#!/bin/bash

# Script de Configuração Automatizada - Sistema de Gestão Padaria Ribamar
# Este script automatiza a configuração do Supabase via SQL Editor

echo "================================================"
echo "  CONFIGURAÇÃO AUTOMATIZADA - PADARIA RIBAMAR"
echo "================================================"
echo ""
echo "Este script irá gerar os comandos SQL necessários para configurar"
echo "o sistema completo no Supabase."
echo ""
echo "PASSOS:"
echo "1. Aceder a: https://supabase.com/dashboard/project/qqvmbueaxclmywrhezcr"
echo "2. Ir para 'SQL Editor' no menu lateral"
echo "3. Copiar e executar cada bloco SQL gerado abaixo"
echo ""
echo "================================================"
echo ""

# Criar diretório de output
mkdir -p setup-sql

# PARTE 1: Criar Tabelas
echo "📝 Gerando PARTE 1: Criação de Tabelas..."
cat > setup-sql/01-create-tables.sql << 'EOF'
-- ================================================
-- PARTE 1: CRIAÇÃO DE TABELAS
-- Sistema de Gestão de Padaria Ribamar
-- ================================================

-- Tabela de perfis de utilizadores
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL UNIQUE,
  nome TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin', 'funcionario')),
  telefone TEXT,
  ativo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabela de clientes
CREATE TABLE IF NOT EXISTS clientes (
  id SERIAL PRIMARY KEY,
  nome TEXT NOT NULL,
  telefone TEXT,
  email TEXT,
  endereco TEXT,
  bairro TEXT,
  referencia TEXT,
  observacoes TEXT,
  ativo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID REFERENCES auth.users(id)
);

-- Tabela de produtos
CREATE TABLE IF NOT EXISTS produtos (
  id SERIAL PRIMARY KEY,
  nome TEXT NOT NULL,
  categoria TEXT,
  preco DECIMAL(10,2) NOT NULL,
  estoque INTEGER DEFAULT 0,
  unidade TEXT DEFAULT 'un',
  ativo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabela de pedidos
CREATE TABLE IF NOT EXISTS pedidos (
  id SERIAL PRIMARY KEY,
  cliente_id INTEGER NOT NULL,
  data_pedido TIMESTAMPTZ DEFAULT NOW(),
  status TEXT NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'preparacao', 'pronto', 'entregue', 'cancelado')),
  observacoes TEXT,
  valor_total DECIMAL(10,2) DEFAULT 0,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabela de itens dos pedidos
CREATE TABLE IF NOT EXISTS pedido_itens (
  id SERIAL PRIMARY KEY,
  pedido_id INTEGER NOT NULL,
  produto_id INTEGER NOT NULL,
  quantidade INTEGER NOT NULL,
  preco_unitario DECIMAL(10,2) NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabela de entregas
CREATE TABLE IF NOT EXISTS entregas (
  id SERIAL PRIMARY KEY,
  pedido_id INTEGER NOT NULL,
  data_entrega DATE NOT NULL,
  hora_entrega TIME,
  status TEXT NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'em_rota', 'entregue', 'cancelada')),
  funcionario_id UUID REFERENCES auth.users(id),
  observacoes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabela de pagamentos
CREATE TABLE IF NOT EXISTS pagamentos (
  id SERIAL PRIMARY KEY,
  pedido_id INTEGER NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  data_pagamento TIMESTAMPTZ DEFAULT NOW(),
  metodo TEXT NOT NULL CHECK (metodo IN ('dinheiro', 'cartao', 'pix', 'transferencia')),
  status TEXT NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'pago', 'cancelado')),
  funcionario_id UUID REFERENCES auth.users(id),
  observacoes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Criar índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_profiles_email ON profiles(email);
CREATE INDEX IF NOT EXISTS idx_clientes_nome ON clientes(nome);
CREATE INDEX IF NOT EXISTS idx_clientes_ativo ON clientes(ativo);
CREATE INDEX IF NOT EXISTS idx_produtos_categoria ON produtos(categoria);
CREATE INDEX IF NOT EXISTS idx_produtos_ativo ON produtos(ativo);
CREATE INDEX IF NOT EXISTS idx_pedidos_cliente ON pedidos(cliente_id);
CREATE INDEX IF NOT EXISTS idx_pedidos_status ON pedidos(status);
CREATE INDEX IF NOT EXISTS idx_pedidos_data ON pedidos(data_pedido);
CREATE INDEX IF NOT EXISTS idx_pedido_itens_pedido ON pedido_itens(pedido_id);
CREATE INDEX IF NOT EXISTS idx_entregas_data ON entregas(data_entrega);
CREATE INDEX IF NOT EXISTS idx_entregas_status ON entregas(status);
CREATE INDEX IF NOT EXISTS idx_entregas_funcionario ON entregas(funcionario_id);
CREATE INDEX IF NOT EXISTS idx_pagamentos_pedido ON pagamentos(pedido_id);
CREATE INDEX IF NOT EXISTS idx_pagamentos_status ON pagamentos(status);
CREATE INDEX IF NOT EXISTS idx_pagamentos_funcionario ON pagamentos(funcionario_id);
EOF

# PARTE 2: RLS Policies
echo "📝 Gerando PARTE 2: Políticas RLS..."
cat > setup-sql/02-rls-policies.sql << 'EOF'
-- ================================================
-- PARTE 2: POLÍTICAS RLS (ROW LEVEL SECURITY)
-- Sistema de Gestão de Padaria Ribamar
-- ================================================

-- Ativar RLS em todas as tabelas
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE produtos ENABLE ROW LEVEL SECURITY;
ALTER TABLE pedidos ENABLE ROW LEVEL SECURITY;
ALTER TABLE pedido_itens ENABLE ROW LEVEL SECURITY;
ALTER TABLE entregas ENABLE ROW LEVEL SECURITY;
ALTER TABLE pagamentos ENABLE ROW LEVEL SECURITY;

-- Políticas para profiles
CREATE POLICY "Utilizadores podem ver o próprio perfil" ON profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Admins podem ver todos os perfis" ON profiles
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins podem inserir perfis" ON profiles
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins podem atualizar perfis" ON profiles
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

-- Políticas para clientes (todos os utilizadores autenticados)
CREATE POLICY "Utilizadores autenticados podem ver clientes" ON clientes
  FOR SELECT USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem inserir clientes" ON clientes
  FOR INSERT WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem atualizar clientes" ON clientes
  FOR UPDATE USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

-- Políticas para produtos
CREATE POLICY "Utilizadores autenticados podem ver produtos" ON produtos
  FOR SELECT USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Admins podem inserir produtos" ON produtos
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins podem atualizar produtos" ON produtos
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

-- Políticas para pedidos
CREATE POLICY "Utilizadores autenticados podem ver pedidos" ON pedidos
  FOR SELECT USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem inserir pedidos" ON pedidos
  FOR INSERT WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem atualizar pedidos" ON pedidos
  FOR UPDATE USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

-- Políticas para pedido_itens
CREATE POLICY "Utilizadores autenticados podem ver itens" ON pedido_itens
  FOR SELECT USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem inserir itens" ON pedido_itens
  FOR INSERT WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

-- Políticas para entregas
CREATE POLICY "Utilizadores autenticados podem ver entregas" ON entregas
  FOR SELECT USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem inserir entregas" ON entregas
  FOR INSERT WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem atualizar entregas" ON entregas
  FOR UPDATE USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

-- Políticas para pagamentos
CREATE POLICY "Utilizadores autenticados podem ver pagamentos" ON pagamentos
  FOR SELECT USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem inserir pagamentos" ON pagamentos
  FOR INSERT WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem atualizar pagamentos" ON pagamentos
  FOR UPDATE USING (auth.role() IN ('authenticated', 'anon', 'service_role'));
EOF

# PARTE 3: Dados Iniciais
echo "📝 Gerando PARTE 3: Dados Iniciais..."
cat > setup-sql/03-seed-data.sql << 'EOF'
-- ================================================
-- PARTE 3: DADOS INICIAIS (OPCIONAL)
-- Sistema de Gestão de Padaria Ribamar
-- ================================================
-- IMPORTANTE: Só executar APÓS criar o utilizador admin no painel Authentication

-- Inserir perfil do administrador
-- Substituir 'USER_ID_AQUI' pelo ID do utilizador criado
INSERT INTO profiles (id, email, nome, role, ativo)
SELECT 
  id,
  'viniciussiuva1@gmail.com',
  'Administrador',
  'admin',
  true
FROM auth.users
WHERE email = 'viniciussiuva1@gmail.com'
ON CONFLICT (id) DO NOTHING;

-- Adicionar produtos de exemplo (OPCIONAL)
INSERT INTO produtos (nome, categoria, preco, estoque, unidade) VALUES
('Pão Francês', 'Pães', 0.50, 100, 'un'),
('Pão de Forma', 'Pães', 3.50, 20, 'un'),
('Bolo de Chocolate', 'Bolos', 25.00, 5, 'un'),
('Croissant', 'Pães', 2.50, 30, 'un'),
('Sonho', 'Doces', 2.00, 15, 'un'),
('Baguete', 'Pães', 1.50, 25, 'un'),
('Pão Integral', 'Pães', 4.00, 15, 'un'),
('Torta de Morango', 'Bolos', 30.00, 3, 'un')
ON CONFLICT DO NOTHING;

-- Adicionar clientes de exemplo (OPCIONAL)
INSERT INTO clientes (nome, telefone, bairro, endereco, created_by) VALUES
('João Silva', '912345678', 'Centro', 'Rua Principal, 123', (SELECT id FROM auth.users WHERE email = 'viniciussiuva1@gmail.com')),
('Maria Santos', '913456789', 'Norte', 'Av. Central, 456', (SELECT id FROM auth.users WHERE email = 'viniciussiuva1@gmail.com')),
('Pedro Costa', '914567890', 'Sul', 'Praça da República, 789', (SELECT id FROM auth.users WHERE email = 'viniciussiuva1@gmail.com')),
('Ana Ferreira', '915678901', 'Centro', 'Rua das Flores, 321', (SELECT id FROM auth.users WHERE email = 'viniciussiuva1@gmail.com')),
('Carlos Oliveira', '916789012', 'Leste', 'Av. da Liberdade, 654', (SELECT id FROM auth.users WHERE email = 'viniciussiuva1@gmail.com'))
ON CONFLICT DO NOTHING;
EOF

# PARTE 4: Instruções
echo "📝 Gerando instruções de uso..."
cat > setup-sql/00-INSTRUCOES.md << 'EOF'
# INSTRUÇÕES DE CONFIGURAÇÃO - PADARIA RIBAMAR

## Pré-requisitos
- Acesso ao painel do Supabase: https://supabase.com/dashboard/project/qqvmbueaxclmywrhezcr

## PASSO 1: Criar Tabelas
1. Aceder ao **SQL Editor** no painel do Supabase
2. Clicar em "New Query"
3. Copiar TODO o conteúdo do ficheiro: `01-create-tables.sql`
4. Colar no editor
5. Clicar em "Run" (ou pressionar Ctrl+Enter)
6. **Aguardar confirmação**: "Success. No rows returned"

## PASSO 2: Configurar Políticas RLS
1. No SQL Editor, criar uma nova query
2. Copiar TODO o conteúdo do ficheiro: `02-rls-policies.sql`
3. Colar no editor
4. Clicar em "Run"
5. **Aguardar confirmação**: "Success. No rows returned"

## PASSO 3: Criar Utilizador Administrador
1. Ir para **Authentication** → **Users** no menu lateral
2. Clicar em "Add user" → "Create new user"
3. Preencher:
   - Email: `viniciussiuva1@gmail.com`
   - Password: `Padariaribamar2025Cvs`
   - Auto Confirm User: ✅ (marcar)
4. Clicar em "Create user"
5. **Copiar o User ID** que aparece na lista (formato: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx)

## PASSO 4: Inserir Dados Iniciais
1. Voltar ao SQL Editor
2. Criar uma nova query
3. Copiar TODO o conteúdo do ficheiro: `03-seed-data.sql`
4. Colar no editor
5. Clicar em "Run"
6. **Aguardar confirmação**: Verificar que dados foram inseridos

## PASSO 5: Testar o Sistema
1. Aceder ao sistema: https://pg8oh6uhkskc.space.minimax.io
2. Fazer login com:
   - Email: viniciussiuva1@gmail.com
   - Senha: Padariaribamar2025Cvs
3. Verificar que o dashboard carrega corretamente
4. Testar funcionalidades:
   - Ver produtos e clientes de exemplo
   - Adicionar novo cliente
   - Adicionar novo produto
   - Navegar pelas diferentes páginas

## Troubleshooting

### Erro ao executar SQL
- Verificar se copiou TODO o conteúdo do ficheiro
- Verificar se não há queries anteriores a interferir
- Tentar executar novamente

### Não consigo fazer login
- Verificar se o utilizador foi criado no painel Authentication
- Verificar se o perfil foi inserido na tabela profiles (PASSO 4)
- Verificar email e senha

### Dados não aparecem
- Verificar se TODAS as políticas RLS foram criadas (PASSO 2)
- Verificar se está autenticado
- Verificar console do navegador para erros

## Tempo Estimado Total
- Configuração completa: **5-7 minutos**
- Incluindo testes: **10 minutos**

## Ficheiros Gerados
1. `00-INSTRUCOES.md` - Este ficheiro
2. `01-create-tables.sql` - Criação de tabelas e índices
3. `02-rls-policies.sql` - Políticas de segurança
4. `03-seed-data.sql` - Dados iniciais e de exemplo

## Suporte
Se encontrar problemas:
1. Verificar os passos foram seguidos na ordem correta
2. Verificar mensagens de erro no SQL Editor
3. Verificar console do navegador (F12)
4. Contactar o administrador do sistema
EOF

echo ""
echo "✅ Ficheiros SQL gerados com sucesso!"
echo ""
echo "📁 Localização: ./setup-sql/"
echo ""
echo "📄 Ficheiros criados:"
echo "  - 00-INSTRUCOES.md      (Leia este primeiro!)"
echo "  - 01-create-tables.sql  (Executar em 1º lugar)"
echo "  - 02-rls-policies.sql   (Executar em 2º lugar)"
echo "  - 03-seed-data.sql      (Executar em 3º lugar)"
echo ""
echo "================================================"
echo "  PRÓXIMOS PASSOS"
echo "================================================"
echo ""
echo "1. Ler as instruções em: setup-sql/00-INSTRUCOES.md"
echo "2. Aceder ao Supabase SQL Editor"
echo "3. Executar os 3 ficheiros SQL na ordem indicada"
echo "4. Criar utilizador admin no painel Authentication"
echo "5. Testar o sistema em: https://pg8oh6uhkskc.space.minimax.io"
echo ""
echo "Tempo estimado: 5-7 minutos"
echo ""
echo "================================================"
