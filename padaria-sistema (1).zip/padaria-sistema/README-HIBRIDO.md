# Sistema de Gestão de Padaria - Modo Híbrido ATIVO

## Acesso Imediato

**URL**: https://3ecoke3pl071.space.minimax.io

**Login**:
- Email: viniciussiuva1@gmail.com
- Senha: Padariaribamar2025Cvs

## Status Atual: MODO OFFLINE (LocalStorage)

O sistema está totalmente funcional usando armazenamento local do navegador enquanto o Supabase está pausado.

### O que está funcionando AGORA:

✅ Login com credenciais do administrador  
✅ Dashboard completo com estatísticas  
✅ Gestão de Clientes (criar, editar, excluir, pesquisar)  
✅ Gestão de Produtos (criar, editar, excluir, alertas de estoque)  
✅ Dados de exemplo pré-carregados  
✅ Persistência de todos os dados no navegador  
✅ Indicadores visuais de status (Online/Offline)  
✅ Interface responsiva para desktop e mobile  

### Dados de Exemplo Incluídos:

**Clientes**:
- Maria Silva (98912345678)
- João Santos (98987654321)

**Produtos**:
- Pão Francês - €0,50
- Pão de Forma - €8,50
- Bolo de Chocolate - €35,00

## Como Usar

1. Acesse a URL acima
2. Faça login com as credenciais
3. Use normalmente - todos os dados ficam salvos
4. Adicione clientes e produtos conforme necessário

**IMPORTANTE**: Em modo offline, dados ficam apenas neste navegador. Não limpe os dados do navegador para não perder informações.

## Quando o Supabase Voltar

O sistema detectará automaticamente e:
- Mudará para modo online
- Permitirá adicionar funcionários
- Sincronizará dados entre dispositivos
- Todos os dados criados offline podem ser migrados

## Documentação Completa

Consulte `GUIA-HIBRIDO.md` para:
- Detalhes técnicos do sistema híbrido
- Como funciona a detecção automática
- Resolução de problemas
- Como sincronizar dados quando Supabase voltar

## Arquitetura Híbrida

O sistema implementa detecção automática:
- Testa conexão Supabase ao carregar
- Se offline: usa LocalStorage
- Se online: usa Supabase (cloud)
- Interface idêntica em ambos os modos

## Suporte

Para questões técnicas ou problemas, consulte:
- `GUIA-HIBRIDO.md` - Guia completo de uso
- `test-progress-hybrid.md` - Relatório de testes
- `CONFIGURACAO_SUPABASE.md` - Como configurar Supabase

---

**Sistema desenvolvido e testado - 100% funcional em modo offline**

Última atualização: 2025-11-03
