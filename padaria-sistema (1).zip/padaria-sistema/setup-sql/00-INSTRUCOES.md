# INSTRUÇÕES DE CONFIGURAÇÃO - PADARIA RIBAMAR

## Pré-requisitos
- Acesso ao painel do Supabase: https://supabase.com/dashboard/project/qqvmbueaxclmywrhezcr

## PASSO 1: Criar Tabelas
1. Aceder ao **SQL Editor** no painel do Supabase
2. Clicar em "New Query"
3. Copiar TODO o conteúdo do ficheiro: `01-create-tables.sql`
4. Colar no editor
5. Clicar em "Run" (ou pressionar Ctrl+Enter)
6. **Aguardar confirmação**: "Success. No rows returned"

## PASSO 2: Configurar Políticas RLS
1. No SQL Editor, criar uma nova query
2. Copiar TODO o conteúdo do ficheiro: `02-rls-policies.sql`
3. Colar no editor
4. Clicar em "Run"
5. **Aguardar confirmação**: "Success. No rows returned"

## PASSO 3: Criar Utilizador Administrador
1. Ir para **Authentication** → **Users** no menu lateral
2. Clicar em "Add user" → "Create new user"
3. Preencher:
   - Email: `viniciussiuva1@gmail.com`
   - Password: `Padariaribamar2025Cvs`
   - Auto Confirm User: ✅ (marcar)
4. Clicar em "Create user"
5. **Copiar o User ID** que aparece na lista (formato: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx)

## PASSO 4: Inserir Dados Iniciais
1. Voltar ao SQL Editor
2. Criar uma nova query
3. Copiar TODO o conteúdo do ficheiro: `03-seed-data.sql`
4. Colar no editor
5. Clicar em "Run"
6. **Aguardar confirmação**: Verificar que dados foram inseridos

## PASSO 5: Testar o Sistema
1. Aceder ao sistema: https://pg8oh6uhkskc.space.minimax.io
2. Fazer login com:
   - Email: viniciussiuva1@gmail.com
   - Senha: Padariaribamar2025Cvs
3. Verificar que o dashboard carrega corretamente
4. Testar funcionalidades:
   - Ver produtos e clientes de exemplo
   - Adicionar novo cliente
   - Adicionar novo produto
   - Navegar pelas diferentes páginas

## Troubleshooting

### Erro ao executar SQL
- Verificar se copiou TODO o conteúdo do ficheiro
- Verificar se não há queries anteriores a interferir
- Tentar executar novamente

### Não consigo fazer login
- Verificar se o utilizador foi criado no painel Authentication
- Verificar se o perfil foi inserido na tabela profiles (PASSO 4)
- Verificar email e senha

### Dados não aparecem
- Verificar se TODAS as políticas RLS foram criadas (PASSO 2)
- Verificar se está autenticado
- Verificar console do navegador para erros

## Tempo Estimado Total
- Configuração completa: **5-7 minutos**
- Incluindo testes: **10 minutos**

## Ficheiros Gerados
1. `00-INSTRUCOES.md` - Este ficheiro
2. `01-create-tables.sql` - Criação de tabelas e índices
3. `02-rls-policies.sql` - Políticas de segurança
4. `03-seed-data.sql` - Dados iniciais e de exemplo

## Suporte
Se encontrar problemas:
1. Verificar os passos foram seguidos na ordem correta
2. Verificar mensagens de erro no SQL Editor
3. Verificar console do navegador (F12)
4. Contactar o administrador do sistema
