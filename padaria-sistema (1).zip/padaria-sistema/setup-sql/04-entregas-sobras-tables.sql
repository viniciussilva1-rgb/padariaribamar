-- Tabelas para Controle Diário de Entregas e Sobras
-- Criado em: 2025-11-03

-- Tabela: movimentos_entregador
-- Armazena os registos de carga diária dos entregadores
CREATE TABLE IF NOT EXISTS movimentos_entregador (
  id SERIAL PRIMARY KEY,
  data DATE NOT NULL,
  entregador_email VARCHAR(255) NOT NULL,
  produto VARCHAR(100) NOT NULL,
  qtde_levada INTEGER DEFAULT 0,
  qtde_sobra INTEGER DEFAULT 0,
  preco_unitario DECIMAL(10,2) NOT NULL,
  valor_levado DECIMAL(10,2) GENERATED ALWAYS AS (qtde_levada * preco_unitario) STORED,
  valor_sobra DECIMAL(10,2) GENERATED ALWAYS AS (qtde_sobra * preco_unitario) STORED,
  valor_vendido DECIMAL(10,2) GENERATED ALWAYS AS ((qtde_levada * preco_unitario) - (qtde_sobra * preco_unitario)) STORED,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Tabela: producao_diaria
-- Armazena a produção diária de cada produto
CREATE TABLE IF NOT EXISTS producao_diaria (
  id SERIAL PRIMARY KEY,
  data DATE NOT NULL,
  produto VARCHAR(100) NOT NULL,
  qtde_produzida INTEGER NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(data, produto)
);

-- Indices para performance
CREATE INDEX IF NOT EXISTS idx_movimentos_data ON movimentos_entregador(data);
CREATE INDEX IF NOT EXISTS idx_movimentos_entregador ON movimentos_entregador(entregador_email);
CREATE INDEX IF NOT EXISTS idx_movimentos_produto ON movimentos_entregador(produto);
CREATE INDEX IF NOT EXISTS idx_producao_data ON producao_diaria(data);
CREATE INDEX IF NOT EXISTS idx_producao_produto ON producao_diaria(produto);

-- Comentários nas tabelas
COMMENT ON TABLE movimentos_entregador IS 'Registos diários de carga dos entregadores (quantidade levada e sobras)';
COMMENT ON TABLE producao_diaria IS 'Produção diária de cada produto para cálculo de quebra';

-- Comentários nas colunas
COMMENT ON COLUMN movimentos_entregador.qtde_levada IS 'Quantidade total levada pelo entregador';
COMMENT ON COLUMN movimentos_entregador.qtde_sobra IS 'Quantidade que sobrou (não foi vendida)';
COMMENT ON COLUMN movimentos_entregador.valor_levado IS 'Valor total do que foi levado (calculado)';
COMMENT ON COLUMN movimentos_entregador.valor_sobra IS 'Valor total das sobras (calculado)';
COMMENT ON COLUMN movimentos_entregador.valor_vendido IS 'Valor efetivamente vendido (calculado)';
COMMENT ON COLUMN producao_diaria.qtde_produzida IS 'Quantidade total produzida no dia';
