/** @type {import('tailwindcss').Config} */
module.exports = {
	darkMode: ['class'],
	content: [
		'./pages/**/*.{ts,tsx}',
		'./components/**/*.{ts,tsx}',
		'./app/**/*.{ts,tsx}',
		'./src/**/*.{ts,tsx}',
	],
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px',
			},
		},
		extend: {
			colors: {
				border: '#E5E7EB',
				input: '#E5E7EB',
				ring: '#D97706',
				background: '#FFFFFF',
				foreground: '#111827',
				primary: {
					DEFAULT: '#D97706',
					50: '#FFF7ED',
					100: '#FFEDD5',
					200: '#FED7AA',
					300: '#FDBA74',
					400: '#FB923C',
					500: '#F97316',
					600: '#EA580C',
					700: '#C2410C',
					800: '#9A3412',
					900: '#7C2D12',
					foreground: '#FFFFFF',
				},
				secondary: {
					DEFAULT: '#92400E',
					foreground: '#FFFFFF',
				},
				accent: {
					DEFAULT: '#FCD34D',
					foreground: '#78350F',
				},
				destructive: {
					DEFAULT: '#DC2626',
					foreground: '#FFFFFF',
				},
				muted: {
					DEFAULT: '#F3F4F6',
					foreground: '#6B7280',
				},
				popover: {
					DEFAULT: '#FFFFFF',
					foreground: '#111827',
				},
				card: {
					DEFAULT: '#FFFFFF',
					foreground: '#111827',
				},
			},
			borderRadius: {
				lg: '0.5rem',
				md: '0.375rem',
				sm: '0.25rem',
			},
			keyframes: {
				'accordion-down': {
					from: { height: 0 },
					to: { height: 'var(--radix-accordion-content-height)' },
				},
				'accordion-up': {
					from: { height: 'var(--radix-accordion-content-height)' },
					to: { height: 0 },
				},
			},
			animation: {
				'accordion-down': 'accordion-down 0.2s ease-out',
				'accordion-up': 'accordion-up 0.2s ease-out',
			},
		},
	},
	plugins: [require('tailwindcss-animate')],
}
