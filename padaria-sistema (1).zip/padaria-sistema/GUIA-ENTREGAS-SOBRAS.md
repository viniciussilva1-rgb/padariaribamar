# Sistema de Controle Diário de Entregas e Sobras

## Resumo da Implementação

Sistema completo para controlo diário de entregas e sobras de produtos de padaria, com duas interfaces distintas:
- **Carga do Dia** - Para funcionários/entregadores registarem suas entregas diárias
- **Produção e Quebra** - Para administradores gerirem produção e analisarem quebra

## URLs de Acesso

- **Sistema Atualizado**: https://im7dgo3xnsza.space.minimax.io
- **Credenciais Admin**:
  - Email: viniciussiuva1@gmail.com
  - Senha: Padariaribamar2025Cvs

## Funcionalidades Implementadas

### 1. Banco de Dados

Duas novas tabelas criadas no Supabase:

#### `movimentos_entregador`
- Armazena registos diários de cada entregador
- Campos: data, entregador_email, produto, qtde_levada, qtde_sobra, preco_unitario
- Cálculos automáticos: valor_levado, valor_sobra, valor_vendido
- Índices para performance em queries por data e entregador

#### `producao_diaria`
- Armazena produção diária de cada produto
- Campos: data, produto, qtde_produzida
- Constraint UNIQUE(data, produto) para evitar duplicatas

### 2. Página "Carga do Dia" (`/carga-dia`)

**Acesso**: Todos os utilizadores (funcionários e administradores)

**Funcionalidades**:
- Lista fixa de 12 produtos da padaria com preços pré-definidos
- Campos para registar quantidade levada e sobras por produto
- Seleção de data (padrão: dia atual)
- Cálculos automáticos em tempo real:
  - Valor Levado = qtde_levada × preco_unitario
  - Valor Sobra = qtde_sobra × preco_unitario
  - Valor Vendido = Valor Levado - Valor Sobra
- Totalizadores automáticos no rodapé
- Validações:
  - Sobras não podem ser maiores que quantidade levada
  - Pelo menos um produto deve ter quantidade
- Interface responsiva (tabela desktop + cards mobile)
- Carrega dados existentes para edição
- Sistema híbrido: funciona online (Supabase) e offline (LocalStorage)

**Produtos Fixos**:
1. Bolinha - 0,25€
2. Viana - 0,80€
3. Pão de trigo - 0,30€
4. Cassete - 0,35€
5. Pão pequeno - 0,25€
6. Papo Seco - 0,30€
7. Bolinha de semente - 0,40€
8. Bolinha de centeio - 0,40€
9. Cassetinho de centeio - 0,35€
10. Pão de milho - 0,45€
11. Pão de forma - 1,50€
12. Pão com chouriço - 1,20€

### 3. Página "Produção e Quebra do Dia" (`/producao-quebra`)

**Acesso**: Apenas administradores

**Seção 1: Registo de Produção**
- Formulário com todos os 12 produtos
- Campo para quantidade produzida de cada item
- Salvamento com validação (pelo menos um produto)
- Atualização automática das análises após salvar

**Seção 2: Visão Consolidada**
- Tabela resumo por produto com colunas:
  - Produzido (da produção_diaria)
  - Levado (soma de todos os entregadores)
  - Sobras (soma de todos os entregadores)
  - Vendido (Levado - Sobras)
  - Quebra = Produzido - (Vendido + Sobras)
  - Valor da Quebra = Quebra × preco_unitario
- Totalizadores de todos os valores
- Interface responsiva (tabela desktop + cards mobile)

**Seção 3: Visão por Entregador**
- Lista de todos os entregadores que registaram cargas no dia
- Para cada entregador:
  - Tabela com produtos, quantidades e valores
  - Totais: Levado, Sobras, Vendido
- Identificação por email do entregador
- Resumo visual com valores destacados

**Navegação**:
- Tabs para alternar entre "Visão Consolidada" e "Por Entregador"
- Filtro de data para análise histórica
- Indicador de status (Online/Offline)

### 4. Controlo de Acesso

**RLS Policies Implementadas**:
- Utilizadores autenticados podem ver e criar seus próprios movimentos
- Apenas administradores acedem à página de Produção e Quebra
- Mensagem de "Acesso Restrito" para funcionários que tentam acessar página admin

**Integração com Sistema Existente**:
- Links adicionados ao menu de navegação
- "Carga do Dia" visível para todos
- "Produção e Quebra" visível apenas para admins
- Rotas protegidas no React Router

### 5. Sistema Híbrido (Supabase + LocalStorage)

**Modo Online**:
- Dados salvos no Supabase
- Multi-utilizador
- Sincronização em tempo real

**Modo Offline**:
- Dados salvos em LocalStorage
- Utilizador único (admin)
- Funcionalidade completa mantida

**Detecção Automática**:
- Testa conexão Supabase ao carregar
- Indicador visual de status (badge Online/Offline)
- Fallback transparente para o utilizador

## Arquitetura Técnica

### Frontend
- **Framework**: React 18 + TypeScript
- **Routing**: React Router v6
- **Styling**: TailwindCSS
- **Icons**: Lucide React
- **Build**: Vite

### Backend
- **Database**: PostgreSQL (Supabase)
- **Storage**: LocalStorage (modo offline)
- **Authentication**: Supabase Auth

### Estrutura de Arquivos

```
src/
├── lib/
│   ├── produtos-fixos.ts         # Lista de produtos com preços
│   ├── storage-adapter.ts         # Adaptadores híbridos (atualizados)
│   └── supabase.ts                # Tipos e cliente Supabase (atualizados)
├── pages/
│   ├── CargaDia.tsx               # Página para funcionários
│   └── ProducaoQuebra.tsx         # Página para administradores
├── components/
│   └── Layout.tsx                 # Menu de navegação (atualizado)
└── App.tsx                        # Rotas (atualizadas)

setup-sql/
├── 04-entregas-sobras-tables.sql  # Criação das tabelas
└── 05-entregas-sobras-rls.sql     # Políticas RLS
```

## Cálculos Implementados

### Por Produto (Carga do Dia)
```
valor_levado = qtde_levada × preco_unitario
valor_sobra = qtde_sobra × preco_unitario
valor_vendido = valor_levado - valor_sobra
```

### Consolidado (Produção e Quebra)
```
levado_total = Σ(qtde_levada) de todos os entregadores
sobras_total = Σ(qtde_sobra) de todos os entregadores
vendido = levado_total - sobras_total
quebra = produzido - (vendido + sobras_total)
valor_quebra = quebra × preco_unitario
```

### Por Entregador
```
total_levado = Σ(qtde_levada × preco) de todos os produtos
total_sobras = Σ(qtde_sobra × preco) de todos os produtos
total_vendido = total_levado - total_sobras
```

## Validações Implementadas

### Carga do Dia
1. Sobras não podem ser maiores que quantidade levada
2. Pelo menos um produto deve ter quantidade levada > 0
3. Valores numéricos positivos ou zero
4. Data obrigatória

### Produção Diária
1. Pelo menos um produto deve ter quantidade produzida > 0
2. Valores numéricos positivos
3. Data obrigatória
4. Apenas administradores podem salvar

## Responsividade

### Desktop
- Tabelas completas com todas as colunas
- Layout espaçado e legível
- Menu lateral fixo

### Mobile
- Cards individuais por produto
- Campos organizados em grid
- Menu hambúrguer
- Totais em card destacado
- Scroll otimizado

## Como Usar

### Funcionário - Registar Carga do Dia

1. Fazer login no sistema
2. Clicar em "Carga do Dia" no menu
3. Confirmar ou alterar a data
4. Preencher quantidade levada para cada produto
5. Preencher quantidade de sobras (se houver)
6. Verificar cálculos automáticos
7. Clicar em "Guardar Carga"
8. Confirmar mensagem de sucesso

### Administrador - Registar Produção

1. Fazer login como administrador
2. Clicar em "Produção e Quebra" no menu
3. Na seção "Registar Produção Diária":
   - Selecionar data
   - Preencher quantidade produzida de cada produto
   - Clicar em "Guardar Produção"

### Administrador - Analisar Quebra

1. Na mesma página "Produção e Quebra"
2. Tab "Visão Consolidada":
   - Ver resumo por produto
   - Analisar quebra e seu valor
   - Verificar totais
3. Tab "Por Entregador":
   - Ver performance de cada entregador
   - Analisar produtos vendidos por pessoa
   - Comparar totais entre entregadores

## Status da Implementação

### Completo
- [x] Tabelas no banco de dados criadas
- [x] Políticas RLS aplicadas
- [x] Tipos TypeScript definidos
- [x] Adaptadores híbridos implementados
- [x] Página Carga do Dia desenvolvida
- [x] Página Produção e Quebra desenvolvida
- [x] Validações implementadas
- [x] Cálculos automáticos funcionando
- [x] Interface responsiva
- [x] Integração com menu de navegação
- [x] Sistema híbrido (online/offline)
- [x] Build de produção
- [x] Deploy realizado

### Pendente
- [ ] Testes automatizados completos (ferramenta de teste indisponível)
- [ ] Otimização de performance (code splitting)

## Notas Técnicas

### Colunas Calculadas no PostgreSQL
As colunas `valor_levado`, `valor_sobra` e `valor_vendido` são GENERATED COLUMNS no PostgreSQL, calculadas automaticamente pelo banco de dados. Isso garante consistência e performance.

### Constraint UNIQUE
A tabela `producao_diaria` tem constraint UNIQUE(data, produto) para evitar registos duplicados do mesmo produto na mesma data.

### Sistema Híbrido
O sistema detecta automaticamente se o Supabase está disponível. Em modo offline:
- Apenas o administrador pode fazer login
- Dados salvos em LocalStorage
- Funcionalidade completa mantida
- Badge visual indica o status

### Performance
- Índices criados em campos de busca frequente (data, email, produto)
- Queries otimizadas para evitar full table scans
- Cálculos feitos no cliente para melhor UX

## Suporte

Para configuração do Supabase ou problemas:
1. Ver arquivo `/workspace/padaria-sistema/CONFIGURACAO_SUPABASE.md`
2. Executar scripts SQL em `/workspace/padaria-sistema/setup-sql/`
3. Verificar logs do Supabase no dashboard

## Changelog

### v2.0 - 2025-11-03
- Adicionado módulo completo de Controle de Entregas e Sobras
- 2 novas tabelas no banco de dados
- 2 novas páginas no frontend
- Sistema de cálculo automático de quebra
- Análise por entregador
- Interface responsiva mobile-first
