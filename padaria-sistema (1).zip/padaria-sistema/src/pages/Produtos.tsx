import React, { useEffect, useState } from 'react'
import { type Produto } from '../lib/supabase'
import { produtosAdapter } from '../lib/storage-adapter'
import { Package, Plus, Edit2, Trash2, AlertCircle } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'

export default function Produtos() {
  const { profile } = useAuth()
  const [produtos, setProdutos] = useState<Produto[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [editingProduto, setEditingProduto] = useState<Produto | null>(null)
  const [formData, setFormData] = useState({
    nome: '',
    categoria: '',
    preco: '',
    estoque: '',
    unidade: 'un',
  })

  const isAdmin = profile?.role === 'admin'

  useEffect(() => {
    loadProdutos()
  }, [])

  async function loadProdutos() {
    setLoading(true)
    try {
      const data = await produtosAdapter.getAll()
      const ativos = data.filter(p => p.ativo !== false).sort((a, b) => a.nome.localeCompare(b.nome))
      setProdutos(ativos)
    } catch (error) {
      console.error('Erro ao carregar produtos:', error)
    } finally {
      setLoading(false)
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!isAdmin) return

    try {
      const produtoData = {
        nome: formData.nome,
        categoria: formData.categoria,
        preco: parseFloat(formData.preco),
        estoque: parseInt(formData.estoque),
        unidade: formData.unidade,
        ativo: true
      }

      if (editingProduto) {
        await produtosAdapter.update(editingProduto.id, produtoData)
      } else {
        await produtosAdapter.create(produtoData)
      }

      setShowModal(false)
      setEditingProduto(null)
      resetForm()
      loadProdutos()
    } catch (error) {
      console.error('Erro ao salvar produto:', error)
      alert('Erro ao salvar produto.')
    }
  }

  async function handleDelete(id: number) {
    if (!isAdmin || !confirm('Tem certeza que deseja remover este produto?')) return

    try {
      await produtosAdapter.update(id, { ativo: false })
      loadProdutos()
    } catch (error) {
      console.error('Erro ao remover produto:', error)
      alert('Erro ao remover produto.')
    }
  }

  function resetForm() {
    setFormData({
      nome: '',
      categoria: '',
      preco: '',
      estoque: '',
      unidade: 'un',
    })
  }

  function openEditModal(produto: Produto) {
    setEditingProduto(produto)
    setFormData({
      nome: produto.nome,
      categoria: produto.categoria || '',
      preco: produto.preco.toString(),
      estoque: produto.estoque.toString(),
      unidade: produto.unidade,
    })
    setShowModal(true)
  }

  function openAddModal() {
    setEditingProduto(null)
    resetForm()
    setShowModal(true)
  }

  if (!isAdmin) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">Acesso Restrito</h3>
        <p className="text-gray-600">Apenas administradores podem acessar esta página.</p>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    )
  }

  const produtosEstoqueBaixo = produtos.filter(p => p.estoque < 10)

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div className="mb-4 md:mb-0">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Produtos</h1>
          <p className="text-gray-600">{produtos.length} produtos cadastrados</p>
        </div>
        <button
          onClick={openAddModal}
          className="flex items-center space-x-2 bg-primary hover:bg-primary-600 text-white px-6 py-3 rounded-lg transition"
        >
          <Plus className="w-5 h-5" />
          <span>Novo Produto</span>
        </button>
      </div>

      {produtosEstoqueBaixo.length > 0 && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center space-x-3">
          <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
          <p className="text-sm text-red-800">
            <strong>{produtosEstoqueBaixo.length}</strong> produto{produtosEstoqueBaixo.length > 1 ? 's' : ''} com estoque baixo (menos de 10 unidades)
          </p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {produtos.map((produto) => (
          <div
            key={produto.id}
            className={`bg-white rounded-xl shadow-sm border p-6 hover:shadow-md transition ${
              produto.estoque < 10 ? 'border-red-300' : 'border-gray-200'
            }`}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900 mb-1">{produto.nome}</h3>
                {produto.categoria && (
                  <span className="inline-block px-3 py-1 bg-primary-100 text-primary-700 text-xs font-medium rounded-full">
                    {produto.categoria}
                  </span>
                )}
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => openEditModal(produto)}
                  className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(produto.id)}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Preço</span>
                <span className="text-lg font-bold text-primary">€{Number(produto.preco).toFixed(2)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Estoque</span>
                <span className={`text-sm font-semibold ${produto.estoque < 10 ? 'text-red-600' : 'text-gray-900'}`}>
                  {produto.estoque} {produto.unidade}
                </span>
              </div>
            </div>

            {produto.estoque < 10 && (
              <div className="mt-3 p-2 bg-red-50 rounded-lg flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 text-red-500" />
                <span className="text-xs text-red-700">Estoque baixo</span>
              </div>
            )}
          </div>
        ))}
      </div>

      {produtos.length === 0 && (
        <div className="text-center py-12 bg-white rounded-xl border border-gray-200">
          <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhum produto cadastrado</h3>
          <p className="text-gray-600 mb-6">Comece adicionando seus produtos</p>
          <button
            onClick={openAddModal}
            className="inline-flex items-center space-x-2 bg-primary hover:bg-primary-600 text-white px-6 py-3 rounded-lg transition"
          >
            <Plus className="w-5 h-5" />
            <span>Adicionar Produto</span>
          </button>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-md w-full">
            <div className="border-b border-gray-200 px-6 py-4">
              <h2 className="text-2xl font-bold text-gray-900">
                {editingProduto ? 'Editar Produto' : 'Novo Produto'}
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nome <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.nome}
                  onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Categoria</label>
                <input
                  type="text"
                  value={formData.categoria}
                  onChange={(e) => setFormData({ ...formData, categoria: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="Ex: Pães, Bolos, etc."
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Preço <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.preco}
                    onChange={(e) => setFormData({ ...formData, preco: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Estoque <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    value={formData.estoque}
                    onChange={(e) => setFormData({ ...formData, estoque: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Unidade</label>
                <select
                  value={formData.unidade}
                  onChange={(e) => setFormData({ ...formData, unidade: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                >
                  <option value="un">Unidade</option>
                  <option value="kg">Quilograma</option>
                  <option value="g">Grama</option>
                  <option value="L">Litro</option>
                  <option value="ml">Mililitro</option>
                  <option value="cx">Caixa</option>
                  <option value="pct">Pacote</option>
                </select>
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-primary hover:bg-primary-600 text-white py-3 rounded-lg transition font-medium"
                >
                  {editingProduto ? 'Atualizar' : 'Adicionar'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 py-3 rounded-lg transition font-medium"
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
