import React, { useState, useEffect } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { produtosStorage, type ProdutoPadaria } from '../lib/supabase'
import { Package, Plus, Edit, Trash2, CheckCircle, XCircle, Save, X, AlertCircle } from 'lucide-react'

export default function GestaoProdutos() {
  const { profile } = useAuth()
  const [produtos, setProdutos] = useState<ProdutoPadaria[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [editingProduto, setEditingProduto] = useState<ProdutoPadaria | null>(null)
  const [formData, setFormData] = useState({
    nome: '',
    preco_padrao: '',
    ativo: true
  })
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null)
  const [searchTerm, setSearchTerm] = useState('')

  useEffect(() => {
    carregarProdutos()
  }, [])

  async function carregarProdutos() {
    try {
      setLoading(true)
      const data = await produtosStorage.getAll()
      setProdutos(data)
    } catch (error: any) {
      console.error('Erro ao carregar produtos:', error)
      setMessage({ type: 'error', text: 'Erro ao carregar produtos' })
    } finally {
      setLoading(false)
    }
  }

  function abrirModal(produto?: ProdutoPadaria) {
    if (produto) {
      setEditingProduto(produto)
      setFormData({
        nome: produto.nome,
        preco_padrao: produto.preco_padrao.toString(),
        ativo: produto.ativo
      })
    } else {
      setEditingProduto(null)
      setFormData({
        nome: '',
        preco_padrao: '',
        ativo: true
      })
    }
    setShowModal(true)
    setMessage(null)
  }

  function fecharModal() {
    setShowModal(false)
    setEditingProduto(null)
    setFormData({ nome: '', preco_padrao: '', ativo: true })
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setMessage(null)

    if (!formData.nome.trim()) {
      setMessage({ type: 'error', text: 'Nome do produto é obrigatório' })
      return
    }

    const preco = parseFloat(formData.preco_padrao)
    if (isNaN(preco) || preco <= 0) {
      setMessage({ type: 'error', text: 'Preço deve ser maior que zero' })
      return
    }

    try {
      setLoading(true)

      if (editingProduto) {
        await produtosStorage.update(editingProduto.id, {
          nome: formData.nome.trim(),
          preco_padrao: preco,
          ativo: formData.ativo
        })
        setMessage({ type: 'success', text: 'Produto atualizado com sucesso' })
      } else {
        await produtosStorage.create({
          nome: formData.nome.trim(),
          preco_padrao: preco,
          ativo: formData.ativo
        })
        setMessage({ type: 'success', text: 'Produto adicionado com sucesso' })
      }

      await carregarProdutos()
      fecharModal()
    } catch (error: any) {
      console.error('Erro ao salvar produto:', error)
      setMessage({ 
        type: 'error', 
        text: error.message?.includes('duplicate') 
          ? 'Já existe um produto com este nome' 
          : 'Erro ao salvar produto' 
      })
    } finally {
      setLoading(false)
    }
  }

  async function handleToggleAtivo(produto: ProdutoPadaria) {
    try {
      await produtosStorage.update(produto.id, {
        ativo: !produto.ativo
      })
      setMessage({ 
        type: 'success', 
        text: `Produto ${!produto.ativo ? 'ativado' : 'desativado'} com sucesso` 
      })
      await carregarProdutos()
    } catch (error) {
      console.error('Erro ao atualizar produto:', error)
      setMessage({ type: 'error', text: 'Erro ao atualizar produto' })
    }
  }

  async function handleDelete(produto: ProdutoPadaria) {
    if (!confirm(`Tem certeza que deseja excluir o produto "${produto.nome}"?\n\nEsta ação não pode ser desfeita.`)) {
      return
    }

    try {
      await produtosStorage.delete(produto.id)
      setMessage({ type: 'success', text: 'Produto excluído com sucesso' })
      await carregarProdutos()
    } catch (error) {
      console.error('Erro ao excluir produto:', error)
      setMessage({ type: 'error', text: 'Erro ao excluir produto' })
    }
  }

  // Calcular estatísticas
  const stats = {
    total: produtos.length,
    ativos: produtos.filter(p => p.ativo).length,
    inativos: produtos.filter(p => !p.ativo).length
  }

  // Filtrar produtos por busca
  const produtosFiltrados = produtos.filter(p =>
    p.nome.toLowerCase().includes(searchTerm.toLowerCase())
  )

  if (profile?.role !== 'admin') {
    return (
      <div className="max-w-6xl mx-auto p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-800">Acesso restrito a administradores</p>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-primary rounded-lg">
              <Package className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Gestão de Produtos</h1>
              <p className="text-sm text-gray-500">Gerenciar produtos da padaria</p>
            </div>
          </div>
          <button
            onClick={() => abrirModal()}
            className="flex items-center space-x-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition"
          >
            <Plus className="w-5 h-5" />
            <span>Novo Produto</span>
          </button>
        </div>

        {/* Mensagem */}
        {message && (
          <div className={`mb-6 p-4 rounded-lg flex items-start space-x-3 ${
            message.type === 'success' 
              ? 'bg-green-50 border border-green-200' 
              : 'bg-red-50 border border-red-200'
          }`}>
            {message.type === 'success' ? (
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            )}
            <p className={`text-sm ${message.type === 'success' ? 'text-green-800' : 'text-red-800'}`}>
              {message.text}
            </p>
          </div>
        )}

        {/* Cards de Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-600 font-medium">Total de Produtos</p>
                <p className="text-2xl font-bold text-blue-900">{stats.total}</p>
              </div>
              <Package className="w-8 h-8 text-blue-400" />
            </div>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-600 font-medium">Produtos Ativos</p>
                <p className="text-2xl font-bold text-green-900">{stats.ativos}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-400" />
            </div>
          </div>
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 font-medium">Produtos Inativos</p>
                <p className="text-2xl font-bold text-gray-900">{stats.inativos}</p>
              </div>
              <XCircle className="w-8 h-8 text-gray-400" />
            </div>
          </div>
        </div>

        {/* Busca */}
        <div className="mb-4">
          <input
            type="text"
            placeholder="Buscar produto por nome..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
          />
        </div>

        {/* Tabela de Produtos - Desktop */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nome</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Preço Padrão</th>
                <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {produtosFiltrados.map((produto) => (
                <tr key={produto.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm font-medium text-gray-900">{produto.nome}</td>
                  <td className="px-4 py-3 text-sm text-gray-900 text-right">{produto.preco_padrao.toFixed(2)} EUR</td>
                  <td className="px-4 py-3 text-center">
                    <button
                      onClick={() => handleToggleAtivo(produto)}
                      className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                        produto.ativo
                          ? 'bg-green-100 text-green-800 hover:bg-green-200'
                          : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                      }`}
                    >
                      {produto.ativo ? 'Ativo' : 'Inativo'}
                    </button>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <button
                        onClick={() => abrirModal(produto)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition"
                        title="Editar"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(produto)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                        title="Excluir"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Cards de Produtos - Mobile */}
        <div className="md:hidden space-y-4">
          {produtosFiltrados.map((produto) => (
            <div key={produto.id} className="border border-gray-200 rounded-lg p-4 bg-white">
              <div className="flex justify-between items-start mb-3">
                <h3 className="font-semibold text-gray-900">{produto.nome}</h3>
                <button
                  onClick={() => handleToggleAtivo(produto)}
                  className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                    produto.ativo
                      ? 'bg-green-100 text-green-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}
                >
                  {produto.ativo ? 'Ativo' : 'Inativo'}
                </button>
              </div>
              <p className="text-lg font-bold text-primary mb-3">{produto.preco_padrao.toFixed(2)} EUR</p>
              <div className="flex space-x-2">
                <button
                  onClick={() => abrirModal(produto)}
                  className="flex-1 flex items-center justify-center space-x-2 px-3 py-2 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition"
                >
                  <Edit className="w-4 h-4" />
                  <span>Editar</span>
                </button>
                <button
                  onClick={() => handleDelete(produto)}
                  className="flex-1 flex items-center justify-center space-x-2 px-3 py-2 bg-red-50 text-red-700 rounded-lg hover:bg-red-100 transition"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Excluir</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {loading && produtosFiltrados.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            Carregando produtos...
          </div>
        )}

        {!loading && produtosFiltrados.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            {searchTerm ? 'Nenhum produto encontrado' : 'Nenhum produto cadastrado'}
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">
                {editingProduto ? 'Editar Produto' : 'Novo Produto'}
              </h2>
              <button
                onClick={fecharModal}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nome do Produto *
                  </label>
                  <input
                    type="text"
                    value={formData.nome}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="Ex: Pão Francês"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Preço Padrão (EUR) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    value={formData.preco_padrao}
                    onChange={(e) => setFormData({ ...formData, preco_padrao: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="0.00"
                    required
                  />
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="ativo"
                    checked={formData.ativo}
                    onChange={(e) => setFormData({ ...formData, ativo: e.target.checked })}
                    className="w-4 h-4 text-primary border-gray-300 rounded focus:ring-primary"
                  />
                  <label htmlFor="ativo" className="ml-2 text-sm text-gray-700">
                    Produto ativo
                  </label>
                </div>
              </div>

              <div className="flex space-x-3 mt-6">
                <button
                  type="button"
                  onClick={fecharModal}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark disabled:opacity-50 disabled:cursor-not-allowed transition"
                >
                  <Save className="w-5 h-5" />
                  <span>{loading ? 'Salvando...' : 'Salvar'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
