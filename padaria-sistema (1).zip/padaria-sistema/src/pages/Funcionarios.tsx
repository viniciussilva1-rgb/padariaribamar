import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Plus, Search, Edit, Trash2, User, Phone, Mail, Calendar, Key, UserCheck, UserX, RotateCcw, Copy, Eye, EyeOff, RefreshCw } from 'lucide-react';
import { createClient } from '@supabase/supabase-js';

interface Funcionario {
  id: string;
  nome: string;
  email: string;
  telefone: string;
  cargo: string;
  dataAdmissao: string;
  ativo: boolean;
  createdAt?: string;
  // Campos de credenciais
  temCredenciais: boolean;
  credenciaisAtivas: boolean;
  supabaseUserId?: string;
  role: 'funcionario' | 'admin';
  senhaGerada?: string; // Apenas para mostrar após criação
}

const Funcionarios: React.FC = () => {
  const { supabaseStatus, profile } = useAuth();
  const [funcionarios, setFuncionarios] = useState<Funcionario[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [showCredentialsModal, setShowCredentialsModal] = useState(false);
  const [editingFuncionario, setEditingFuncionario] = useState<Funcionario | null>(null);
  const [newCredentials, setNewCredentials] = useState<{email: string, password: string} | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [showPassword, setShowPassword] = useState(false);

  // Cliente Supabase Admin (com service role key)
  const supabaseAdmin = createClient(
    'https://qqvmbueaxclmywrhezcr.supabase.co',
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFxdm1idWVheGNsbXl3cmhlemNyIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MTQxNDkyMywiZXhwIjoyMDc2OTkwOTIzfQ.fdLwRDGLdTTkDWJtcLd6VcmB3xrAaQvWkETlfWg3ecw'
  );

  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    telefone: '',
    cargo: 'Funcionário',
    dataAdmissao: new Date().toISOString().split('T')[0],
    // Novos campos de credenciais
    criarCredenciais: false,
    senha: '',
    gerarSenha: true,
    role: 'funcionario' as 'funcionario' | 'admin'
  });

  useEffect(() => {
    loadFuncionarios();
  }, [supabaseStatus]);

  const loadFuncionarios = async () => {
    try {
      setLoading(true);
      if (supabaseStatus === 'online') {
        // Carregar funcionários da tabela profiles do Supabase
        const { data: profiles, error } = await supabaseAdmin
          .from('profiles')
          .select('*')
          .neq('role', 'admin') // Excluir admins da lista de funcionários
          .order('created_at', { ascending: false });

        if (error) {
          console.error('Erro ao carregar funcionários do Supabase:', error);
          // Fallback para LocalStorage em caso de erro
          const stored = localStorage.getItem('funcionarios');
          if (stored) {
            setFuncionarios(JSON.parse(stored));
          }
        } else {
          // Mapear profiles para formato de funcionários
          const funcionariosMapeados: Funcionario[] = profiles.map(profile => ({
            id: profile.id,
            nome: profile.nome || 'Nome não informado',
            email: profile.email,
            telefone: profile.telefone || '',
            cargo: 'Funcionário', // Valor padrão
            dataAdmissao: new Date(profile.created_at).toISOString().split('T')[0],
            ativo: profile.ativo,
            createdAt: profile.created_at,
            // Campos de credenciais
            temCredenciais: true, // Se está na tabela profiles, tem credenciais
            credenciaisAtivas: profile.ativo,
            supabaseUserId: profile.id,
            role: profile.role
          }));

          setFuncionarios(funcionariosMapeados);
          
          // Sincronizar com LocalStorage para modo híbrido
          saveFuncionarios(funcionariosMapeados);
        }
      } else {
        // Modo offline - usar LocalStorage
        const stored = localStorage.getItem('funcionarios');
        if (stored) {
          setFuncionarios(JSON.parse(stored));
        }
      }
    } catch (error) {
      console.error('Erro ao carregar funcionários:', error);
      // Fallback para LocalStorage
      const stored = localStorage.getItem('funcionarios');
      if (stored) {
        setFuncionarios(JSON.parse(stored));
      }
    } finally {
      setLoading(false);
    }
  };

  const saveFuncionarios = (funcionariosList: Funcionario[]) => {
    localStorage.setItem('funcionarios', JSON.stringify(funcionariosList));
  };

  // Gerar senha aleatória
  const gerarSenha = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let senha = '';
    for (let i = 0; i < 8; i++) {
      senha += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return senha;
  };

  // Criar utilizador no Supabase Auth
  const criarUsuarioSupabase = async (email: string, senha: string, nome: string, role: 'funcionario' | 'admin') => {
    try {
      // 1. Criar utilizador no Auth
      const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
        email,
        password: senha,
        email_confirm: true
      });

      if (authError) throw authError;

      // 2. Criar perfil na tabela profiles
      const { error: profileError } = await supabaseAdmin
        .from('profiles')
        .insert({
          id: authData.user!.id,
          email,
          nome,
          role,
          ativo: true
        });

      if (profileError) throw profileError;

      return authData.user!.id;
    } catch (error) {
      console.error('Erro ao criar utilizador:', error);
      throw error;
    }
  };

  // Desativar credenciais do utilizador
  const desativarCredenciais = async (funcionarioId: string, supabaseUserId?: string) => {
    try {
      if (supabaseUserId && supabaseStatus === 'online') {
        // Desativar no Supabase
        await supabaseAdmin.auth.admin.updateUserById(supabaseUserId, { 
          ban_duration: '876000h' // Banir por 100 anos
        });
      }

      // Atualizar localmente
      const funcionariosAtualizados = funcionarios.map(f => 
        f.id === funcionarioId ? { ...f, credenciaisAtivas: false } : f
      );
      setFuncionarios(funcionariosAtualizados);
      saveFuncionarios(funcionariosAtualizados);
    } catch (error) {
      console.error('Erro ao desativar credenciais:', error);
      alert('Erro ao desativar credenciais: ' + (error as Error).message);
    }
  };

  // Ativar credenciais do utilizador
  const ativarCredenciais = async (funcionarioId: string, supabaseUserId?: string) => {
    try {
      if (supabaseUserId && supabaseStatus === 'online') {
        // Reativar no Supabase
        await supabaseAdmin.auth.admin.updateUserById(supabaseUserId, { 
          ban_duration: 'none'
        });
      }

      // Atualizar localmente
      const funcionariosAtualizados = funcionarios.map(f => 
        f.id === funcionarioId ? { ...f, credenciaisAtivas: true } : f
      );
      setFuncionarios(funcionariosAtualizados);
      saveFuncionarios(funcionariosAtualizados);
    } catch (error) {
      console.error('Erro ao ativar credenciais:', error);
      alert('Erro ao ativar credenciais: ' + (error as Error).message);
    }
  };

  // Resetar senha
  const resetarSenha = async (funcionarioId: string, supabaseUserId?: string) => {
    try {
      const novaSenha = gerarSenha();
      
      if (supabaseUserId && supabaseStatus === 'online') {
        // Resetar no Supabase
        await supabaseAdmin.auth.admin.updateUserById(supabaseUserId, { 
          password: novaSenha
        });
      }

      // Mostrar nova senha
      const funcionario = funcionarios.find(f => f.id === funcionarioId);
      if (funcionario) {
        setNewCredentials({ email: funcionario.email, password: novaSenha });
        setShowCredentialsModal(true);
      }
    } catch (error) {
      console.error('Erro ao resetar senha:', error);
      alert('Erro ao resetar senha: ' + (error as Error).message);
    }
  };

  // Forçar sincronização manual com Supabase
  const forcarSincronizacao = async () => {
    if (supabaseStatus === 'online') {
      setLoading(true);
      await loadFuncionarios();
      // Mostrar feedback visual de sucesso
      const originalText = document.querySelector('[data-sync-button]')?.textContent;
      const button = document.querySelector('[data-sync-button]');
      if (button) {
        button.textContent = 'Sincronizado!';
        setTimeout(() => {
          button.textContent = originalText || 'Sincronizar';
        }, 2000);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      let senhaGerada = '';
      let supabaseUserId = '';

      // Gerar ou usar senha definida
      if (formData.criarCredenciais) {
        senhaGerada = formData.gerarSenha ? gerarSenha() : formData.senha;
        
        // Criar utilizador no Supabase apenas se estivermos online e não for edição
        if (supabaseStatus === 'online' && !editingFuncionario) {
          try {
            supabaseUserId = await criarUsuarioSupabase(
              formData.email, 
              senhaGerada, 
              formData.nome, 
              formData.role
            );
          } catch (error) {
            alert('Erro ao criar credenciais: ' + (error as Error).message);
            return;
          }
        }
      }

      const novoFuncionario: Funcionario = {
        id: editingFuncionario?.id || Date.now().toString(),
        nome: formData.nome,
        email: formData.email,
        telefone: formData.telefone,
        cargo: formData.cargo,
        dataAdmissao: formData.dataAdmissao,
        ativo: true,
        createdAt: editingFuncionario?.createdAt || new Date().toISOString(),
        // Campos de credenciais
        temCredenciais: formData.criarCredenciais,
        credenciaisAtivas: formData.criarCredenciais,
        supabaseUserId: supabaseUserId || editingFuncionario?.supabaseUserId,
        role: formData.role,
        senhaGerada: formData.criarCredenciais ? senhaGerada : undefined
      };

      let funcionariosAtualizados: Funcionario[];
      
      if (editingFuncionario) {
        funcionariosAtualizados = funcionarios.map(f => 
          f.id === editingFuncionario.id ? novoFuncionario : f
        );
      } else {
        funcionariosAtualizados = [...funcionarios, novoFuncionario];
      }

      setFuncionarios(funcionariosAtualizados);
      saveFuncionarios(funcionariosAtualizados);
      
      // Se criou funcionário online, recarregar lista do Supabase para sincronizar
      if (supabaseStatus === 'online' && formData.criarCredenciais && !editingFuncionario) {
        setTimeout(() => {
          loadFuncionarios(); // Recarregar para sincronizar com Supabase
        }, 1000);
      }
      
      // Mostrar credenciais se foram criadas
      if (formData.criarCredenciais && !editingFuncionario) {
        setNewCredentials({ email: formData.email, password: senhaGerada });
        setShowCredentialsModal(true);
      }
      
      // Reset form
      setFormData({
        nome: '',
        email: '',
        telefone: '',
        cargo: 'Funcionário',
        dataAdmissao: new Date().toISOString().split('T')[0],
        criarCredenciais: false,
        senha: '',
        gerarSenha: true,
        role: 'funcionario'
      });
      setEditingFuncionario(null);
      setShowModal(false);
    } catch (error) {
      console.error('Erro ao salvar funcionário:', error);
      alert('Erro ao salvar funcionário: ' + (error as Error).message);
    }
  };

  const handleEdit = (funcionario: Funcionario) => {
    setEditingFuncionario(funcionario);
    setFormData({
      nome: funcionario.nome,
      email: funcionario.email,
      telefone: funcionario.telefone,
      cargo: funcionario.cargo,
      dataAdmissao: funcionario.dataAdmissao,
      criarCredenciais: funcionario.temCredenciais,
      senha: '',
      gerarSenha: true,
      role: funcionario.role || 'funcionario'
    });
    setShowModal(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Tem certeza que deseja excluir este funcionário?')) {
      const funcionariosAtualizados = funcionarios.filter(f => f.id !== id);
      setFuncionarios(funcionariosAtualizados);
      saveFuncionarios(funcionariosAtualizados);
    }
  };

  const toggleAtivo = (id: string) => {
    const funcionariosAtualizados = funcionarios.map(f => 
      f.id === id ? { ...f, ativo: !f.ativo } : f
    );
    setFuncionarios(funcionariosAtualizados);
    saveFuncionarios(funcionariosAtualizados);
  };

  const funcionariosFiltrados = funcionarios.filter(f =>
    f.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    f.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    f.cargo.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Funcionários</h1>
            <p className="text-gray-600">Gestão da Equipa da Padaria Ribamar</p>
          </div>
          <div className="flex gap-3">
            {supabaseStatus === 'online' && (
              <button
                onClick={forcarSincronizacao}
                disabled={loading}
                data-sync-button
                className="bg-green-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-green-700 transition-colors disabled:opacity-50"
              >
                <RefreshCw size={20} className={loading ? 'animate-spin' : ''} />
                Sincronizar
              </button>
            )}
            <button
              onClick={() => setShowModal(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 transition-colors"
            >
              <Plus size={20} />
              Novo Funcionário
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Buscar por nome, email ou cargo..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Status Info */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <div className="flex items-center gap-2 text-blue-800">
            <User size={20} />
            <span className="font-medium">
              Total de Funcionários: {funcionarios.length} | Ativos: {funcionarios.filter(f => f.ativo).length}
            </span>
            <span className={`ml-auto px-2 py-1 rounded text-sm ${
              supabaseStatus === 'online' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
            }`}>
              {supabaseStatus === 'online' ? 'Online' : 'Offline'}
            </span>
          </div>
        </div>

        {/* Funcionários Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {funcionariosFiltrados.length === 0 ? (
            <div className="col-span-full bg-white p-8 rounded-lg shadow-sm text-center">
              <User size={48} className="mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                {searchTerm ? 'Nenhum funcionário encontrado' : 'Nenhum funcionário cadastrado'}
              </h3>
              <p className="text-gray-600 mb-4">
                {searchTerm 
                  ? 'Tente ajustar os termos da busca' 
                  : 'Comece adicionando o primeiro funcionário da sua equipa'
                }
              </p>
              {!searchTerm && (
                <button
                  onClick={() => setShowModal(true)}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Adicionar Primeiro Funcionário
                </button>
              )}
            </div>
          ) : (
            funcionariosFiltrados.map((funcionario) => (
              <div key={funcionario.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <User size={24} className="text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{funcionario.nome}</h3>
                      <p className="text-sm text-gray-600">{funcionario.cargo}</p>
                    </div>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${funcionario.ativo ? 'bg-green-500' : 'bg-red-500'}`}></div>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Mail size={16} />
                    <span>{funcionario.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Phone size={16} />
                    <span>{funcionario.telefone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Calendar size={16} />
                    <span>Admitido: {new Date(funcionario.dataAdmissao).toLocaleDateString('pt-BR')}</span>
                  </div>
                  {/* Status das Credenciais */}
                  <div className="flex items-center gap-2 text-sm">
                    <Key size={16} />
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      funcionario.temCredenciais 
                        ? funcionario.credenciaisAtivas 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                        : 'bg-gray-100 text-gray-600'
                    }`}>
                      {funcionario.temCredenciais 
                        ? funcionario.credenciaisAtivas 
                          ? 'Credenciais Ativas' 
                          : 'Credenciais Inativas'
                        : 'Sem Credenciais'
                      }
                    </span>
                  </div>
                  {funcionario.role && (
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <User size={16} />
                      <span className="capitalize">{funcionario.role}</span>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  {/* Primeira linha de botões */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleEdit(funcionario)}
                      className="flex-1 bg-gray-100 text-gray-700 px-3 py-2 rounded text-sm hover:bg-gray-200 transition-colors flex items-center justify-center gap-1"
                    >
                      <Edit size={14} />
                      Editar
                    </button>
                    <button
                      onClick={() => handleDelete(funcionario.id)}
                      className="bg-red-100 text-red-700 px-3 py-2 rounded text-sm hover:bg-red-200 transition-colors flex items-center justify-center gap-1"
                    >
                      <Trash2 size={14} />
                      Excluir
                    </button>
                  </div>
                  
                  {/* Segunda linha - Gestão de Credenciais */}
                  {funcionario.temCredenciais && (
                    <div className="flex gap-2">
                      {funcionario.credenciaisAtivas ? (
                        <button
                          onClick={() => desativarCredenciais(funcionario.id, funcionario.supabaseUserId)}
                          className="flex-1 bg-red-100 text-red-700 px-3 py-2 rounded text-sm hover:bg-red-200 transition-colors flex items-center justify-center gap-1"
                        >
                          <UserX size={14} />
                          Desativar
                        </button>
                      ) : (
                        <button
                          onClick={() => ativarCredenciais(funcionario.id, funcionario.supabaseUserId)}
                          className="flex-1 bg-green-100 text-green-700 px-3 py-2 rounded text-sm hover:bg-green-200 transition-colors flex items-center justify-center gap-1"
                        >
                          <UserCheck size={14} />
                          Ativar
                        </button>
                      )}
                      <button
                        onClick={() => resetarSenha(funcionario.id, funcionario.supabaseUserId)}
                        className="bg-blue-100 text-blue-700 px-3 py-2 rounded text-sm hover:bg-blue-200 transition-colors flex items-center justify-center gap-1"
                      >
                        <RotateCcw size={14} />
                        Reset
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Modal */}
        {showModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg max-w-md w-full p-6">
              <h2 className="text-xl font-bold mb-4">
                {editingFuncionario ? 'Editar Funcionário' : 'Novo Funcionário'}
              </h2>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nome Completo
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.nome}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Nome do funcionário"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="email@exemplo.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Telefone
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.telefone}
                    onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="(98) 99999-9999"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Cargo
                  </label>
                  <select
                    value={formData.cargo}
                    onChange={(e) => setFormData({ ...formData, cargo: e.target.value })}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="Funcionário">Funcionário</option>
                    <option value="Padeiro">Padeiro</option>
                    <option value="Caixa">Caixa</option>
                    <option value="Supervisor">Supervisor</option>
                    <option value="Gerente">Gerente</option>
                    <option value="Administrador">Administrador</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Data de Admissão
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.dataAdmissao}
                    onChange={(e) => setFormData({ ...formData, dataAdmissao: e.target.value })}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* Seção de Credenciais de Acesso */}
                <div className="border-t pt-4">
                  <div className="flex items-center gap-2 mb-3">
                    <Key size={20} className="text-blue-600" />
                    <span className="font-medium text-gray-700">Credenciais de Acesso</span>
                  </div>
                  
                  {!editingFuncionario && (
                    <div className="mb-4">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.criarCredenciais}
                          onChange={(e) => setFormData({ ...formData, criarCredenciais: e.target.checked })}
                          className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                        />
                        <span className="text-sm text-gray-700">Criar credenciais de login para este funcionário</span>
                      </label>
                    </div>
                  )}

                  {(formData.criarCredenciais || editingFuncionario?.temCredenciais) && (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Tipo de Acesso
                        </label>
                        <select
                          value={formData.role}
                          onChange={(e) => setFormData({ ...formData, role: e.target.value as 'funcionario' | 'admin' })}
                          className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        >
                          <option value="funcionario">Funcionário (Acesso Limitado)</option>
                          <option value="admin">Administrador (Acesso Total)</option>
                        </select>
                      </div>

                      {!editingFuncionario && (
                        <>
                          <div>
                            <label className="flex items-center gap-2 cursor-pointer mb-2">
                              <input
                                type="checkbox"
                                checked={formData.gerarSenha}
                                onChange={(e) => setFormData({ ...formData, gerarSenha: e.target.checked })}
                                className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                              />
                              <span className="text-sm text-gray-700">Gerar senha automaticamente</span>
                            </label>
                          </div>

                          {!formData.gerarSenha && (
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">
                                Senha Personalizada
                              </label>
                              <div className="relative">
                                <input
                                  type={showPassword ? "text" : "password"}
                                  value={formData.senha}
                                  onChange={(e) => setFormData({ ...formData, senha: e.target.value })}
                                  className="w-full p-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                  placeholder="Digite uma senha"
                                  minLength={6}
                                />
                                <button
                                  type="button"
                                  onClick={() => setShowPassword(!showPassword)}
                                  className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                >
                                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                                </button>
                              </div>
                              <p className="text-xs text-gray-500 mt-1">Mínimo 6 caracteres</p>
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setShowModal(false);
                      setEditingFuncionario(null);
                      setFormData({
                        nome: '',
                        email: '',
                        telefone: '',
                        cargo: 'Funcionário',
                        dataAdmissao: new Date().toISOString().split('T')[0],
                        criarCredenciais: false,
                        senha: '',
                        gerarSenha: true,
                        role: 'funcionario'
                      });
                    }}
                    className="flex-1 bg-gray-200 text-gray-800 py-2 rounded-lg hover:bg-gray-300 transition-colors"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    {editingFuncionario ? 'Atualizar' : 'Cadastrar'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal de Credenciais Geradas */}
        {showCredentialsModal && newCredentials && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg max-w-md w-full p-6">
              <div className="text-center mb-4">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <UserCheck size={32} className="text-green-600" />
                </div>
                <h2 className="text-xl font-bold text-gray-900">Credenciais Criadas!</h2>
                <p className="text-gray-600">As credenciais de acesso foram geradas com sucesso.</p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="space-y-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email:</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={newCredentials.email}
                        readOnly
                        className="flex-1 p-2 bg-white border border-gray-300 rounded text-sm"
                      />
                      <button
                        onClick={() => navigator.clipboard.writeText(newCredentials.email)}
                        className="p-2 text-gray-500 hover:text-gray-700"
                        title="Copiar email"
                      >
                        <Copy size={16} />
                      </button>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Senha:</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={newCredentials.password}
                        readOnly
                        className="flex-1 p-2 bg-white border border-gray-300 rounded text-sm font-mono"
                      />
                      <button
                        onClick={() => navigator.clipboard.writeText(newCredentials.password)}
                        className="p-2 text-gray-500 hover:text-gray-700"
                        title="Copiar senha"
                      >
                        <Copy size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
                <p className="text-sm text-blue-800">
                  <strong>Importante:</strong> Guarde estas credenciais em local seguro. 
                  O funcionário poderá usar estes dados para fazer login no sistema.
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    const texto = `Credenciais de Acesso - Sistema Padaria Ribamar\n\nEmail: ${newCredentials.email}\nSenha: ${newCredentials.password}\n\nPara acessar: https://im7dgo3xnsza.space.minimax.io`;
                    navigator.clipboard.writeText(texto);
                    alert('Credenciais copiadas para a área de transferência!');
                  }}
                  className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                >
                  <Copy size={16} />
                  Copiar Tudo
                </button>
                <button
                  onClick={() => {
                    setShowCredentialsModal(false);
                    setNewCredentials(null);
                  }}
                  className="flex-1 bg-gray-200 text-gray-800 py-2 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Funcionarios;