import React, { useEffect, useState } from 'react'
import { supabase, type Pagamento } from '../lib/supabase'
import { CreditCard, DollarSign, CheckCircle, Clock } from 'lucide-react'

interface PagamentoComDados extends Pagamento {
  pedido?: {
    cliente_id: number
  }
  cliente?: {
    nome: string
  }
}

export default function Pagamentos() {
  const [pagamentos, setPagamentos] = useState<PagamentoComDados[]>([])
  const [loading, setLoading] = useState(true)
  const [filterStatus, setFilterStatus] = useState<string>('todos')

  useEffect(() => {
    loadPagamentos()
  }, [])

  async function loadPagamentos() {
    setLoading(true)
    try {
      const { data: pagamentosData, error } = await supabase
        .from('pagamentos')
        .select('*')
        .order('data_pagamento', { ascending: false })
        .limit(100)

      if (error) throw error

      if (pagamentosData && pagamentosData.length > 0) {
        const pedidoIds = pagamentosData.map(p => p.pedido_id)
        const { data: pedidosData } = await supabase
          .from('pedidos')
          .select('id, cliente_id')
          .in('id', pedidoIds)

        const clienteIds = pedidosData?.map(p => p.cliente_id) || []
        const { data: clientesData } = await supabase
          .from('clientes')
          .select('id, nome')
          .in('id', clienteIds)

        const pagamentosComDados = pagamentosData.map(pagamento => {
          const pedido = pedidosData?.find(p => p.id === pagamento.pedido_id)
          const cliente = clientesData?.find(c => c.id === pedido?.cliente_id)
          return { ...pagamento, pedido, cliente: { nome: cliente?.nome || 'Cliente não encontrado' } }
        })

        setPagamentos(pagamentosComDados)
      } else {
        setPagamentos([])
      }
    } catch (error) {
      console.error('Erro ao carregar pagamentos:', error)
    } finally {
      setLoading(false)
    }
  }

  const filteredPagamentos = filterStatus === 'todos'
    ? pagamentos
    : pagamentos.filter(p => p.status === filterStatus)

  const statusColors = {
    pendente: 'bg-yellow-100 text-yellow-800',
    pago: 'bg-green-100 text-green-800',
    cancelado: 'bg-red-100 text-red-800',
  }

  const statusLabels = {
    pendente: 'Pendente',
    pago: 'Pago',
    cancelado: 'Cancelado',
  }

  const metodoLabels = {
    dinheiro: 'Dinheiro',
    cartao: 'Cartão',
    pix: 'PIX',
    transferencia: 'Transferência',
  }

  const totalPago = filteredPagamentos
    .filter(p => p.status === 'pago')
    .reduce((sum, p) => sum + Number(p.valor), 0)

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Pagamentos</h1>
        <p className="text-gray-600">Gerencie os pagamentos dos clientes</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-600">Total Recebido</span>
            <DollarSign className="w-5 h-5 text-green-500" />
          </div>
          <p className="text-3xl font-bold text-gray-900">€{totalPago.toFixed(2)}</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-600">Pagamentos</span>
            <CheckCircle className="w-5 h-5 text-blue-500" />
          </div>
          <p className="text-3xl font-bold text-gray-900">{filteredPagamentos.length}</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-600">Pendentes</span>
            <Clock className="w-5 h-5 text-yellow-500" />
          </div>
          <p className="text-3xl font-bold text-gray-900">
            {pagamentos.filter(p => p.status === 'pendente').length}
          </p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-6">
        <div className="p-4 border-b border-gray-200">
          <div className="flex flex-wrap gap-2">
            {['todos', 'pendente', 'pago', 'cancelado'].map((status) => (
              <button
                key={status}
                onClick={() => setFilterStatus(status)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                  filterStatus === status
                    ? 'bg-primary text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {status === 'todos' ? 'Todos' : statusLabels[status as keyof typeof statusLabels]}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Cliente
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Pedido
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Valor
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Método
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Data
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredPagamentos.map((pagamento) => (
                <tr key={pagamento.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{pagamento.cliente?.nome}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">#{pagamento.pedido_id}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-semibold text-gray-900">€{Number(pagamento.valor).toFixed(2)}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center space-x-2">
                      <CreditCard className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-600">{metodoLabels[pagamento.metodo]}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[pagamento.status]}`}>
                      {statusLabels[pagamento.status]}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(pagamento.data_pagamento).toLocaleDateString('pt-PT')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredPagamentos.length === 0 && (
          <div className="text-center py-12">
            <CreditCard className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhum pagamento encontrado</h3>
            <p className="text-gray-600">Os pagamentos aparecerão aqui</p>
          </div>
        )}
      </div>
    </div>
  )
}
