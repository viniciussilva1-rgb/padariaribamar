import React, { useState, useEffect } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { movimentosAdapter, producaoDiariaAdapter, getSupabaseStatus, produtosStorage, type ProdutoOption } from '../lib/storage-adapter'
import { BarChart3, Save, AlertCircle, CheckCircle2, TrendingDown, Users, Package } from 'lucide-react'
import type { MovimentoEntregador, ProducaoDiaria } from '../lib/supabase'

interface ProducaoForm {
  produto: string
  qtde_produzida: number
}

interface DadosConsolidados {
  produto: string
  preco: number
  produzido: number
  levado: number
  sobras: number
  vendido: number
  quebra: number
  valorQuebra: number
}

interface DadosPorEntregador {
  entregador: string
  produtos: {
    produto: string
    levado: number
    sobras: number
    vendido: number
    valorLevado: number
    valorSobras: number
    valorVendido: number
  }[]
  totais: {
    levado: number
    sobras: number
    vendido: number
  }
}

export default function ProducaoQuebra() {
  const { profile } = useAuth()
  const [data, setData] = useState(new Date().toISOString().split('T')[0])
  const [producao, setProducao] = useState<ProducaoForm[]>([])
  const [produtosDisponiveis, setProdutosDisponiveis] = useState<ProdutoOption[]>([])
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null)
  const [visualizacao, setVisualizacao] = useState<'consolidado' | 'entregadores'>('consolidado')
  
  const [dadosConsolidados, setDadosConsolidados] = useState<DadosConsolidados[]>([])
  const [dadosPorEntregador, setDadosPorEntregador] = useState<DadosPorEntregador[]>([])
  
  const supabaseStatus = getSupabaseStatus()

  // Verificar se é admin
  const isAdmin = profile?.role === 'admin'

  useEffect(() => {
    carregarProdutosDisponiveis()
  }, [])

  useEffect(() => {
    if (produtosDisponiveis.length > 0) {
      inicializarFormulario()
      carregarDados()
    }
  }, [data, produtosDisponiveis])

  async function carregarProdutosDisponiveis() {
    try {
      const produtosDb = await produtosStorage.getAtivos()
      setProdutosDisponiveis(produtosDb)
    } catch (error) {
      console.error('Erro ao carregar produtos:', error)
      setMessage({ type: 'error', text: 'Erro ao carregar lista de produtos' })
    }
  }

  function inicializarFormulario() {
    const producaoInit = produtosDisponiveis.map(p => ({
      produto: p.nome,
      qtde_produzida: 0
    }))
    setProducao(producaoInit)
  }

  async function carregarDados() {
    if (produtosDisponiveis.length === 0) return
    
    try {
      // Carregar produção existente
      const todasProducoes = await producaoDiariaAdapter.getAll()
      const producoesDia = todasProducoes.filter(p => p.data === data)
      
      if (producoesDia.length > 0) {
        const producaoComDados = produtosDisponiveis.map(pf => {
          const prod = producoesDia.find(p => p.produto === pf.nome)
          return {
            produto: pf.nome,
            qtde_produzida: prod?.qtde_produzida || 0
          }
        })
        setProducao(producaoComDados)
      }
      
      // Carregar movimentos do dia
      const todosMovimentos = await movimentosAdapter.getAll()
      const movimentosDia = todosMovimentos.filter(m => m.data === data)
      
      // Calcular dados consolidados
      calcularDadosConsolidados(producoesDia, movimentosDia)
      
      // Calcular dados por entregador
      calcularDadosPorEntregador(movimentosDia)
      
    } catch (error) {
      console.error('Erro ao carregar dados:', error)
    }
  }

  function calcularDadosConsolidados(producoesDia: ProducaoDiaria[], movimentosDia: MovimentoEntregador[]) {
    const consolidados = produtosDisponiveis.map(pf => {
      const prod = producoesDia.find(p => p.produto === pf.nome)
      const produzido = prod?.qtde_produzida || 0
      
      // Somar todos os movimentos deste produto
      const movsDesteProduto = movimentosDia.filter(m => m.produto === pf.nome)
      const levado = movsDesteProduto.reduce((sum, m) => sum + m.qtde_levada, 0)
      const sobras = movsDesteProduto.reduce((sum, m) => sum + m.qtde_sobra, 0)
      const vendido = levado - sobras
      
      // Calcular quebra
      const quebra = produzido - (vendido + sobras)
      const valorQuebra = quebra * pf.preco_padrao
      
      return {
        produto: pf.nome,
        preco: pf.preco_padrao,
        produzido,
        levado,
        sobras,
        vendido,
        quebra,
        valorQuebra
      }
    })
    
    setDadosConsolidados(consolidados)
  }

  function calcularDadosPorEntregador(movimentosDia: MovimentoEntregador[]) {
    // Agrupar por entregador
    const entregadoresMap = new Map<string, MovimentoEntregador[]>()
    
    movimentosDia.forEach(m => {
      if (!entregadoresMap.has(m.entregador_email)) {
        entregadoresMap.set(m.entregador_email, [])
      }
      entregadoresMap.get(m.entregador_email)!.push(m)
    })
    
    const dadosEntregadores: DadosPorEntregador[] = []
    
    entregadoresMap.forEach((movimentos, email) => {
      const produtos = movimentos.map(m => {
        const valorLevado = m.qtde_levada * m.preco_unitario
        const valorSobras = m.qtde_sobra * m.preco_unitario
        const valorVendido = valorLevado - valorSobras
        
        return {
          produto: m.produto,
          levado: m.qtde_levada,
          sobras: m.qtde_sobra,
          vendido: m.qtde_levada - m.qtde_sobra,
          valorLevado,
          valorSobras,
          valorVendido
        }
      })
      
      const totais = produtos.reduce((acc, p) => ({
        levado: acc.levado + p.valorLevado,
        sobras: acc.sobras + p.valorSobras,
        vendido: acc.vendido + p.valorVendido
      }), { levado: 0, sobras: 0, vendido: 0 })
      
      dadosEntregadores.push({
        entregador: email,
        produtos,
        totais
      })
    })
    
    setDadosPorEntregador(dadosEntregadores)
  }

  function handleProducaoChange(index: number, value: string) {
    const newProducao = [...producao]
    newProducao[index].qtde_produzida = parseInt(value) || 0
    setProducao(newProducao)
  }

  async function handleSubmitProducao(e: React.FormEvent) {
    e.preventDefault()
    
    if (!isAdmin) {
      setMessage({ type: 'error', text: 'Apenas administradores podem registar produção' })
      return
    }

    const temProducao = producao.some(p => p.qtde_produzida > 0)
    if (!temProducao) {
      setMessage({ type: 'error', text: 'Registre pelo menos um produto com quantidade produzida' })
      return
    }

    setLoading(true)
    setMessage(null)

    try {
      // Deletar registos antigos para esta data
      const todasProducoes = await producaoDiariaAdapter.getAll()
      const producoesDia = todasProducoes.filter(p => p.data === data)
      
      for (const prod of producoesDia) {
        await producaoDiariaAdapter.delete(prod.id)
      }

      // Salvar apenas produtos com quantidade
      const produtosParaSalvar = producao.filter(p => p.qtde_produzida > 0)
      
      for (const p of produtosParaSalvar) {
        await producaoDiariaAdapter.create({
          data,
          produto: p.produto,
          qtde_produzida: p.qtde_produzida
        })
      }

      setMessage({ 
        type: 'success', 
        text: `Produção registada com sucesso! ${produtosParaSalvar.length} produtos salvos.` 
      })
      
      // Recarregar dados
      await carregarDados()
    } catch (error: any) {
      console.error('Erro ao salvar:', error)
      setMessage({ 
        type: 'error', 
        text: error.message || 'Erro ao salvar. Tente novamente.' 
      })
    } finally {
      setLoading(false)
    }
  }

  // Calcular totais consolidados
  const totaisConsolidados = dadosConsolidados.reduce((acc, d) => ({
    produzido: acc.produzido + d.produzido,
    levado: acc.levado + d.levado,
    sobras: acc.sobras + d.sobras,
    vendido: acc.vendido + d.vendido,
    quebra: acc.quebra + d.quebra,
    valorQuebra: acc.valorQuebra + d.valorQuebra
  }), { produzido: 0, levado: 0, sobras: 0, vendido: 0, quebra: 0, valorQuebra: 0 })

  if (!isAdmin) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
          <AlertCircle className="w-12 h-12 text-red-600 mx-auto mb-3" />
          <h2 className="text-xl font-bold text-red-900 mb-2">Acesso Restrito</h2>
          <p className="text-red-700">Esta página é apenas para administradores.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-primary rounded-lg">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Produção e Quebra do Dia</h1>
              <p className="text-sm text-gray-500">Gestão de produção e análise de quebra</p>
            </div>
          </div>
          {supabaseStatus === 'offline' && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg px-3 py-2">
              <p className="text-xs text-yellow-800">Modo Offline</p>
            </div>
          )}
        </div>

        {/* Seletor de Data */}
        <div className="mt-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Data
          </label>
          <input
            type="date"
            value={data}
            onChange={(e) => setData(e.target.value)}
            className="w-full md:w-64 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
          />
        </div>
      </div>

      {/* Cards de Resumo - Nova seção */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Produzido */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="bg-blue-100 p-2 rounded-lg">
              <Package className="w-5 h-5 text-blue-600" />
            </div>
          </div>
          <h3 className="text-gray-600 text-sm font-medium mb-1">Total Produzido</h3>
          <p className="text-2xl font-bold text-gray-900">{totaisConsolidados.produzido}</p>
          <p className="text-xs text-gray-500 mt-1">unidades</p>
        </div>

        {/* Card 2: Total Levado */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="bg-purple-100 p-2 rounded-lg">
              <Package className="w-5 h-5 text-purple-600" />
            </div>
          </div>
          <h3 className="text-gray-600 text-sm font-medium mb-1">Total Levado</h3>
          <p className="text-2xl font-bold text-gray-900">{totaisConsolidados.levado}</p>
          <p className="text-xs text-gray-500 mt-1">unidades pelos entregadores</p>
        </div>

        {/* Card 3: Total Vendido */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="bg-green-100 p-2 rounded-lg">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
            </div>
          </div>
          <h3 className="text-gray-600 text-sm font-medium mb-1">Total Vendido</h3>
          <p className="text-2xl font-bold text-gray-900">{totaisConsolidados.vendido}</p>
          <p className="text-xs text-green-600 mt-1">unidades</p>
        </div>

        {/* Card 4: Quebra Total */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="bg-red-100 p-2 rounded-lg">
              <TrendingDown className="w-5 h-5 text-red-600" />
            </div>
          </div>
          <h3 className="text-gray-600 text-sm font-medium mb-1">Quebra Total</h3>
          <p className="text-2xl font-bold text-red-600">{totaisConsolidados.quebra}</p>
          <p className="text-xs text-red-600 mt-1">{totaisConsolidados.valorQuebra.toFixed(2)} EUR em perdas</p>
        </div>
      </div>

      {/* Alerta de Quebra Alta */}
      {totaisConsolidados.quebra > 10 && (
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-orange-900">Quebra Acima do Normal</p>
              <p className="text-xs text-orange-700 mt-1">
                A quebra de {totaisConsolidados.quebra} unidades ({totaisConsolidados.valorQuebra.toFixed(2)} EUR) está acima do esperado. 
                Recomenda-se revisar a produção ou distribuição.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Formulário de Produção */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Package className="w-5 h-5 text-primary" />
          <h2 className="text-lg font-bold text-gray-900">Registar Produção Diária</h2>
        </div>

        {message && (
          <div className={`mb-4 p-4 rounded-lg flex items-start space-x-3 ${
            message.type === 'success' 
              ? 'bg-green-50 border border-green-200' 
              : 'bg-red-50 border border-red-200'
          }`}>
            {message.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            )}
            <p className={`text-sm ${
              message.type === 'success' ? 'text-green-800' : 'text-red-800'
            }`}>
              {message.text}
            </p>
          </div>
        )}

        <form onSubmit={handleSubmitProducao}>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-6">
            {producao.map((p, index) => (
              <div key={p.produto}>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {p.produto}
                </label>
                <input
                  type="number"
                  min="0"
                  value={p.qtde_produzida || ''}
                  onChange={(e) => handleProducaoChange(index, e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-right focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="0"
                />
              </div>
            ))}
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={loading}
              className="flex items-center space-x-2 px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary-dark disabled:opacity-50 disabled:cursor-not-allowed transition font-medium"
            >
              <Save className="w-5 h-5" />
              <span>{loading ? 'A guardar...' : 'Guardar Produção'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Tabs de Visualização */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <div className="flex space-x-1 p-2">
            <button
              onClick={() => setVisualizacao('consolidado')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition ${
                visualizacao === 'consolidado'
                  ? 'bg-primary text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <TrendingDown className="w-4 h-4" />
              <span className="font-medium">Visão Consolidada</span>
            </button>
            <button
              onClick={() => setVisualizacao('entregadores')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition ${
                visualizacao === 'entregadores'
                  ? 'bg-primary text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Users className="w-4 h-4" />
              <span className="font-medium">Por Entregador</span>
            </button>
          </div>
        </div>

        <div className="p-6">
          {visualizacao === 'consolidado' ? (
            <div>
              <h3 className="text-lg font-bold text-gray-900 mb-4">Análise Consolidada por Produto</h3>
              
              {/* Tabela Desktop */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Produto</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Produzido</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Levado</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Sobras</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Vendido</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Quebra</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Valor Quebra</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {dadosConsolidados.map(d => (
                      <tr key={d.produto} className="hover:bg-gray-50">
                        <td className="px-4 py-3 text-sm font-medium text-gray-900">{d.produto}</td>
                        <td className="px-4 py-3 text-sm text-gray-700 text-right">{d.produzido}</td>
                        <td className="px-4 py-3 text-sm text-blue-600 text-right">{d.levado}</td>
                        <td className="px-4 py-3 text-sm text-orange-600 text-right">{d.sobras}</td>
                        <td className="px-4 py-3 text-sm text-green-600 text-right font-medium">{d.vendido}</td>
                        <td className="px-4 py-3 text-sm text-red-600 text-right font-bold">{d.quebra}</td>
                        <td className="px-4 py-3 text-sm text-red-600 text-right font-bold">{d.valorQuebra.toFixed(2)} EUR</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-gray-50 border-t-2 border-gray-300">
                    <tr>
                      <td className="px-4 py-3 text-sm font-bold text-gray-900">TOTAIS:</td>
                      <td className="px-4 py-3 text-sm font-bold text-gray-900 text-right">{totaisConsolidados.produzido}</td>
                      <td className="px-4 py-3 text-sm font-bold text-blue-600 text-right">{totaisConsolidados.levado}</td>
                      <td className="px-4 py-3 text-sm font-bold text-orange-600 text-right">{totaisConsolidados.sobras}</td>
                      <td className="px-4 py-3 text-sm font-bold text-green-600 text-right">{totaisConsolidados.vendido}</td>
                      <td className="px-4 py-3 text-sm font-bold text-red-600 text-right">{totaisConsolidados.quebra}</td>
                      <td className="px-4 py-3 text-sm font-bold text-red-600 text-right">{totaisConsolidados.valorQuebra.toFixed(2)} EUR</td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Cards Mobile */}
              <div className="md:hidden space-y-3">
                {dadosConsolidados.filter(d => d.produzido > 0 || d.levado > 0).map(d => (
                  <div key={d.produto} className="border border-gray-200 rounded-lg p-4">
                    <h4 className="font-semibold text-gray-900 mb-2">{d.produto}</h4>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <span className="text-gray-500">Produzido:</span>
                        <span className="ml-2 font-medium">{d.produzido}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">Levado:</span>
                        <span className="ml-2 font-medium text-blue-600">{d.levado}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">Sobras:</span>
                        <span className="ml-2 font-medium text-orange-600">{d.sobras}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">Vendido:</span>
                        <span className="ml-2 font-medium text-green-600">{d.vendido}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">Quebra:</span>
                        <span className="ml-2 font-bold text-red-600">{d.quebra}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">Valor:</span>
                        <span className="ml-2 font-bold text-red-600">{d.valorQuebra.toFixed(2)} EUR</span>
                      </div>
                    </div>
                  </div>
                ))}
                
                {/* Totais Mobile */}
                <div className="border-2 border-red-500 rounded-lg p-4 bg-red-50">
                  <h4 className="font-bold text-gray-900 mb-2">TOTAIS</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>Total Quebra:</span>
                      <span className="font-bold text-red-600">{totaisConsolidados.quebra}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Valor da Quebra:</span>
                      <span className="font-bold text-red-600">{totaisConsolidados.valorQuebra.toFixed(2)} EUR</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div>
              <h3 className="text-lg font-bold text-gray-900 mb-4">Dados por Entregador</h3>
              
              {dadosPorEntregador.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  Nenhum registo de entregadores para esta data
                </div>
              ) : (
                <div className="space-y-6">
                  {dadosPorEntregador.map((ent, idx) => (
                    <div key={idx} className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="font-bold text-gray-900">{ent.entregador}</h4>
                        <div className="text-right">
                          <p className="text-sm text-gray-500">Total Vendido</p>
                          <p className="text-lg font-bold text-green-600">{ent.totais.vendido.toFixed(2)} EUR</p>
                        </div>
                      </div>
                      
                      {/* Tabela de produtos do entregador */}
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead className="bg-white border-b border-gray-300">
                            <tr>
                              <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Produto</th>
                              <th className="px-3 py-2 text-right text-xs font-medium text-gray-500">Levado</th>
                              <th className="px-3 py-2 text-right text-xs font-medium text-gray-500">Sobras</th>
                              <th className="px-3 py-2 text-right text-xs font-medium text-gray-500">Vendido</th>
                              <th className="px-3 py-2 text-right text-xs font-medium text-gray-500">Valor</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-200">
                            {ent.produtos.map((p, i) => (
                              <tr key={i}>
                                <td className="px-3 py-2 text-gray-900">{p.produto}</td>
                                <td className="px-3 py-2 text-right text-gray-700">{p.levado}</td>
                                <td className="px-3 py-2 text-right text-orange-600">{p.sobras}</td>
                                <td className="px-3 py-2 text-right text-green-600 font-medium">{p.vendido}</td>
                                <td className="px-3 py-2 text-right text-green-600 font-bold">{p.valorVendido.toFixed(2)} EUR</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      
                      {/* Resumo do entregador */}
                      <div className="mt-3 pt-3 border-t border-gray-300 grid grid-cols-3 gap-4 text-center">
                        <div>
                          <p className="text-xs text-gray-500">Total Levado</p>
                          <p className="font-bold text-gray-900">{ent.totais.levado.toFixed(2)} EUR</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Total Sobras</p>
                          <p className="font-bold text-orange-600">{ent.totais.sobras.toFixed(2)} EUR</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Total Vendido</p>
                          <p className="font-bold text-green-600">{ent.totais.vendido.toFixed(2)} EUR</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
