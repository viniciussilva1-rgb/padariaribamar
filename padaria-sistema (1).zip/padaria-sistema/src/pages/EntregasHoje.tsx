import React, { useEffect, useState } from 'react'
import { supabase, type Entrega } from '../lib/supabase'
import { Truck, Clock, CheckCircle, XCircle, MapPin } from 'lucide-react'

interface EntregaComDados extends Entrega {
  pedido?: {
    id: number
    cliente_id: number
  }
  cliente?: {
    nome: string
    endereco?: string
    telefone?: string
  }
}

export default function EntregasHoje() {
  const [entregas, setEntregas] = useState<EntregaComDados[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadEntregas()
  }, [])

  async function loadEntregas() {
    setLoading(true)
    try {
      const hoje = new Date().toISOString().split('T')[0]

      const { data: entregasData, error } = await supabase
        .from('entregas')
        .select('*')
        .eq('data_entrega', hoje)
        .order('hora_entrega', { ascending: true })

      if (error) throw error

      if (entregasData && entregasData.length > 0) {
        const pedidoIds = entregasData.map(e => e.pedido_id)
        const { data: pedidosData } = await supabase
          .from('pedidos')
          .select('id, cliente_id')
          .in('id', pedidoIds)

        const clienteIds = pedidosData?.map(p => p.cliente_id) || []
        const { data: clientesData } = await supabase
          .from('clientes')
          .select('id, nome, endereco, telefone')
          .in('id', clienteIds)

        const entregasComDados = entregasData.map(entrega => {
          const pedido = pedidosData?.find(p => p.id === entrega.pedido_id)
          const cliente = clientesData?.find(c => c.id === pedido?.cliente_id)
          return { ...entrega, pedido, cliente: { nome: cliente?.nome || 'Cliente não encontrado', endereco: cliente?.endereco, telefone: cliente?.telefone } }
        })

        setEntregas(entregasComDados)
      } else {
        setEntregas([])
      }
    } catch (error) {
      console.error('Erro ao carregar entregas:', error)
    } finally {
      setLoading(false)
    }
  }

  async function updateStatus(id: number, status: string) {
    try {
      const { error } = await supabase
        .from('entregas')
        .update({ status, updated_at: new Date().toISOString() })
        .eq('id', id)

      if (error) throw error
      loadEntregas()
    } catch (error) {
      console.error('Erro ao atualizar status:', error)
      alert('Erro ao atualizar status.')
    }
  }

  const statusColors = {
    pendente: 'bg-yellow-100 text-yellow-800',
    em_rota: 'bg-blue-100 text-blue-800',
    entregue: 'bg-green-100 text-green-800',
    cancelada: 'bg-red-100 text-red-800',
  }

  const statusLabels = {
    pendente: 'Pendente',
    em_rota: 'Em Rota',
    entregue: 'Entregue',
    cancelada: 'Cancelada',
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Entregas de Hoje</h1>
        <p className="text-gray-600">{entregas.length} entregas agendadas</p>
      </div>

      {entregas.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl border border-gray-200">
          <Truck className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhuma entrega para hoje</h3>
          <p className="text-gray-600">As entregas aparecer  aqui quando forem agendadas</p>
        </div>
      ) : (
        <div className="space-y-4">
          {entregas.map((entrega) => (
            <div key={entrega.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                <div className="flex items-center space-x-4 mb-4 md:mb-0">
                  <div className="p-3 bg-primary-100 rounded-lg">
                    <Truck className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{entrega.cliente?.nome}</h3>
                    <p className="text-sm text-gray-500">Pedido #{entrega.pedido_id}</p>
                  </div>
                </div>
                <span className={`px-4 py-2 rounded-full text-sm font-medium ${statusColors[entrega.status]}`}>
                  {statusLabels[entrega.status]}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                {entrega.hora_entrega && (
                  <div className="flex items-center space-x-2 text-gray-600">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm">Horário: {entrega.hora_entrega}</span>
                  </div>
                )}
                {entrega.cliente?.endereco && (
                  <div className="flex items-start space-x-2 text-gray-600">
                    <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <span className="text-sm">{entrega.cliente.endereco}</span>
                  </div>
                )}
              </div>

              {entrega.observacoes && (
                <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-600">{entrega.observacoes}</p>
                </div>
              )}

              <div className="flex flex-wrap gap-2">
                {entrega.status === 'pendente' && (
                  <button
                    onClick={() => updateStatus(entrega.id, 'em_rota')}
                    className="flex items-center space-x-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition text-sm"
                  >
                    <Truck className="w-4 h-4" />
                    <span>Iniciar Rota</span>
                  </button>
                )}
                {entrega.status === 'em_rota' && (
                  <button
                    onClick={() => updateStatus(entrega.id, 'entregue')}
                    className="flex items-center space-x-2 px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg transition text-sm"
                  >
                    <CheckCircle className="w-4 h-4" />
                    <span>Marcar como Entregue</span>
                  </button>
                )}
                {entrega.status !== 'cancelada' && entrega.status !== 'entregue' && (
                  <button
                    onClick={() => updateStatus(entrega.id, 'cancelada')}
                    className="flex items-center space-x-2 px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition text-sm"
                  >
                    <XCircle className="w-4 h-4" />
                    <span>Cancelar</span>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
