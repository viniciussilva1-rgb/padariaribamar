// Adaptador híbrido: Supabase + LocalStorage
// Detecta automaticamente qual usar e fornece interface unificada

import { supabase, type Profile, type Cliente, type Produto, type Pedido, type Entrega, type Pagamento, type MovimentoEntregador, type ProducaoDiaria, type ClienteComPagamento } from './supabase'

const STORAGE_KEYS = {
  PROFILES: 'padaria_profiles',
  CLIENTES: 'padaria_clientes',
  CLIENTES_PAGAMENTO: 'padaria_clientes_pagamento',
  PRODUTOS: 'padaria_produtos',
  PEDIDOS: 'padaria_pedidos',
  ENTREGAS: 'padaria_entregas',
  PAGAMENTOS: 'padaria_pagamentos',
  MOVIMENTOS: 'padaria_movimentos_entregador',
  PRODUCAO: 'padaria_producao_diaria',
  CURRENT_USER: 'padaria_current_user',
  SUPABASE_STATUS: 'padaria_supabase_status',
  LAST_SYNC: 'padaria_last_sync'
}

export type SupabaseStatus = 'online' | 'offline' | 'checking'

// Estado global do sistema
let currentStatus: SupabaseStatus = 'checking'
let statusListeners: Array<(status: SupabaseStatus) => void> = []

// Testar conexão com Supabase e inicializar sistema
export async function testSupabaseConnection(): Promise<boolean> {
  try {
    console.log('Testando conexão com Supabase...')
    
    const { error } = await Promise.race([
      supabase.from('profiles').select('count').limit(1),
      new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 5000))
    ]) as any
    
    const isOnline = !error
    console.log(`Supabase status: ${isOnline ? 'ONLINE' : 'OFFLINE'}`)
    
    if (isOnline) {
      // Se está online, inicializar sistema automaticamente
      await initializeAdminUserIfNeeded()
    }
    
    updateStatus(isOnline ? 'online' : 'offline')
    return isOnline
  } catch (error) {
    console.log('Supabase OFFLINE - usando LocalStorage')
    updateStatus('offline')
    return false
  }
}

// Inicializar usuário admin automaticamente se necessário
async function initializeAdminUserIfNeeded(): Promise<void> {
  try {
    console.log('Verificando se usuário admin existe...')
    
    const adminEmail = 'viniciussiuva1@gmail.com'
    
    // Verificar se perfil admin já existe
    const { data: existingProfile } = await supabase
      .from('profiles')
      .select('*')
      .eq('email', adminEmail)
      .maybeSingle()
    
    if (existingProfile) {
      console.log('Usuário admin já existe - sistema pronto!')
      return
    }
    
    console.log('Usuário admin não encontrado - chamando edge function de inicialização...')
    
    // Chamar edge function para inicializar admin
    const { data, error } = await supabase.functions.invoke('init-admin', {
      body: {}
    })
    
    if (error) {
      console.warn('Erro ao inicializar admin via edge function:', error)
      // Continuar - sistema pode funcionar sem isso
    } else {
      console.log('Sistema inicializado com sucesso:', data)
    }
    
  } catch (error) {
    console.warn('Erro na inicialização automática do admin:', error)
    // Não falhar - sistema deve continuar funcionando
  }
}

function updateStatus(status: SupabaseStatus) {
  currentStatus = status
  localStorage.setItem(STORAGE_KEYS.SUPABASE_STATUS, status)
  statusListeners.forEach(listener => listener(status))
}

export function getSupabaseStatus(): SupabaseStatus {
  return currentStatus
}

export function onStatusChange(listener: (status: SupabaseStatus) => void) {
  statusListeners.push(listener)
  return () => {
    statusListeners = statusListeners.filter(l => l !== listener)
  }
}

// LocalStorage helpers
function getFromLocalStorage<T>(key: string): T[] {
  const data = localStorage.getItem(key)
  return data ? JSON.parse(data) : []
}

function saveToLocalStorage<T>(key: string, data: T[]) {
  localStorage.setItem(key, JSON.stringify(data))
}

// Autenticação Híbrida
export const authAdapter = {
  async signIn(email: string, password: string): Promise<{ user: any, profile: Profile | null }> {
    const isOnline = await testSupabaseConnection()
    
    if (isOnline) {
      // Modo Supabase
      const { data, error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) throw error
      
      // Carregar perfil
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', data.user!.id)
        .maybeSingle()
      
      return { user: data.user, profile }
    } else {
      // Modo LocalStorage
      const profiles = getFromLocalStorage<Profile>(STORAGE_KEYS.PROFILES)
      
      // Verificar credenciais do admin
      const ADMIN_EMAIL = 'viniciussiuva1@gmail.com'
      const ADMIN_PASSWORD = 'Padariaribamar2025Cvs'
      
      if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
        // Criar/atualizar perfil do admin
        let adminProfile = profiles.find(p => p.email === ADMIN_EMAIL)
        
        if (!adminProfile) {
          adminProfile = {
            id: 'admin-local-001',
            email: ADMIN_EMAIL,
            nome: 'Administrador',
            role: 'admin',
            ativo: true,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          }
          profiles.push(adminProfile)
          saveToLocalStorage(STORAGE_KEYS.PROFILES, profiles)
        }
        
        // Simular objeto user
        const user = {
          id: adminProfile.id,
          email: adminProfile.email,
          created_at: adminProfile.created_at
        }
        
        localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify({ user, profile: adminProfile }))
        return { user, profile: adminProfile }
      } else {
        throw new Error('Credenciais inválidas. Em modo offline, apenas o administrador pode fazer login.')
      }
    }
  },

  async signOut(): Promise<void> {
    if (currentStatus === 'online') {
      await supabase.auth.signOut()
    }
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER)
  },

  async getUser(): Promise<{ user: any, profile: Profile | null }> {
    if (currentStatus === 'online') {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return { user: null, profile: null }
      
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .maybeSingle()
      
      return { user, profile }
    } else {
      const data = localStorage.getItem(STORAGE_KEYS.CURRENT_USER)
      if (!data) return { user: null, profile: null }
      return JSON.parse(data)
    }
  }
}

// Adaptador genérico para CRUD
export function createCRUDAdapter<T extends { id: number | string }>(
  tableName: string,
  storageKey: string
) {
  return {
    async getAll(): Promise<T[]> {
      if (currentStatus === 'online') {
        const { data, error } = await supabase.from(tableName).select('*').order('created_at', { ascending: false })
        if (error) throw error
        return data || []
      } else {
        return getFromLocalStorage<T>(storageKey)
      }
    },

    async getById(id: number | string): Promise<T | null> {
      if (currentStatus === 'online') {
        const { data, error } = await supabase.from(tableName).select('*').eq('id', id).maybeSingle()
        if (error) throw error
        return data
      } else {
        const items = getFromLocalStorage<T>(storageKey)
        return items.find(item => item.id === id) || null
      }
    },

    async create(item: Omit<T, 'id' | 'created_at' | 'updated_at'>): Promise<T> {
      if (currentStatus === 'online') {
        const { data, error } = await supabase.from(tableName).insert([item]).select().single()
        if (error) throw error
        return data
      } else {
        const items = getFromLocalStorage<T>(storageKey)
        const newItem: any = {
          ...item,
          id: Date.now(),
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }
        items.unshift(newItem)
        saveToLocalStorage(storageKey, items)
        return newItem as T
      }
    },

    async update(id: number | string, updates: Partial<T>): Promise<T> {
      if (currentStatus === 'online') {
        const { data, error } = await supabase
          .from(tableName)
          .update({ ...updates, updated_at: new Date().toISOString() })
          .eq('id', id)
          .select()
          .single()
        if (error) throw error
        return data
      } else {
        const items = getFromLocalStorage<T>(storageKey)
        const index = items.findIndex(item => item.id === id)
        if (index === -1) throw new Error('Item não encontrado')
        
        items[index] = {
          ...items[index],
          ...updates,
          updated_at: new Date().toISOString()
        }
        saveToLocalStorage(storageKey, items)
        return items[index]
      }
    },

    async delete(id: number | string): Promise<void> {
      if (currentStatus === 'online') {
        const { error } = await supabase.from(tableName).delete().eq('id', id)
        if (error) throw error
      } else {
        const items = getFromLocalStorage<T>(storageKey)
        const filtered = items.filter(item => item.id !== id)
        saveToLocalStorage(storageKey, filtered)
      }
    }
  }
}

// Adaptadores específicos para cada entidade
export const clientesAdapter = createCRUDAdapter<Cliente>('clientes', STORAGE_KEYS.CLIENTES)
export const clientesComPagamentoAdapter = createCRUDAdapter<ClienteComPagamento>('clientes', STORAGE_KEYS.CLIENTES_PAGAMENTO)
export const produtosAdapter = createCRUDAdapter<Produto>('produtos', STORAGE_KEYS.PRODUTOS)
export const pedidosAdapter = createCRUDAdapter<Pedido>('pedidos', STORAGE_KEYS.PEDIDOS)
export const entregasAdapter = createCRUDAdapter<Entrega>('entregas', STORAGE_KEYS.ENTREGAS)
export const pagamentosAdapter = createCRUDAdapter<Pagamento>('pagamentos', STORAGE_KEYS.PAGAMENTOS)
export const movimentosAdapter = createCRUDAdapter<MovimentoEntregador>('movimentos_entregador', STORAGE_KEYS.MOVIMENTOS)
export const producaoDiariaAdapter = createCRUDAdapter<ProducaoDiaria>('producao_diaria', STORAGE_KEYS.PRODUCAO)

// Inicializar dados de exemplo se estiver vazio (apenas LocalStorage)
export function initializeSampleData() {
  if (currentStatus !== 'offline') return
  
  const clientes = getFromLocalStorage<Cliente>(STORAGE_KEYS.CLIENTES)
  if (clientes.length === 0) {
    const sampleClientes: Cliente[] = [
      {
        id: 1,
        nome: 'Maria Silva',
        telefone: '98912345678',
        email: 'maria@email.com',
        endereco: 'Rua das Flores, 123',
        bairro: 'Centro',
        ativo: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: 2,
        nome: 'João Santos',
        telefone: '98987654321',
        endereco: 'Av. Principal, 456',
        bairro: 'São Francisco',
        ativo: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }
    ]
    saveToLocalStorage(STORAGE_KEYS.CLIENTES, sampleClientes)
  }
  
  const produtos = getFromLocalStorage<Produto>(STORAGE_KEYS.PRODUTOS)
  if (produtos.length === 0) {
    const sampleProdutos: Produto[] = [
      {
        id: 1,
        nome: 'Pão Francês',
        categoria: 'Pães',
        preco: 0.50,
        estoque: 200,
        unidade: 'unidade',
        ativo: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: 2,
        nome: 'Pão de Forma',
        categoria: 'Pães',
        preco: 8.50,
        estoque: 50,
        unidade: 'pacote',
        ativo: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: 3,
        nome: 'Bolo de Chocolate',
        categoria: 'Bolos',
        preco: 35.00,
        estoque: 10,
        unidade: 'unidade',
        ativo: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }
    ]
    saveToLocalStorage(STORAGE_KEYS.PRODUTOS, sampleProdutos)
  }
}

// Sincronização (para quando Supabase voltar)
export async function syncLocalToSupabase(): Promise<void> {
  if (currentStatus !== 'online') {
    throw new Error('Supabase não está disponível para sincronização')
  }
  
  // Sincronizar clientes
  const clientes = getFromLocalStorage<Cliente>(STORAGE_KEYS.CLIENTES)
  for (const cliente of clientes) {
    const { id, created_at, updated_at, ...data } = cliente
    await supabase.from('clientes').upsert([{ ...data, id }])
  }
  
  // Sincronizar produtos
  const produtos = getFromLocalStorage<Produto>(STORAGE_KEYS.PRODUTOS)
  for (const produto of produtos) {
    const { id, created_at, updated_at, ...data } = produto
    await supabase.from('produtos').upsert([{ ...data, id }])
  }
  
  localStorage.setItem(STORAGE_KEYS.LAST_SYNC, new Date().toISOString())
}

// Export produtosStorage para uso em componentes
export { produtosStorage, type ProdutoOption } from './supabase'
