import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://qqvmbueaxclmywrhezcr.supabase.co'
// Chave anon correta obtida da API
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFxdm1idWVheGNsbXl3cmhlemNyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE0MTQ5MjMsImV4cCI6MjA3Njk5MDkyM30.InoszkJ5tUkjvvVerFleLGVzRvMs1AgDHm19q5FKwP4'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export interface Profile {
  id: string
  email: string
  nome: string
  role: 'admin' | 'funcionario'
  telefone?: string
  ativo: boolean
  created_at: string
  updated_at: string
}

export interface Cliente {
  id: number
  nome: string
  telefone?: string
  email?: string
  endereco?: string
  bairro?: string
  referencia?: string
  observacoes?: string
  ativo: boolean
  created_at: string
  updated_at: string
  created_by?: string
}

export interface Produto {
  id: number
  nome: string
  categoria?: string
  preco: number
  estoque: number
  unidade: string
  ativo: boolean
  created_at: string
  updated_at: string
}

export interface Pedido {
  id: number
  cliente_id: number
  data_pedido: string
  status: 'pendente' | 'preparacao' | 'pronto' | 'entregue' | 'cancelado'
  observacoes?: string
  valor_total: number
  created_by?: string
  created_at: string
  updated_at: string
}

export interface PedidoItem {
  id: number
  pedido_id: number
  produto_id: number
  quantidade: number
  preco_unitario: number
  subtotal: number
  created_at: string
}

export interface Entrega {
  id: number
  pedido_id: number
  data_entrega: string
  hora_entrega?: string
  status: 'pendente' | 'em_rota' | 'entregue' | 'cancelada'
  funcionario_id?: string
  observacoes?: string
  created_at: string
  updated_at: string
}

export interface Pagamento {
  id: number
  pedido_id: number
  valor: number
  data_pagamento: string
  metodo: 'dinheiro' | 'cartao' | 'pix' | 'transferencia'
  status: 'pendente' | 'pago' | 'cancelado'
  funcionario_id?: string
  observacoes?: string
  created_at: string
  updated_at: string
}

export interface MovimentoEntregador {
  id: number
  data: string
  entregador_email: string
  funcionario_id?: string
  produto: string
  qtde_levada: number
  qtde_sobra: number
  preco_unitario: number
  qtde_vendida?: number
  valor_levado?: number
  valor_sobra?: number
  valor_vendido?: number
  created_at: string
  updated_at: string
}

export interface ProducaoDiaria {
  id: number
  data: string
  produto: string
  qtde_produzida: number
  created_at: string
  updated_at: string
}

export interface ClienteComPagamento {
  id: string
  nome: string
  telefone?: string
  morada?: string
  funcionario_id?: string
  data_pagamento_atual?: string
  ultimo_pagamento?: string
  pago_ate?: string
  status_pagamento: 'Em dia' | 'Pendente' | 'Vencido'
  ativo: boolean
  latitude?: number
  longitude?: number
  frequencia_pagamento: 'DIARIO' | 'SEMANAL' | 'MENSAL' | 'PERSONALIZADO'
  dias_entrega: string[]
  produtos_padrao: { produto_id: string; produto_nome?: string; quantidade: number }[]
  ferias_inicio?: string
  ferias_fim?: string
  observacoes?: string
  created_at: string
  updated_at: string
}

export interface PagamentoRegistro {
  id: string
  cliente_id: string
  funcionario_id: string
  data_pagamento: string
  valor: number
  metodo: 'Dinheiro' | 'Cartao' | 'PIX' | 'Transferencia' | 'Cheque'
  observacoes?: string
  created_at: string
  updated_at: string
}

// Nova interface para tabela produtos
export interface ProdutoPadaria {
  id: string
  nome: string
  preco_padrao: number
  ativo: boolean
  created_at: string
  updated_at: string
}

export interface ProdutoOption {
  id: string
  nome: string
  preco_padrao: number
}

// Storage para Produtos - Admin e Funcionários
export const produtosStorage = {
  // Admin: CRUD completo
  async getAll(): Promise<ProdutoPadaria[]> {
    const { data, error } = await supabase
      .from('produtos')
      .select('*')
      .order('nome')
    if (error) throw error
    return data || []
  },

  async create(produto: { nome: string; preco_padrao: number; ativo?: boolean }): Promise<ProdutoPadaria> {
    const { data, error } = await supabase
      .from('produtos')
      .insert([produto])
      .select()
      .single()
    if (error) throw error
    return data
  },

  async update(id: string, updates: { nome?: string; preco_padrao?: number; ativo?: boolean }): Promise<ProdutoPadaria> {
    const { data, error } = await supabase
      .from('produtos')
      .update(updates)
      .eq('id', id)
      .select()
      .single()
    if (error) throw error
    return data
  },

  async delete(id: string): Promise<void> {
    const { error } = await supabase
      .from('produtos')
      .delete()
      .eq('id', id)
    if (error) throw error
  },

  // Funcionários: Apenas produtos ativos
  async getAtivos(): Promise<ProdutoOption[]> {
    const { data, error } = await supabase
      .from('produtos')
      .select('id, nome, preco_padrao')
      .eq('ativo', true)
      .order('nome')
    if (error) throw error
    return data || []
  }
}


// Storage para Pagamentos
export const pagamentosStorage = {
  // Obter histórico de pagamentos de um cliente
  async getHistorico(clienteId: string): Promise<PagamentoRegistro[]> {
    const { data, error } = await supabase
      .from('pagamentos')
      .select('*')
      .eq('cliente_id', clienteId)
      .order('data_pagamento', { ascending: false })
    if (error) throw error
    return data || []
  },

  // Registrar novo pagamento
  async registrar(pagamento: {
    cliente_id: string
    funcionario_id: string
    valor: number
    metodo: string
    data_pagamento?: string
    observacoes?: string
  }): Promise<PagamentoRegistro> {
    // 1. Inserir pagamento
    const { data: pagamentoData, error: pagamentoError } = await supabase
      .from('pagamentos')
      .insert([{
        ...pagamento,
        data_pagamento: pagamento.data_pagamento || new Date().toISOString().split('T')[0]
      }])
      .select()
      .single()
    
    if (pagamentoError) throw pagamentoError
    
    // 2. Atualizar datas no cliente
    const { data: cliente } = await supabase
      .from('clientes')
      .select('data_pagamento_atual')
      .eq('id', pagamento.cliente_id)
      .single()
    
    const { error: clienteError } = await supabase
      .from('clientes')
      .update({
        ultimo_pagamento: cliente?.data_pagamento_atual,
        data_pagamento_atual: pagamentoData.data_pagamento
      })
      .eq('id', pagamento.cliente_id)
    
    if (clienteError) console.error('Erro ao atualizar cliente:', clienteError)
    
    return pagamentoData
  },

  // Obter todos os pagamentos (admin)
  async getAll(): Promise<PagamentoRegistro[]> {
    const { data, error } = await supabase
      .from('pagamentos')
      .select('*')
      .order('data_pagamento', { ascending: false })
    if (error) throw error
    return data || []
  },

  // Obter pagamentos por funcionário
  async getByFuncionario(funcionarioId: string): Promise<PagamentoRegistro[]> {
    const { data, error } = await supabase
      .from('pagamentos')
      .select('*')
      .eq('funcionario_id', funcionarioId)
      .order('data_pagamento', { ascending: false })
    if (error) throw error
    return data || []
  }
}

// Funções auxiliares para clientes
export const clientesHelpers = {
  // Verificar se cliente está em férias
  isEmFerias(cliente: ClienteComPagamento): boolean {
    if (!cliente.ferias_inicio || !cliente.ferias_fim) return false
    const hoje = new Date().toISOString().split('T')[0]
    return cliente.ferias_inicio <= hoje && cliente.ferias_fim >= hoje
  },

  // Verificar se cliente tem entrega em determinado dia
  temEntregaHoje(cliente: ClienteComPagamento, data?: string): boolean {
    const targetDate = data ? new Date(data) : new Date()
    const diaSemana = ['Domingo', 'Segunda', 'Terca', 'Quarta', 'Quinta', 'Sexta', 'Sabado'][targetDate.getDay()]
    return cliente.dias_entrega.includes(diaSemana) && !this.isEmFerias(cliente)
  },

  // Obter clientes para entrega em determinado dia
  async getClientesParaEntrega(funcionarioId: string, data?: string): Promise<ClienteComPagamento[]> {
    const { data: clientes, error } = await supabase
      .from('clientes')
      .select('*')
      .eq('funcionario_id', funcionarioId)
      .eq('ativo', true)
    
    if (error) throw error
    
    // Filtrar por dia da semana e férias
    return (clientes || []).filter(cliente => 
      this.temEntregaHoje(cliente, data)
    )
  }
}
