import React, { useEffect, useState } from 'react'
import { produtosStorage, type ProdutoOption } from '../lib/supabase'
import { Package, Plus, Trash2 } from 'lucide-react'

interface ProdutoPadrao {
  produto_id: string
  produto_nome?: string
  quantidade: number
}

interface ProductSelectorProps {
  selectedProducts: ProdutoPadrao[]
  onChange: (products: ProdutoPadrao[]) => void
}

export default function ProductSelector({ selectedProducts, onChange }: ProductSelectorProps) {
  const [produtos, setProdutos] = useState<ProdutoOption[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    carregarProdutos()
  }, [])

  async function carregarProdutos() {
    try {
      setLoading(true)
      const data = await produtosStorage.getAtivos()
      setProdutos(data)
    } catch (error) {
      console.error('Erro ao carregar produtos:', error)
    } finally {
      setLoading(false)
    }
  }

  const addProduct = () => {
    if (produtos.length === 0) return
    const firstProduct = produtos[0]
    onChange([
      ...selectedProducts,
      { produto_id: firstProduct.id, produto_nome: firstProduct.nome, quantidade: 1 }
    ])
  }

  const removeProduct = (index: number) => {
    onChange(selectedProducts.filter((_, i) => i !== index))
  }

  const updateProduct = (index: number, field: 'produto_id' | 'quantidade', value: string | number) => {
    const updated = [...selectedProducts]
    if (field === 'produto_id') {
      const produto = produtos.find(p => p.id === value)
      updated[index] = {
        ...updated[index],
        produto_id: value as string,
        produto_nome: produto?.nome
      }
    } else {
      updated[index] = {
        ...updated[index],
        quantidade: typeof value === 'number' ? value : parseInt(value) || 0
      }
    }
    onChange(updated)
  }

  if (loading) {
    return <div className="text-center py-4 text-gray-500">Carregando produtos...</div>
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <label className="block text-sm font-medium text-gray-700">
          Produtos Padrão (Opcional)
        </label>
        <button
          type="button"
          onClick={addProduct}
          disabled={produtos.length === 0}
          className="flex items-center gap-2 px-3 py-1.5 bg-orange-600 text-white text-sm rounded-lg hover:bg-orange-700 disabled:opacity-50"
        >
          <Plus className="w-4 h-4" />
          Adicionar Produto
        </button>
      </div>

      {selectedProducts.length === 0 ? (
        <div className="p-4 bg-gray-50 rounded-lg text-center text-gray-500 text-sm">
          <Package className="w-8 h-8 mx-auto mb-2 text-gray-400" />
          <p>Nenhum produto selecionado</p>
          <p className="text-xs mt-1">Clique em "Adicionar Produto" para começar</p>
        </div>
      ) : (
        <div className="space-y-3">
          {selectedProducts.map((item, index) => (
            <div key={index} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <select
                value={item.produto_id}
                onChange={(e) => updateProduct(index, 'produto_id', e.target.value)}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              >
                {produtos.map((produto) => (
                  <option key={produto.id} value={produto.id}>
                    {produto.nome} - {produto.preco_padrao.toFixed(2)}
                  </option>
                ))}
              </select>

              <input
                type="number"
                min="1"
                value={item.quantidade}
                onChange={(e) => updateProduct(index, 'quantidade', e.target.value)}
                placeholder="Qtd"
                className="w-24 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />

              <button
                type="button"
                onClick={() => removeProduct(index)}
                className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {selectedProducts.length > 0 && (
        <div className="p-3 bg-blue-50 rounded-lg">
          <p className="text-sm text-blue-700">
            <span className="font-medium">{selectedProducts.length}</span> produto(s) configurado(s)
          </p>
        </div>
      )}
    </div>
  )
}
