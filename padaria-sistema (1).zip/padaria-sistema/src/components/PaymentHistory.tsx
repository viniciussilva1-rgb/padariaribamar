import React, { useEffect, useState } from 'react'
import { pagamentosStorage, type PagamentoRegistro, type ClienteComPagamento } from '../lib/supabase'
import { useAuth } from '../contexts/AuthContext'
import { CreditCard, Plus, X, CheckCircle2, AlertCircle } from 'lucide-react'

interface PaymentHistoryProps {
  cliente: ClienteComPagamento
  onPaymentAdded?: () => void
}

export default function PaymentHistory({ cliente, onPaymentAdded }: PaymentHistoryProps) {
  const { profile } = useAuth()
  const [pagamentos, setPagamentos] = useState<PagamentoRegistro[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null)

  const [formData, setFormData] = useState({
    data_pagamento: new Date().toISOString().split('T')[0],
    valor: '',
    metodo: 'Dinheiro',
    observacoes: ''
  })

  useEffect(() => {
    carregarHistorico()
  }, [cliente.id])

  async function carregarHistorico() {
    try {
      setLoading(true)
      const data = await pagamentosStorage.getHistorico(cliente.id)
      setPagamentos(data)
    } catch (error) {
      console.error('Erro ao carregar histórico:', error)
    } finally {
      setLoading(false)
    }
  }

  const abrirModal = () => {
    setFormData({
      data_pagamento: new Date().toISOString().split('T')[0],
      valor: '',
      metodo: 'Dinheiro',
      observacoes: ''
    })
    setMessage(null)
    setShowModal(true)
  }

  const fecharModal = () => {
    setShowModal(false)
    setFormData({
      data_pagamento: new Date().toISOString().split('T')[0],
      valor: '',
      metodo: 'Dinheiro',
      observacoes: ''
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setMessage(null)

    const valor = parseFloat(formData.valor)
    if (isNaN(valor) || valor <= 0) {
      setMessage({ type: 'error', text: 'Valor deve ser maior que zero' })
      return
    }

    if (!profile?.id) {
      setMessage({ type: 'error', text: 'Funcionário não identificado' })
      return
    }

    try {
      setSaving(true)
      await pagamentosStorage.registrar({
        cliente_id: cliente.id,
        funcionario_id: profile.id,
        valor,
        metodo: formData.metodo,
        data_pagamento: formData.data_pagamento,
        observacoes: formData.observacoes || undefined
      })

      setMessage({ type: 'success', text: 'Pagamento registrado com sucesso' })
      await carregarHistorico()
      if (onPaymentAdded) onPaymentAdded()
      
      setTimeout(() => {
        fecharModal()
      }, 1500)
    } catch (error: any) {
      console.error('Erro ao registrar pagamento:', error)
      setMessage({ type: 'error', text: `Erro: ${error.message}` })
    } finally {
      setSaving(false)
    }
  }

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('pt-PT')
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-PT', {
      style: 'currency',
      currency: 'EUR'
    }).format(value)
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
          <CreditCard className="w-5 h-5" />
          Histórico de Pagamentos
        </h3>
        <button
          type="button"
          onClick={abrirModal}
          className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
        >
          <Plus className="w-4 h-4" />
          Registrar Pagamento
        </button>
      </div>

      {loading ? (
        <div className="text-center py-8 text-gray-500">Carregando histórico...</div>
      ) : pagamentos.length === 0 ? (
        <div className="p-6 bg-gray-50 rounded-lg text-center text-gray-500">
          <CreditCard className="w-12 h-12 mx-auto mb-3 text-gray-400" />
          <p>Nenhum pagamento registrado</p>
          <p className="text-sm mt-1">Clique em "Registrar Pagamento" para começar</p>
        </div>
      ) : (
        <div className="overflow-hidden border border-gray-200 rounded-lg">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Data</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Valor</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Método</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Observações</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {pagamentos.map((pagamento) => (
                <tr key={pagamento.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm text-gray-900">{formatDate(pagamento.data_pagamento)}</td>
                  <td className="px-4 py-3 text-sm font-medium text-green-600">{formatCurrency(pagamento.valor)}</td>
                  <td className="px-4 py-3 text-sm text-gray-700">{pagamento.metodo}</td>
                  <td className="px-4 py-3 text-sm text-gray-500">{pagamento.observacoes || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full">
            <div className="flex items-center justify-between p-6 border-b">
              <h3 className="text-xl font-bold text-gray-900">Registrar Pagamento</h3>
              <button
                onClick={fecharModal}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Data do Pagamento
                </label>
                <input
                  type="date"
                  value={formData.data_pagamento}
                  onChange={(e) => setFormData({ ...formData, data_pagamento: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Valor (EUR)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={formData.valor}
                  onChange={(e) => setFormData({ ...formData, valor: e.target.value })}
                  required
                  placeholder="0.00"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Método de Pagamento
                </label>
                <select
                  value={formData.metodo}
                  onChange={(e) => setFormData({ ...formData, metodo: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  <option value="Dinheiro">Dinheiro</option>
                  <option value="Cartao">Cartão</option>
                  <option value="PIX">PIX</option>
                  <option value="Transferencia">Transferência</option>
                  <option value="Cheque">Cheque</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Observações (Opcional)
                </label>
                <textarea
                  value={formData.observacoes}
                  onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="Observações sobre o pagamento..."
                />
              </div>

              {message && (
                <div className={`p-3 rounded-lg flex items-center gap-2 ${
                  message.type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
                }`}>
                  {message.type === 'success' ? (
                    <CheckCircle2 className="w-5 h-5" />
                  ) : (
                    <AlertCircle className="w-5 h-5" />
                  )}
                  <span className="text-sm">{message.text}</span>
                </div>
              )}

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={fecharModal}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
                >
                  {saving ? 'Salvando...' : 'Registrar'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
