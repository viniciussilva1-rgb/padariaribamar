import React from 'react'
import { useAuth } from '../contexts/AuthContext'
import { Wifi, WifiOff, RefreshCw } from 'lucide-react'

export function StatusIndicator() {
  const { supabaseStatus, recheckSupabase } = useAuth()
  const [checking, setChecking] = React.useState(false)

  async function handleRecheck() {
    setChecking(true)
    await recheckSupabase()
    setTimeout(() => setChecking(false), 1000)
  }

  if (supabaseStatus === 'checking') {
    return (
      <div className="flex items-center gap-2 text-sm text-gray-600">
        <RefreshCw className="w-4 h-4 animate-spin" />
        <span>Verificando conexão...</span>
      </div>
    )
  }

  if (supabaseStatus === 'offline') {
    return (
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
        <div className="flex items-center gap-2 mb-2">
          <WifiOff className="w-5 h-5 text-amber-600" />
          <span className="font-medium text-amber-900">Modo Offline</span>
        </div>
        <p className="text-sm text-amber-700 mb-3">
          Sistema funcionando com armazenamento local. Dados serão sincronizados quando a conexão for restabelecida.
        </p>
        <button
          onClick={handleRecheck}
          disabled={checking}
          className="text-sm text-amber-700 hover:text-amber-900 underline flex items-center gap-1"
        >
          <RefreshCw className={`w-4 h-4 ${checking ? 'animate-spin' : ''}`} />
          Tentar reconectar
        </button>
      </div>
    )
  }

  return (
    <div className="flex items-center gap-2 text-sm text-green-600">
      <Wifi className="w-4 h-4" />
      <span>Conectado</span>
    </div>
  )
}

export function StatusBadge() {
  const { supabaseStatus } = useAuth()

  if (supabaseStatus === 'online') {
    return (
      <div className="flex items-center gap-1.5 px-2.5 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
        <Wifi className="w-3 h-3" />
        Online
      </div>
    )
  }

  return (
    <div className="flex items-center gap-1.5 px-2.5 py-1 bg-amber-100 text-amber-700 rounded-full text-xs font-medium">
      <WifiOff className="w-3 h-3" />
      Offline
    </div>
  )
}
