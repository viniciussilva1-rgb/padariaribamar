# Configuração de Segurança - Políticas RLS

## CRÍTICO: Configurar Perfil de Administrador

### Quando o primeiro utilizador se registar no sistema:

**1. Registar utilizador no Supabase Auth**
   - Ir ao Supabase Dashboard > Authentication > Users
   - Criar utilizador com email: viniciussiuva1@gmail.com

**2. Inserir perfil de administrador**

Após o registo, executar este SQL no Supabase SQL Editor:

```sql
-- Inserir perfil do administrador
-- IMPORTANTE: Substituir 'USER_ID_AQUI' pelo ID real do utilizador criado
INSERT INTO profiles (id, email, nome, role, ativo)
VALUES (
  'USER_ID_AQUI',  -- ID do auth.users (UUID)
  'viniciussiuva1@gmail.com',
  'Administrador',
  'admin',
  true
);
```

**Como obter o USER_ID:**
```sql
-- Executar primeiro para ver o ID do utilizador
SELECT id, email FROM auth.users WHERE email = 'viniciussiuva1@gmail.com';
```

**3. Criar perfis para funcionários**

```sql
-- Para cada funcionário registado:
INSERT INTO profiles (id, email, nome, role, ativo)
VALUES (
  'ID_DO_FUNCIONARIO',  -- ID do auth.users
  'email@funcionario.com',
  'Nome do Funcionário',
  'funcionario',
  true
);
```

---

## Políticas RLS Implementadas

### Tabela: movimentos_entregador

#### Políticas de SELECT:
1. **admin_view_all_movimentos**: Administradores veem todos os registos
2. **funcionario_view_own_movimentos**: Funcionários veem apenas seus registos

#### Políticas de INSERT:
1. **admin_insert_movimentos**: Administradores podem inserir qualquer registo
2. **funcionario_insert_own_movimentos**: Funcionários só inserem com seu email

#### Políticas de UPDATE:
1. **admin_update_movimentos**: Administradores atualizam tudo
2. **funcionario_update_own_movimentos**: Funcionários atualizam apenas seus registos

#### Políticas de DELETE:
1. **admin_delete_movimentos**: Apenas administradores podem deletar

### Tabela: producao_diaria

#### Política Única:
1. **admin_all_producao**: Apenas administradores têm acesso completo (SELECT, INSERT, UPDATE, DELETE)

### Tabela: profiles

#### Políticas:
1. **users_view_own_profile**: Utilizadores veem seu próprio perfil
2. **admins_view_all_profiles**: Administradores veem todos os perfis
3. **admins_create_profiles**: Apenas administradores criam perfis

---

## Verificação de Segurança

### Testar como Funcionário:

```sql
-- Simular contexto de funcionário
SET LOCAL role TO authenticated;
SET LOCAL request.jwt.claims TO '{"sub": "ID_FUNCIONARIO", "email": "funcionario@email.com"}';

-- Deve retornar apenas registos do funcionário
SELECT * FROM movimentos_entregador;

-- Não deve retornar nada (sem permissão)
SELECT * FROM producao_diaria;
```

### Testar como Administrador:

```sql
-- Simular contexto de admin
SET LOCAL role TO authenticated;
SET LOCAL request.jwt.claims TO '{"sub": "ID_ADMIN", "email": "admin@email.com"}';

-- Deve retornar todos os registos
SELECT * FROM movimentos_entregador;
SELECT * FROM producao_diaria;
```

---

## Fluxo de Segurança

### 1. Autenticação (Supabase Auth)
- Utilizador faz login
- Supabase gera JWT token com `sub` (user ID)

### 2. Autorização (RLS)
- Cada query verifica políticas RLS
- `auth.uid()` retorna o ID do utilizador autenticado
- Políticas comparam `auth.uid()` com `profiles.id`
- `profiles.role` determina nível de acesso

### 3. Verificação no Frontend
- `AuthContext` carrega perfil do utilizador
- `profile.role` usado para mostrar/ocultar páginas
- Verificação adicional no backend via RLS

---

## Importante: Modo Híbrido

### Modo Online (Supabase):
- RLS totalmente funcional
- Segurança gerida pelo Supabase
- Multi-utilizador com isolamento de dados

### Modo Offline (LocalStorage):
- Apenas admin pode fazer login
- Sem multi-utilizador
- Dados locais no navegador
- Para uso temporário quando Supabase indisponível

---

## Comandos Úteis

### Verificar políticas ativas:
```sql
SELECT schemaname, tablename, policyname, permissive, roles, cmd
FROM pg_policies
WHERE tablename IN ('movimentos_entregador', 'producao_diaria', 'profiles')
ORDER BY tablename, policyname;
```

### Desabilitar RLS temporariamente (apenas para debug):
```sql
-- CUIDADO: Só usar em desenvolvimento
ALTER TABLE movimentos_entregador DISABLE ROW LEVEL SECURITY;
ALTER TABLE producao_diaria DISABLE ROW LEVEL SECURITY;
```

### Reabilitar RLS:
```sql
ALTER TABLE movimentos_entregador ENABLE ROW LEVEL SECURITY;
ALTER TABLE producao_diaria ENABLE ROW LEVEL SECURITY;
```

---

## Status: POLÍTICAS RLS TOTALMENTE IMPLEMENTADAS

Todas as políticas de segurança especificadas foram aplicadas corretamente no Supabase.
