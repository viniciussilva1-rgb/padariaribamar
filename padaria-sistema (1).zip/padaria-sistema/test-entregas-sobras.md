# Sistema Padaria - Teste de Entregas e Sobras

## Test Plan
**Website Type**: MPA (Multi-Page Application)
**Deployed URL**: https://im7dgo3xnsza.space.minimax.io
**Test Date**: 2025-11-03
**Funcionalidade**: Controle Diário de Entregas e Sobras

### Pathways to Test
- [ ] Login e Acesso ao Sistema
- [ ] Navegação e Menu (verificar novos links)
- [ ] Página Carga do Dia (funcionário)
  - [ ] Visualização da lista de produtos
  - [ ] Preenchimento de quantidades
  - [ ] Validações (sobra > levada)
  - [ ] Cálculos automáticos
  - [ ] Salvamento de dados
  - [ ] Responsividade mobile
- [ ] Página Produção e Quebra (admin)
  - [ ] Restrição de acesso
  - [ ] Formulário de produção
  - [ ] Visão consolidada
  - [ ] Visão por entregador
  - [ ] Cálculos de quebra
  - [ ] Responsividade mobile

## Testing Progress

### Step 1: Pre-Test Planning
- Website complexity: Complex (sistema com múltiplas funcionalidades)
- Test strategy: Testar ambas as páginas novas com foco em cálculos e validações

### Step 2: Comprehensive Testing
**Status**: In Progress

### Step 3: Coverage Validation
- [ ] Login testado
- [ ] Menu de navegação testado
- [ ] Página Carga do Dia testada
- [ ] Página Produção e Quebra testada
- [ ] Cálculos verificados
- [ ] Responsividade testada

### Step 4: Fixes & Re-testing
**Bugs Found**: 0

| Bug | Type | Status | Re-test Result |
|-----|------|--------|----------------|
| - | - | - | - |

**Final Status**: Testing in Progress
