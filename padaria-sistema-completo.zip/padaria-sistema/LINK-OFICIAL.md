# Link Oficial do Sistema - Padaria Ribamar

## Link Permanente
**https://aowsxmtctjxa.space.minimax.io**

Este é o link oficial e permanente do Sistema de Gestão de Padaria Ribamar.

## Informações do Projeto

### Nome do Projeto
- **Nome**: padariaribamar
- **Tipo**: Aplicação Web de Gestão
- **Status**: Produção

### Credenciais de Acesso

#### Administrador
- **Email**: viniciussiuva1@gmail.com
- **Senha**: Padariaribamar2025Cvs
- **Permissões**: Acesso total ao sistema

#### Funcionário Exemplo
- **Email**: vinicius2903cvs@gmail.com
- **Permissões**: Acesso limitado a funcionalidades de funcionário

### Backend - Supabase
- **Status**: ONLINE e funcional
- **Tabelas Principais**:
  - profiles (funcionários e usuários)
  - movimentos_entregador (entregas e sobras)
  - producao_diaria (produção e quebras)
- **Autenticação**: Supabase Auth ativo
- **RLS**: Políticas de segurança implementadas

## Funcionalidades do Sistema

### Para Administradores
1. **Gestão de Funcionários**
   - Criar, editar e remover funcionários
   - Criar credenciais de acesso
   - Ativar/desativar contas
   - Resetar senhas

2. **Produção e Quebra**
   - Registrar produção diária
   - Visualizar quebra por produto
   - Visualizar quebra por entregador
   - Relatórios consolidados

3. **Dashboard**
   - Visão geral do sistema
   - Estatísticas e métricas

### Para Funcionários
1. **Carga do Dia**
   - Registrar produtos levados
   - Registrar sobras
   - Cálculos automáticos
   - Totalizadores

2. **Dashboard**
   - Visão das próprias entregas
   - Histórico pessoal

## Sistema Híbrido

O sistema funciona em dois modos:

### Modo Online (Supabase)
- Multi-usuário com sincronização em tempo real
- Dados armazenados na nuvem
- Indicador: Badge "ONLINE" no header

### Modo Offline (LocalStorage)
- Usuário único (admin)
- Dados armazenados localmente
- Indicador: Badge "OFFLINE" no header
- Detecção automática quando Supabase não está disponível

## Arquitetura Técnica

### Frontend
- **Framework**: React 18 + TypeScript
- **Roteamento**: React Router v6
- **UI**: Radix UI + Tailwind CSS
- **Estado**: Context API
- **Build**: Vite

### Backend
- **BaaS**: Supabase
- **Banco de Dados**: PostgreSQL
- **Autenticação**: Supabase Auth
- **RLS**: Row Level Security implementado

### Estrutura do Projeto
```
/workspace/padaria-sistema/
├── src/
│   ├── components/        # Componentes reutilizáveis
│   ├── contexts/          # Context API (AuthContext, etc)
│   ├── pages/             # Páginas da aplicação
│   ├── utils/             # Utilitários (storage-adapter, etc)
│   └── lib/               # Configurações (Supabase, etc)
├── supabase/
│   └── migrations/        # Migrações do banco de dados
├── dist/                  # Build de produção
└── public/                # Assets estáticos
```

## Instruções para Atualizações Futuras

### Quando Atualizar o Sistema
1. Modificar código em `/workspace/padaria-sistema/`
2. Executar build: `cd /workspace/padaria-sistema && pnpm run build`
3. Deploy mantendo o mesmo link

### Importante
- Sempre trabalhar no diretório `/workspace/padaria-sistema/`
- Manter as mesmas credenciais do Supabase
- Preservar a estrutura do banco de dados
- Testar localmente antes do deploy

## Suporte e Manutenção

### Problemas Comuns

#### Sistema mostra "OFFLINE"
- Verificar conexão com internet
- Verificar se projeto Supabase está ativo
- Verificar credenciais no código

#### Não consegue fazer login
- Verificar se usuário existe no Supabase Auth
- Verificar credenciais
- Verificar RLS policies

#### Dados não aparecem
- Verificar modo (online/offline)
- Verificar RLS policies no Supabase
- Verificar console do navegador para erros

### Logs e Debugging
- Console do navegador (F12)
- Badge de status no header (ONLINE/OFFLINE)
- Mensagens de erro do sistema

## Contato e Documentação

### Documentação Técnica Completa
- `RELATORIO-SUPABASE-REATIVADO.md`: Configuração do Supabase
- `RELATORIO-SINCRONIZACAO-FUNCIONARIOS.md`: Sistema de funcionários
- `RELATORIO-VALIDACAO-CREDENCIAIS.md`: Sistema de credenciais
- `GUIA-ENTREGAS-SOBRAS.md`: Funcionalidade de entregas

### Data de Criação
- Projeto iniciado: 2025-11-03
- Última atualização: 2025-11-04 22:20

### Desenvolvedor
MiniMax Agent

---

**IMPORTANTE**: Este é o link oficial e permanente do sistema. Todas as futuras atualizações devem usar este mesmo link para garantir continuidade e evitar confusão.
