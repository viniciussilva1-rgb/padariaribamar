import React, { useState, useEffect } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { supabase, type ClienteComPagamento, clientesHelpers } from '../lib/supabase'
import { getSupabaseStatus } from '../lib/storage-adapter'
import { Users, Plus, Phone, MapPin, Calendar, DollarSign, CheckCircle, XCircle, Clock, Edit, Trash2, Package, Truck, AlertTriangle } from 'lucide-react'
import ClienteFormModal from '../components/ClienteFormModal'
import PaymentHistory from '../components/PaymentHistory'

export default function MeusClientes() {
  const { user, profile } = useAuth()
  const [clientes, setClientes] = useState<ClienteComPagamento[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [clienteSelecionado, setClienteSelecionado] = useState<ClienteComPagamento | null>(null)
  const [showPaymentHistory, setShowPaymentHistory] = useState(false)
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null)
  const supabaseStatus = getSupabaseStatus()

  useEffect(() => {
    carregarClientes()
  }, [])

  async function carregarClientes() {
    if (supabaseStatus === 'offline' || !profile?.id) {
      const stored = localStorage.getItem('padaria_meus_clientes')
      if (stored) {
        setClientes(JSON.parse(stored))
      }
      setLoading(false)
      return
    }

    try {
      setLoading(true)
      const { data, error } = await supabase
        .from('clientes')
        .select('*')
        .eq('funcionario_id', profile.id)
        .order('created_at', { ascending: false })

      if (error) throw error
      setClientes(data || [])
      
      localStorage.setItem('padaria_meus_clientes', JSON.stringify(data || []))
    } catch (error: any) {
      console.error('Erro ao carregar clientes:', error)
      setMessage({ type: 'error', text: 'Erro ao carregar clientes' })
    } finally {
      setLoading(false)
    }
  }

  function abrirModal(cliente?: ClienteComPagamento) {
    setClienteSelecionado(cliente || null)
    setMessage(null)
    setShowModal(true)
  }

  function fecharModal() {
    setShowModal(false)
    setClienteSelecionado(null)
  }

  function abrirHistoricoPagamentos(cliente: ClienteComPagamento) {
    setClienteSelecionado(cliente)
    setShowPaymentHistory(true)
  }

  function fecharHistoricoPagamentos() {
    setShowPaymentHistory(false)
    setClienteSelecionado(null)
  }

  async function handleSave(data: Partial<ClienteComPagamento>) {
    if (!profile?.id) {
      throw new Error('Utilizador não autenticado')
    }

    try {
      if (clienteSelecionado) {
        const { error } = await supabase
          .from('clientes')
          .update({
            ...data,
            updated_at: new Date().toISOString()
          })
          .eq('id', clienteSelecionado.id)

        if (error) throw error
      } else {
        const { error } = await supabase
          .from('clientes')
          .insert({
            ...data,
            funcionario_id: profile.id,
            status_pagamento: 'Pendente',
            ativo: data.ativo ?? true
          })

        if (error) throw error
      }

      await carregarClientes()
    } catch (error: any) {
      throw new Error(error.message || 'Erro ao salvar cliente')
    }
  }

  async function handleDelete(cliente: ClienteComPagamento) {
    if (!confirm(`Deseja realmente excluir o cliente "${cliente.nome}"?`)) {
      return
    }

    try {
      const { error } = await supabase
        .from('clientes')
        .delete()
        .eq('id', cliente.id)

      if (error) throw error

      setMessage({ type: 'success', text: 'Cliente excluído com sucesso!' })
      await carregarClientes()
    } catch (error: any) {
      console.error('Erro ao excluir cliente:', error)
      setMessage({ type: 'error', text: 'Erro ao excluir cliente' })
    }
  }

  const getStatusBadge = (status: string) => {
    const badges = {
      'Em dia': { icon: CheckCircle, color: 'bg-green-100 text-green-700', label: 'Em dia' },
      'Pendente': { icon: Clock, color: 'bg-yellow-100 text-yellow-700', label: 'Pendente' },
      'Vencido': { icon: XCircle, color: 'bg-red-100 text-red-700', label: 'Vencido' }
    }
    const badge = badges[status as keyof typeof badges] || badges['Pendente']
    const Icon = badge.icon
    return (
      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${badge.color}`}>
        <Icon className="w-3 h-3" />
        {badge.label}
      </span>
    )
  }

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '-'
    return new Date(dateStr).toLocaleDateString('pt-PT')
  }

  if (loading) {
    return (
      <div className="p-8">
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Carregando clientes...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="p-4 md:p-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Users className="w-7 h-7 text-orange-600" />
            Meus Clientes
          </h1>
          <p className="text-gray-600 mt-1">
            {clientes.length} cliente(s) cadastrado(s)
          </p>
        </div>
        <button
          onClick={() => abrirModal()}
          className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 shadow-lg"
        >
          <Plus className="w-5 h-5" />
          Novo Cliente
        </button>
      </div>

      {message && (
        <div className={`mb-6 p-4 rounded-lg ${
          message.type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
        }`}>
          <p className="font-medium">{message.text}</p>
        </div>
      )}

      {clientes.length === 0 ? (
        <div className="bg-white rounded-lg shadow p-12 text-center">
          <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhum cliente cadastrado</h3>
          <p className="text-gray-600 mb-6">Comece adicionando seu primeiro cliente</p>
          <button
            onClick={() => abrirModal()}
            className="inline-flex items-center gap-2 px-6 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700"
          >
            <Plus className="w-5 h-5" />
            Adicionar Cliente
          </button>
        </div>
      ) : (
        <div className="grid gap-6">
          {clientes.map((cliente) => {
            const emFerias = clientesHelpers.isEmFerias(cliente)
            const temEntregaHoje = clientesHelpers.temEntregaHoje(cliente)

            return (
              <div
                key={cliente.id}
                className={`bg-white rounded-lg shadow hover:shadow-lg transition-shadow ${
                  !cliente.ativo ? 'opacity-60' : ''
                }`}
              >
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-xl font-bold text-gray-900">{cliente.nome}</h3>
                        {!cliente.ativo && (
                          <span className="px-2 py-1 bg-gray-200 text-gray-600 text-xs rounded-full font-medium">
                            Inativo
                          </span>
                        )}
                        {emFerias && (
                          <span className="px-2 py-1 bg-purple-100 text-purple-700 text-xs rounded-full font-medium flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            Em Férias
                          </span>
                        )}
                        {temEntregaHoje && !emFerias && (
                          <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full font-medium flex items-center gap-1">
                            <Truck className="w-3 h-3" />
                            Entrega Hoje
                          </span>
                        )}
                      </div>
                      {getStatusBadge(cliente.status_pagamento)}
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => abrirModal(cliente)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Editar"
                      >
                        <Edit className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => handleDelete(cliente)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Excluir"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4 mb-4">
                    {cliente.telefone && (
                      <div className="flex items-center gap-2 text-gray-600">
                        <Phone className="w-4 h-4" />
                        <span className="text-sm">{cliente.telefone}</span>
                      </div>
                    )}
                    {cliente.morada && (
                      <div className="flex items-center gap-2 text-gray-600">
                        <MapPin className="w-4 h-4" />
                        <span className="text-sm">{cliente.morada}</span>
                      </div>
                    )}
                    {cliente.data_pagamento_atual && (
                      <div className="flex items-center gap-2 text-gray-600">
                        <Calendar className="w-4 h-4" />
                        <span className="text-sm">Próximo: {formatDate(cliente.data_pagamento_atual)}</span>
                      </div>
                    )}
                    {cliente.ultimo_pagamento && (
                      <div className="flex items-center gap-2 text-gray-600">
                        <DollarSign className="w-4 h-4" />
                        <span className="text-sm">Último: {formatDate(cliente.ultimo_pagamento)}</span>
                      </div>
                    )}
                  </div>

                  {/* Informações Adicionais */}
                  {(cliente.dias_entrega.length > 0 || cliente.produtos_padrao.length > 0 || cliente.observacoes) && (
                    <div className="pt-4 border-t space-y-3">
                      {cliente.dias_entrega.length > 0 && (
                        <div>
                          <p className="text-xs font-medium text-gray-500 mb-1">Dias de Entrega:</p>
                          <div className="flex flex-wrap gap-1">
                            {cliente.dias_entrega.map((dia) => (
                              <span key={dia} className="px-2 py-1 bg-orange-100 text-orange-700 text-xs rounded">
                                {dia}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {cliente.produtos_padrao.length > 0 && (
                        <div>
                          <p className="text-xs font-medium text-gray-500 mb-1">Produtos Padrão:</p>
                          <div className="flex flex-wrap gap-2">
                            {cliente.produtos_padrao.map((p, idx) => (
                              <span key={idx} className="flex items-center gap-1 px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded">
                                <Package className="w-3 h-3" />
                                {p.produto_nome || 'Produto'} x{p.quantidade}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {cliente.observacoes && (
                        <div>
                          <p className="text-xs font-medium text-gray-500 mb-1">Observações:</p>
                          <p className="text-sm text-gray-600">{cliente.observacoes}</p>
                        </div>
                      )}

                      {emFerias && cliente.ferias_inicio && cliente.ferias_fim && (
                        <div className="flex items-start gap-2 p-3 bg-purple-50 rounded-lg">
                          <AlertTriangle className="w-4 h-4 text-purple-600 mt-0.5" />
                          <div className="text-sm text-purple-700">
                            <strong>Férias:</strong> {formatDate(cliente.ferias_inicio)} até {formatDate(cliente.ferias_fim)}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="pt-4 border-t mt-4">
                    <button
                      onClick={() => abrirHistoricoPagamentos(cliente)}
                      className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-green-50 text-green-700 rounded-lg hover:bg-green-100 font-medium"
                    >
                      <DollarSign className="w-4 h-4" />
                      Ver Histórico de Pagamentos
                    </button>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {/* Modal de Formulário */}
      <ClienteFormModal
        cliente={clienteSelecionado}
        isOpen={showModal}
        onClose={fecharModal}
        onSave={handleSave}
      />

      {/* Modal de Histórico de Pagamentos */}
      {showPaymentHistory && clienteSelecionado && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white p-6 border-b flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-900">
                Pagamentos - {clienteSelecionado.nome}
              </h2>
              <button
                onClick={fecharHistoricoPagamentos}
                className="text-gray-400 hover:text-gray-600"
              >
                <XCircle className="w-6 h-6" />
              </button>
            </div>
            <div className="p-6">
              <PaymentHistory
                cliente={clienteSelecionado}
                onPaymentAdded={() => {
                  carregarClientes()
                }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
