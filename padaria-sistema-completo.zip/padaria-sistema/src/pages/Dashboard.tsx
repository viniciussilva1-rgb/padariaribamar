import React, { useEffect, useState } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { supabase } from '../lib/supabase'
import { TrendingUp, Users, AlertTriangle, Package, TrendingDown, UserX, DollarSign, ShoppingCart } from 'lucide-react'

interface DashboardStats {
  clientesVencidosHoje: number
  totalLevadoHoje: number
  totalVendidoHoje: number
  quebraDia: {
    unidades: number
    valor: number
  }
  funcionarioMaisPendencias: {
    nome: string
    total: number
  } | null
  
  // Stats para funcionários
  meusClientes: number
  clientesPagosHoje: number
  minhasCargasHoje: number
}

export default function Dashboard() {
  const { profile } = useAuth()
  const [stats, setStats] = useState<DashboardStats>({
    clientesVencidosHoje: 0,
    totalLevadoHoje: 0,
    totalVendidoHoje: 0,
    quebraDia: { unidades: 0, valor: 0 },
    funcionarioMaisPendencias: null,
    meusClientes: 0,
    clientesPagosHoje: 0,
    minhasCargasHoje: 0
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadDashboardData()
  }, [profile])

  async function loadDashboardData() {
    setLoading(true)
    try {
      const hoje = new Date().toISOString().split('T')[0]

      if (profile?.role === 'admin') {
        // 1. Clientes vencidos hoje
        const { data: clientesVencidos } = await supabase
          .from('clientes')
          .select('*')
          .eq('status_pagamento', 'Vencido')
          .lte('pago_ate', hoje)
        
        // 2. Total levado pelos entregadores hoje
        const { data: movimentosHoje } = await supabase
          .from('movimentos_entregador')
          .select('qtde_levada, qtde_sobra, preco_unitario')
          .eq('data', hoje)
        
        const totalLevado = movimentosHoje?.reduce((sum, m) => 
          sum + (m.qtde_levada * m.preco_unitario), 0
        ) || 0

        // 3. Total vendido hoje
        const totalVendido = movimentosHoje?.reduce((sum, m) => {
          const vendido = (m.qtde_levada - (m.qtde_sobra || 0)) * m.preco_unitario
          return sum + vendido
        }, 0) || 0

        // 4. Quebra do dia
        const { data: producaoHoje } = await supabase
          .from('producao_diaria')
          .select('*')
          .eq('data', hoje)

        const totalProduzido = producaoHoje?.reduce((sum, p) => sum + p.qtde_produzida, 0) || 0
        const totalVendidoUnidades = movimentosHoje?.reduce((sum, m) => 
          sum + (m.qtde_levada - (m.qtde_sobra || 0)), 0
        ) || 0
        const totalSobra = movimentosHoje?.reduce((sum, m) => sum + (m.qtde_sobra || 0), 0) || 0
        
        const quebraUnidades = totalProduzido - totalVendidoUnidades - totalSobra
        // Valor médio de quebra (estimativa simples)
        const precoMedio = movimentosHoje && movimentosHoje.length > 0
          ? movimentosHoje.reduce((sum, m) => sum + m.preco_unitario, 0) / movimentosHoje.length
          : 0
        const quebraValor = quebraUnidades * precoMedio

        // 5. Funcionário com mais pendências
        const { data: todosClientes } = await supabase
          .from('clientes')
          .select('funcionario_id, status_pagamento, profiles(nome)')
          .neq('status_pagamento', 'Em dia')

        const pendenciasPorFuncionario = todosClientes?.reduce((acc: any, cliente: any) => {
          const funcId = cliente.funcionario_id
          if (!funcId) return acc
          
          if (!acc[funcId]) {
            acc[funcId] = {
              nome: cliente.profiles?.nome || 'Desconhecido',
              total: 0
            }
          }
          acc[funcId].total++
          return acc
        }, {})

        const funcionarioComMais = pendenciasPorFuncionario 
          ? Object.values(pendenciasPorFuncionario).sort((a: any, b: any) => b.total - a.total)[0] as any
          : null

        setStats({
          clientesVencidosHoje: clientesVencidos?.length || 0,
          totalLevadoHoje: totalLevado,
          totalVendidoHoje: totalVendido,
          quebraDia: {
            unidades: quebraUnidades,
            valor: quebraValor
          },
          funcionarioMaisPendencias: funcionarioComMais || null,
          meusClientes: 0,
          clientesPagosHoje: 0,
          minhasCargasHoje: 0
        })
      } else {
        // Dashboard para funcionários
        const { data: meusClientes } = await supabase
          .from('clientes')
          .select('*')
          .eq('funcionario_id', profile?.id)

        const clientesPagosHoje = meusClientes?.filter(c => 
          c.data_pagamento_atual === hoje
        ).length || 0

        const { data: minhasCargas } = await supabase
          .from('movimentos_entregador')
          .select('*')
          .eq('funcionario_id', profile?.id)
          .eq('data', hoje)

        setStats({
          ...stats,
          meusClientes: meusClientes?.length || 0,
          clientesPagosHoje,
          minhasCargasHoje: minhasCargas?.length || 0
        })
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error)
    } finally {
      setLoading(false)
    }
  }

  const isAdmin = profile?.role === 'admin'

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Dashboard</h1>
        <p className="text-gray-600">
          Bem-vindo, {profile?.nome}! {isAdmin ? 'Visão geral da padaria.' : 'Suas métricas de hoje.'}
        </p>
      </div>

      {isAdmin ? (
        <>
          {/* 5 CARDS OBRIGATÓRIOS PARA ADMINISTRADOR */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 mb-8">
            {/* 1. Clientes vencidos hoje */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition">
              <div className="flex items-center justify-between mb-4">
                <div className="bg-red-500 p-3 rounded-lg">
                  <AlertTriangle className="w-6 h-6 text-white" />
                </div>
              </div>
              <h3 className="text-gray-600 text-sm font-medium mb-1">Clientes Vencidos Hoje</h3>
              <p className="text-3xl font-bold text-gray-900">{stats.clientesVencidosHoje}</p>
              <p className="text-xs text-red-600 mt-2">Requerem atenção</p>
            </div>

            {/* 2. Total levado pelos entregadores hoje */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition">
              <div className="flex items-center justify-between mb-4">
                <div className="bg-blue-500 p-3 rounded-lg">
                  <Package className="w-6 h-6 text-white" />
                </div>
              </div>
              <h3 className="text-gray-600 text-sm font-medium mb-1">Total Levado Hoje</h3>
              <p className="text-3xl font-bold text-gray-900">{stats.totalLevadoHoje.toFixed(2)} EUR</p>
              <p className="text-xs text-gray-500 mt-2">Por todos os entregadores</p>
            </div>

            {/* 3. Total vendido hoje */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition">
              <div className="flex items-center justify-between mb-4">
                <div className="bg-green-500 p-3 rounded-lg">
                  <DollarSign className="w-6 h-6 text-white" />
                </div>
              </div>
              <h3 className="text-gray-600 text-sm font-medium mb-1">Total Vendido Hoje</h3>
              <p className="text-3xl font-bold text-gray-900">{stats.totalVendidoHoje.toFixed(2)} EUR</p>
              <p className="text-xs text-green-600 mt-2">Receita do dia</p>
            </div>

            {/* 4. Quebra do dia */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition">
              <div className="flex items-center justify-between mb-4">
                <div className="bg-orange-500 p-3 rounded-lg">
                  <TrendingDown className="w-6 h-6 text-white" />
                </div>
              </div>
              <h3 className="text-gray-600 text-sm font-medium mb-1">Quebra do Dia</h3>
              <p className="text-3xl font-bold text-gray-900">{stats.quebraDia.unidades}</p>
              <p className="text-xs text-orange-600 mt-2">{stats.quebraDia.valor.toFixed(2)} EUR em perdas</p>
            </div>

            {/* 5. Funcionário com mais pendências */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition">
              <div className="flex items-center justify-between mb-4">
                <div className="bg-yellow-500 p-3 rounded-lg">
                  <UserX className="w-6 h-6 text-white" />
                </div>
              </div>
              <h3 className="text-gray-600 text-sm font-medium mb-1">Mais Pendências</h3>
              <p className="text-lg font-bold text-gray-900 truncate">
                {stats.funcionarioMaisPendencias?.nome || 'Nenhum'}
              </p>
              <p className="text-xs text-yellow-600 mt-2">
                {stats.funcionarioMaisPendencias?.total || 0} clientes pendentes
              </p>
            </div>
          </div>

          {/* Seção adicional com insights */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Resumo Operacional</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-gray-700">Sistema operacional</span>
                </div>
                <span className="text-sm text-gray-500">Atualizado agora</span>
              </div>
              
              {stats.clientesVencidosHoje > 0 && (
                <div className="flex items-center justify-between p-4 bg-red-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <AlertTriangle className="w-5 h-5 text-red-500" />
                    <span className="text-gray-700">
                      {stats.clientesVencidosHoje} cliente{stats.clientesVencidosHoje > 1 ? 's' : ''} vencido{stats.clientesVencidosHoje > 1 ? 's' : ''}
                    </span>
                  </div>
                  <span className="text-sm text-red-600 font-medium">Ação necessária</span>
                </div>
              )}
              
              {stats.quebraDia.unidades > 10 && (
                <div className="flex items-center justify-between p-4 bg-orange-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <TrendingDown className="w-5 h-5 text-orange-500" />
                    <span className="text-gray-700">Quebra acima do normal</span>
                  </div>
                  <span className="text-sm text-orange-600 font-medium">Verificar produção</span>
                </div>
              )}
            </div>
          </div>
        </>
      ) : (
        <>
          {/* Dashboard para Funcionários */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition">
              <div className="flex items-center justify-between mb-4">
                <div className="bg-blue-500 p-3 rounded-lg">
                  <Users className="w-6 h-6 text-white" />
                </div>
              </div>
              <h3 className="text-gray-600 text-sm font-medium mb-1">Meus Clientes</h3>
              <p className="text-3xl font-bold text-gray-900">{stats.meusClientes}</p>
              <p className="text-xs text-gray-500 mt-2">Total de clientes ativos</p>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition">
              <div className="flex items-center justify-between mb-4">
                <div className="bg-green-500 p-3 rounded-lg">
                  <DollarSign className="w-6 h-6 text-white" />
                </div>
              </div>
              <h3 className="text-gray-600 text-sm font-medium mb-1">Pagaram Hoje</h3>
              <p className="text-3xl font-bold text-gray-900">{stats.clientesPagosHoje}</p>
              <p className="text-xs text-green-600 mt-2">Pagamentos recebidos</p>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition">
              <div className="flex items-center justify-between mb-4">
                <div className="bg-purple-500 p-3 rounded-lg">
                  <ShoppingCart className="w-6 h-6 text-white" />
                </div>
              </div>
              <h3 className="text-gray-600 text-sm font-medium mb-1">Cargas Hoje</h3>
              <p className="text-3xl font-bold text-gray-900">{stats.minhasCargasHoje}</p>
              <p className="text-xs text-gray-500 mt-2">Produtos registados</p>
            </div>
          </div>

          <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="font-semibold text-blue-900 mb-2">Acesso Rápido</h3>
            <div className="space-y-2">
              <a href="/meus-clientes" className="block text-blue-700 hover:text-blue-900 hover:underline">
                Gestão de Clientes
              </a>
              <a href="/carga-dia" className="block text-blue-700 hover:text-blue-900 hover:underline">
                Registar Carga do Dia
              </a>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
