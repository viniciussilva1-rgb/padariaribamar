import React, { useState, useEffect } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { supabase, type ClienteComPagamento, type Profile, clientesHelpers } from '../lib/supabase'
import { Truck, Calendar, MapPin, Package, Users, Filter } from 'lucide-react'

const DIAS_SEMANA = ['Domingo', 'Segunda', 'Terca', 'Quarta', 'Quinta', 'Sexta', 'Sabado']

export default function GestaoEntregas() {
  const { profile } = useAuth()
  const [clientes, setClientes] = useState<ClienteComPagamento[]>([])
  const [funcionarios, setFuncionarios] = useState<Profile[]>([])
  const [loading, setLoading] = useState(true)
  const [filtros, setFiltros] = useState({
    funcionarioId: 'todos',
    diaSemana: DIAS_SEMANA[new Date().getDay()],
    data: new Date().toISOString().split('T')[0]
  })

  useEffect(() => {
    carregarDados()
  }, [])

  async function carregarDados() {
    try {
      setLoading(true)

      // Carregar funcionários
      const { data: funcsData, error: funcsError } = await supabase
        .from('profiles')
        .select('*')
        .eq('role', 'funcionario')
        .eq('ativo', true)
        .order('nome')

      if (funcsError) throw funcsError
      setFuncionarios(funcsData || [])

      // Carregar todos os clientes ativos
      const { data: clientesData, error: clientesError } = await supabase
        .from('clientes')
        .select('*')
        .eq('ativo', true)

      if (clientesError) throw clientesError
      setClientes(clientesData || [])
    } catch (error) {
      console.error('Erro ao carregar dados:', error)
    } finally {
      setLoading(false)
    }
  }

  const clientesFiltrados = React.useMemo(() => {
    let resultado = clientes.filter(c => {
      // Filtrar por dia da semana
      if (!c.dias_entrega.includes(filtros.diaSemana)) return false
      
      // Verificar se está em férias
      if (clientesHelpers.isEmFerias(c)) return false
      
      // Filtrar por funcionário
      if (filtros.funcionarioId !== 'todos' && c.funcionario_id !== filtros.funcionarioId) {
        return false
      }
      
      return true
    })

    // Agrupar por funcionário
    const grupos: { [key: string]: ClienteComPagamento[] } = {}
    resultado.forEach(cliente => {
      const funcId = cliente.funcionario_id || 'sem-funcionario'
      if (!grupos[funcId]) {
        grupos[funcId] = []
      }
      grupos[funcId].push(cliente)
    })

    return grupos
  }, [clientes, filtros])

  const getFuncionarioNome = (funcionarioId?: string) => {
    if (!funcionarioId) return 'Sem Funcionário'
    const func = funcionarios.find(f => f.id === funcionarioId)
    return func?.nome || 'Desconhecido'
  }

  const calcularTotais = (clientesGrupo: ClienteComPagamento[]) => {
    const totalClientes = clientesGrupo.length
    const totalProdutos = clientesGrupo.reduce((acc, c) => {
      return acc + c.produtos_padrao.reduce((sum, p) => sum + p.quantidade, 0)
    }, 0)

    return { totalClientes, totalProdutos }
  }

  if (loading) {
    return (
      <div className="p-8">
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Carregando entregas...</p>
        </div>
      </div>
    )
  }

  if (profile?.role !== 'admin') {
    return (
      <div className="p-8">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
          <p className="text-red-700 font-medium">Acesso restrito a administradores</p>
        </div>
      </div>
    )
  }

  return (
    <div className="p-4 md:p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <Truck className="w-7 h-7 text-orange-600" />
          Gestão de Entregas
        </h1>
        <p className="text-gray-600 mt-1">Rotas de entrega por funcionário</p>
      </div>

      {/* Filtros */}
      <div className="bg-white rounded-lg shadow p-6 mb-6">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="w-5 h-5 text-gray-600" />
          <h2 className="text-lg font-semibold text-gray-900">Filtros</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Data
            </label>
            <input
              type="date"
              value={filtros.data}
              onChange={(e) => {
                const newDate = e.target.value
                const diaSemana = DIAS_SEMANA[new Date(newDate).getDay()]
                setFiltros({ ...filtros, data: newDate, diaSemana })
              }}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Dia da Semana
            </label>
            <select
              value={filtros.diaSemana}
              onChange={(e) => setFiltros({ ...filtros, diaSemana: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            >
              {DIAS_SEMANA.map((dia) => (
                <option key={dia} value={dia}>{dia}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Funcionário
            </label>
            <select
              value={filtros.funcionarioId}
              onChange={(e) => setFiltros({ ...filtros, funcionarioId: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            >
              <option value="todos">Todos os Funcionários</option>
              {funcionarios.map((func) => (
                <option key={func.id} value={func.id}>{func.nome}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Listagem de Entregas */}
      {Object.keys(clientesFiltrados).length === 0 ? (
        <div className="bg-white rounded-lg shadow p-12 text-center">
          <Truck className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhuma entrega programada</h3>
          <p className="text-gray-600">
            Não há entregas para {filtros.diaSemana} com os filtros selecionados
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {Object.entries(clientesFiltrados).map(([funcionarioId, clientesGrupo]) => {
            const { totalClientes, totalProdutos } = calcularTotais(clientesGrupo)

            return (
              <div key={funcionarioId} className="bg-white rounded-lg shadow overflow-hidden">
                <div className="bg-orange-50 p-4 border-b border-orange-100">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-orange-600 rounded-full flex items-center justify-center">
                        <Users className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-gray-900">
                          {getFuncionarioNome(funcionarioId)}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {totalClientes} cliente(s) • {totalProdutos} produto(s)
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="divide-y">
                  {clientesGrupo.map((cliente, index) => (
                    <div key={cliente.id} className="p-4 hover:bg-gray-50">
                      <div className="flex items-start gap-4">
                        <div className="w-8 h-8 bg-orange-600 text-white rounded-full flex items-center justify-center font-bold flex-shrink-0">
                          {index + 1}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <h4 className="font-semibold text-gray-900">{cliente.nome}</h4>
                              {cliente.telefone && (
                                <p className="text-sm text-gray-600">{cliente.telefone}</p>
                              )}
                            </div>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              cliente.status_pagamento === 'Em dia'
                                ? 'bg-green-100 text-green-700'
                                : cliente.status_pagamento === 'Vencido'
                                ? 'bg-red-100 text-red-700'
                                : 'bg-yellow-100 text-yellow-700'
                            }`}>
                              {cliente.status_pagamento}
                            </span>
                          </div>

                          {cliente.morada && (
                            <div className="flex items-start gap-2 mb-2">
                              <MapPin className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                              <span className="text-sm text-gray-600">{cliente.morada}</span>
                            </div>
                          )}

                          {cliente.latitude && cliente.longitude && (
                            <div className="text-xs text-gray-500 mb-2">
                              GPS: {cliente.latitude.toFixed(6)}, {cliente.longitude.toFixed(6)}
                            </div>
                          )}

                          {cliente.produtos_padrao.length > 0 && (
                            <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                              <p className="text-xs font-medium text-gray-500 mb-2">Produtos:</p>
                              <div className="flex flex-wrap gap-2">
                                {cliente.produtos_padrao.map((p, idx) => (
                                  <span key={idx} className="flex items-center gap-1 px-2 py-1 bg-white border border-gray-200 text-gray-700 text-xs rounded">
                                    <Package className="w-3 h-3" />
                                    {p.produto_nome || 'Produto'} x{p.quantidade}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}

                          {cliente.observacoes && (
                            <div className="mt-2 p-2 bg-blue-50 rounded text-xs text-blue-700">
                              <strong>Obs:</strong> {cliente.observacoes}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )
          })}
        </div>
      )}

      {/* Resumo Geral */}
      <div className="mt-6 bg-gradient-to-r from-orange-600 to-orange-700 rounded-lg shadow-lg p-6 text-white">
        <h3 className="text-lg font-bold mb-4">Resumo do Dia</h3>
        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <p className="text-orange-100 text-sm">Total de Entregas</p>
            <p className="text-3xl font-bold">
              {Object.values(clientesFiltrados).reduce((acc, grupo) => acc + grupo.length, 0)}
            </p>
          </div>
          <div>
            <p className="text-orange-100 text-sm">Funcionários Ativos</p>
            <p className="text-3xl font-bold">{Object.keys(clientesFiltrados).length}</p>
          </div>
          <div>
            <p className="text-orange-100 text-sm">Total de Produtos</p>
            <p className="text-3xl font-bold">
              {Object.values(clientesFiltrados).reduce((acc, grupo) => {
                return acc + grupo.reduce((sum, c) => {
                  return sum + c.produtos_padrao.reduce((total, p) => total + p.quantidade, 0)
                }, 0)
              }, 0)}
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
