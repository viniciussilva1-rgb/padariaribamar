import React, { useState, useEffect } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { movimentosAdapter, getSupabaseStatus, produtosStorage, type ProdutoOption } from '../lib/storage-adapter'
import { Package, Save, AlertCircle, CheckCircle2 } from 'lucide-react'
import type { MovimentoEntregador } from '../lib/supabase'

interface ProdutoForm {
  produto_id: string
  produto: string
  preco_unitario: number
  qtde_levada: number
  qtde_sobra: number
}

export default function CargaDia() {
  const { user, profile } = useAuth()
  const [data, setData] = useState(new Date().toISOString().split('T')[0])
  const [produtos, setProdutos] = useState<ProdutoForm[]>([])
  const [produtosDisponiveis, setProdutosDisponiveis] = useState<ProdutoOption[]>([])
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null)
  const [movimentosExistentes, setMovimentosExistentes] = useState<MovimentoEntregador[]>([])
  const supabaseStatus = getSupabaseStatus()

  useEffect(() => {
    carregarProdutosDisponiveis()
  }, [])

  useEffect(() => {
    if (produtosDisponiveis.length > 0) {
      inicializarFormulario()
      carregarMovimentos()
    }
  }, [data, produtosDisponiveis])

  async function carregarProdutosDisponiveis() {
    try {
      const produtosDb = await produtosStorage.getAtivos()
      setProdutosDisponiveis(produtosDb)
    } catch (error) {
      console.error('Erro ao carregar produtos:', error)
      setMessage({ type: 'error', text: 'Erro ao carregar lista de produtos' })
    }
  }

  function inicializarFormulario() {
    const produtosInit = produtosDisponiveis.map(p => ({
      produto_id: p.id,
      produto: p.nome,
      preco_unitario: p.preco_padrao,
      qtde_levada: 0,
      qtde_sobra: 0
    }))
    setProdutos(produtosInit)
  }

  async function carregarMovimentos() {
    if (!user?.email || !profile?.id || produtosDisponiveis.length === 0) return
    
    try {
      const todos = await movimentosAdapter.getAll()
      const filtrados = todos.filter(m => 
        m.data === data && (m.funcionario_id === profile.id || m.entregador_email === user.email)
      )
      setMovimentosExistentes(filtrados)
      
      // Preencher formulário com dados existentes
      if (filtrados.length > 0) {
        const produtosComDados = produtosDisponiveis.map(pf => {
          const mov = filtrados.find(m => m.produto === pf.nome)
          return {
            produto_id: pf.id,
            produto: pf.nome,
            preco_unitario: mov?.preco_unitario || pf.preco_padrao,
            qtde_levada: mov?.qtde_levada || 0,
            qtde_sobra: mov?.qtde_sobra || 0
          }
        })
        setProdutos(produtosComDados)
      }
    } catch (error) {
      console.error('Erro ao carregar movimentos:', error)
    }
  }

  function handleQuantidadeChange(index: number, field: 'qtde_levada' | 'qtde_sobra', value: string) {
    const newProdutos = [...produtos]
    const numValue = parseInt(value) || 0
    newProdutos[index][field] = numValue
    setProdutos(newProdutos)
  }

  function calcularValores(p: ProdutoForm) {
    const valorLevado = p.qtde_levada * p.preco_unitario
    const valorSobra = p.qtde_sobra * p.preco_unitario
    const valorVendido = valorLevado - valorSobra
    return { valorLevado, valorSobra, valorVendido }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    
    if (!user?.email || !profile?.id) {
      setMessage({ type: 'error', text: 'Utilizador não autenticado' })
      return
    }

    // Validar que pelo menos um produto tem quantidade
    const temProdutos = produtos.some(p => p.qtde_levada > 0)
    if (!temProdutos) {
      setMessage({ type: 'error', text: 'Registre pelo menos um produto com quantidade levada' })
      return
    }

    // Validar que sobras não são maiores que levado
    const sobrasInvalidas = produtos.find(p => p.qtde_sobra > p.qtde_levada)
    if (sobrasInvalidas) {
      setMessage({ 
        type: 'error', 
        text: `Produto "${sobrasInvalidas.produto}": sobras não podem ser maiores que quantidade levada` 
      })
      return
    }

    setLoading(true)
    setMessage(null)

    try {
      // Deletar registos antigos para esta data (se existirem)
      for (const mov of movimentosExistentes) {
        await movimentosAdapter.delete(mov.id)
      }

      // Salvar apenas produtos com quantidade
      const produtosParaSalvar = produtos.filter(p => p.qtde_levada > 0)
      
      for (const p of produtosParaSalvar) {
        await movimentosAdapter.create({
          data,
          entregador_email: user.email,
          funcionario_id: profile.id,
          produto: p.produto,
          qtde_levada: p.qtde_levada,
          qtde_sobra: p.qtde_sobra,
          preco_unitario: p.preco_unitario
        })
      }

      setMessage({ 
        type: 'success', 
        text: `Carga registada com sucesso! ${produtosParaSalvar.length} produtos salvos.` 
      })
      
      // Recarregar movimentos
      await carregarMovimentos()
    } catch (error: any) {
      console.error('Erro ao salvar:', error)
      setMessage({ 
        type: 'error', 
        text: error.message || 'Erro ao salvar. Tente novamente.' 
      })
    } finally {
      setLoading(false)
    }
  }

  // Calcular totais
  const totais = produtos.reduce((acc, p) => {
    const { valorLevado, valorSobra, valorVendido } = calcularValores(p)
    return {
      levado: acc.levado + valorLevado,
      sobra: acc.sobra + valorSobra,
      vendido: acc.vendido + valorVendido
    }
  }, { levado: 0, sobra: 0, vendido: 0 })

  return (
    <div className="max-w-6xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-primary rounded-lg">
              <Package className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Carga do Dia</h1>
              <p className="text-sm text-gray-500">Registar produtos levados e sobras</p>
            </div>
          </div>
          {supabaseStatus === 'offline' && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg px-3 py-2">
              <p className="text-xs text-yellow-800">Modo Offline</p>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit}>
          {/* Data */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Data
            </label>
            <input
              type="date"
              value={data}
              onChange={(e) => setData(e.target.value)}
              className="w-full md:w-64 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
              required
            />
          </div>

          {/* Mensagens */}
          {message && (
            <div className={`mb-6 p-4 rounded-lg flex items-start space-x-3 ${
              message.type === 'success' 
                ? 'bg-green-50 border border-green-200' 
                : 'bg-red-50 border border-red-200'
            }`}>
              {message.type === 'success' ? (
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              )}
              <p className={`text-sm ${
                message.type === 'success' ? 'text-green-800' : 'text-red-800'
              }`}>
                {message.text}
              </p>
            </div>
          )}

          {/* Tabela de Produtos - Desktop */}
          <div className="hidden md:block overflow-x-auto mb-6">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Produto</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Preço</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Qtd. Levada</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Sobras</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Valor Levado</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Valor Sobra</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Valor Vendido</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {produtos.map((p, index) => {
                  const { valorLevado, valorSobra, valorVendido } = calcularValores(p)
                  return (
                    <tr key={p.produto} className="hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm font-medium text-gray-900">{p.produto}</td>
                      <td className="px-4 py-3 text-sm text-gray-500 text-right">{p.preco_unitario.toFixed(2)} EUR</td>
                      <td className="px-4 py-3">
                        <input
                          type="number"
                          min="0"
                          value={p.qtde_levada || ''}
                          onChange={(e) => handleQuantidadeChange(index, 'qtde_levada', e.target.value)}
                          className="w-24 px-3 py-2 border border-gray-300 rounded-lg text-right focus:ring-2 focus:ring-primary focus:border-transparent"
                          placeholder="0"
                        />
                      </td>
                      <td className="px-4 py-3">
                        <input
                          type="number"
                          min="0"
                          value={p.qtde_sobra || ''}
                          onChange={(e) => handleQuantidadeChange(index, 'qtde_sobra', e.target.value)}
                          className="w-24 px-3 py-2 border border-gray-300 rounded-lg text-right focus:ring-2 focus:ring-primary focus:border-transparent"
                          placeholder="0"
                        />
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-900 text-right font-medium">
                        {valorLevado.toFixed(2)} EUR
                      </td>
                      <td className="px-4 py-3 text-sm text-orange-600 text-right font-medium">
                        {valorSobra.toFixed(2)} EUR
                      </td>
                      <td className="px-4 py-3 text-sm text-green-600 text-right font-bold">
                        {valorVendido.toFixed(2)} EUR
                      </td>
                    </tr>
                  )
                })}
              </tbody>
              <tfoot className="bg-gray-50 border-t-2 border-gray-300">
                <tr>
                  <td colSpan={4} className="px-4 py-3 text-sm font-bold text-gray-900 text-right">TOTAIS:</td>
                  <td className="px-4 py-3 text-sm font-bold text-gray-900 text-right">{totais.levado.toFixed(2)} EUR</td>
                  <td className="px-4 py-3 text-sm font-bold text-orange-600 text-right">{totais.sobra.toFixed(2)} EUR</td>
                  <td className="px-4 py-3 text-sm font-bold text-green-600 text-right">{totais.vendido.toFixed(2)} EUR</td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Cards de Produtos - Mobile */}
          <div className="md:hidden space-y-4 mb-6">
            {produtos.map((p, index) => {
              const { valorLevado, valorSobra, valorVendido } = calcularValores(p)
              return (
                <div key={p.produto} className="border border-gray-200 rounded-lg p-4 bg-white">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="font-semibold text-gray-900">{p.produto}</h3>
                    <span className="text-sm text-gray-500">{p.preco_unitario.toFixed(2)} EUR</span>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 mb-3">
                    <div>
                      <label className="block text-xs text-gray-500 mb-1">Qtd. Levada</label>
                      <input
                        type="number"
                        min="0"
                        value={p.qtde_levada || ''}
                        onChange={(e) => handleQuantidadeChange(index, 'qtde_levada', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-right"
                        placeholder="0"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-500 mb-1">Sobras</label>
                      <input
                        type="number"
                        min="0"
                        value={p.qtde_sobra || ''}
                        onChange={(e) => handleQuantidadeChange(index, 'qtde_sobra', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-right"
                        placeholder="0"
                      />
                    </div>
                  </div>
                  
                  {(p.qtde_levada > 0 || p.qtde_sobra > 0) && (
                    <div className="pt-3 border-t border-gray-200 space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Valor Levado:</span>
                        <span className="font-medium">{valorLevado.toFixed(2)} EUR</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Valor Sobra:</span>
                        <span className="font-medium text-orange-600">{valorSobra.toFixed(2)} EUR</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Valor Vendido:</span>
                        <span className="font-bold text-green-600">{valorVendido.toFixed(2)} EUR</span>
                      </div>
                    </div>
                  )}
                </div>
              )
            })}
            
            {/* Totais Mobile */}
            <div className="border-2 border-primary rounded-lg p-4 bg-primary bg-opacity-5">
              <h3 className="font-bold text-gray-900 mb-3">TOTAIS</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-700">Total Levado:</span>
                  <span className="font-bold">{totais.levado.toFixed(2)} EUR</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-700">Total Sobras:</span>
                  <span className="font-bold text-orange-600">{totais.sobra.toFixed(2)} EUR</span>
                </div>
                <div className="flex justify-between text-lg">
                  <span className="text-gray-900 font-semibold">Total Vendido:</span>
                  <span className="font-bold text-green-600">{totais.vendido.toFixed(2)} EUR</span>
                </div>
              </div>
            </div>
          </div>

          {/* Botão Salvar */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={loading}
              className="flex items-center space-x-2 px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary-dark disabled:opacity-50 disabled:cursor-not-allowed transition font-medium"
            >
              <Save className="w-5 h-5" />
              <span>{loading ? 'A guardar...' : 'Guardar Carga'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
