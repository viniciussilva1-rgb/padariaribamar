import React, { useState } from 'react'
import { type ClienteComPagamento } from '../lib/supabase'
import { X, User, Truck, CreditCard, FileText } from 'lucide-react'
import LocationPicker from './LocationPicker'
import DaysSelector from './DaysSelector'
import ProductSelector from './ProductSelector'

interface ClienteFormModalProps {
  cliente: ClienteComPagamento | null
  isOpen: boolean
  onClose: () => void
  onSave: (data: Partial<ClienteComPagamento>) => Promise<void>
}

type TabType = 'basico' | 'entrega' | 'pagamento' | 'observacoes'

export default function ClienteFormModal({ cliente, isOpen, onClose, onSave }: ClienteFormModalProps) {
  const [activeTab, setActiveTab] = useState<TabType>('basico')
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null)

  const [formData, setFormData] = useState<Partial<ClienteComPagamento>>({
    nome: cliente?.nome || '',
    telefone: cliente?.telefone || '',
    morada: cliente?.morada || '',
    latitude: cliente?.latitude,
    longitude: cliente?.longitude,
    frequencia_pagamento: cliente?.frequencia_pagamento || 'MENSAL',
    dias_entrega: cliente?.dias_entrega || [],
    produtos_padrao: cliente?.produtos_padrao || [],
    ferias_inicio: cliente?.ferias_inicio,
    ferias_fim: cliente?.ferias_fim,
    observacoes: cliente?.observacoes || '',
    ativo: cliente?.ativo ?? true
  })

  React.useEffect(() => {
    if (cliente) {
      setFormData({
        nome: cliente.nome,
        telefone: cliente.telefone,
        morada: cliente.morada,
        latitude: cliente.latitude,
        longitude: cliente.longitude,
        frequencia_pagamento: cliente.frequencia_pagamento || 'MENSAL',
        dias_entrega: cliente.dias_entrega || [],
        produtos_padrao: cliente.produtos_padrao || [],
        ferias_inicio: cliente.ferias_inicio,
        ferias_fim: cliente.ferias_fim,
        observacoes: cliente.observacoes,
        ativo: cliente.ativo
      })
    } else {
      setFormData({
        nome: '',
        telefone: '',
        morada: '',
        frequencia_pagamento: 'MENSAL',
        dias_entrega: [],
        produtos_padrao: [],
        observacoes: '',
        ativo: true
      })
    }
    setActiveTab('basico')
    setMessage(null)
  }, [cliente, isOpen])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setMessage(null)

    // Validações
    if (!formData.nome?.trim()) {
      setMessage({ type: 'error', text: 'Nome é obrigatório' })
      setActiveTab('basico')
      return
    }

    if (!formData.dias_entrega || formData.dias_entrega.length === 0) {
      setMessage({ type: 'error', text: 'Selecione pelo menos um dia de entrega' })
      setActiveTab('entrega')
      return
    }

    try {
      setSaving(true)
      await onSave(formData)
      setMessage({ type: 'success', text: 'Cliente salvo com sucesso!' })
      setTimeout(() => {
        onClose()
      }, 1500)
    } catch (error: any) {
      setMessage({ type: 'error', text: error.message || 'Erro ao salvar cliente' })
    } finally {
      setSaving(false)
    }
  }

  if (!isOpen) return null

  const tabs = [
    { id: 'basico', label: 'Dados Básicos', icon: User },
    { id: 'entrega', label: 'Entrega', icon: Truck },
    { id: 'pagamento', label: 'Pagamento', icon: CreditCard },
    { id: 'observacoes', label: 'Observações', icon: FileText }
  ]

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full my-8">
        <div className="flex items-center justify-between p-6 border-b sticky top-0 bg-white rounded-t-xl">
          <h2 className="text-2xl font-bold text-gray-900">
            {cliente ? 'Editar Cliente' : 'Novo Cliente'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b bg-gray-50">
          <div className="flex overflow-x-auto">
            {tabs.map((tab) => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id as TabType)}
                  className={`
                    flex items-center gap-2 px-6 py-4 font-medium transition-all
                    ${activeTab === tab.id
                      ? 'text-orange-600 border-b-2 border-orange-600 bg-white'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    }
                  `}
                >
                  <Icon className="w-5 h-5" />
                  <span className="whitespace-nowrap">{tab.label}</span>
                </button>
              )
            })}
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="p-6 space-y-6 max-h-[60vh] overflow-y-auto">
            {/* ABA 1: DADOS BÁSICOS */}
            {activeTab === 'basico' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nome Completo <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.nome || ''}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    required
                    placeholder="Nome do cliente"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Telefone
                  </label>
                  <input
                    type="tel"
                    value={formData.telefone || ''}
                    onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
                    placeholder="(+351) 912 345 678"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Morada
                  </label>
                  <textarea
                    value={formData.morada || ''}
                    onChange={(e) => setFormData({ ...formData, morada: e.target.value })}
                    rows={3}
                    placeholder="Endereço completo do cliente"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>

                <div className="pt-4 border-t">
                  <LocationPicker
                    latitude={formData.latitude}
                    longitude={formData.longitude}
                    onChange={(lat, lng) => setFormData({ ...formData, latitude: lat, longitude: lng })}
                    onClear={() => setFormData({ ...formData, latitude: undefined, longitude: undefined })}
                  />
                </div>
              </div>
            )}

            {/* ABA 2: ENTREGA */}
            {activeTab === 'entrega' && (
              <div className="space-y-6">
                <DaysSelector
                  selectedDays={formData.dias_entrega || []}
                  onChange={(days) => setFormData({ ...formData, dias_entrega: days })}
                  required
                />

                <div className="pt-4 border-t">
                  <ProductSelector
                    selectedProducts={formData.produtos_padrao || []}
                    onChange={(products) => setFormData({ ...formData, produtos_padrao: products })}
                  />
                </div>

                <div className="pt-4 border-t">
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Período de Férias (Opcional)
                  </label>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs text-gray-600 mb-1">Data Início</label>
                      <input
                        type="date"
                        value={formData.ferias_inicio || ''}
                        onChange={(e) => setFormData({ ...formData, ferias_inicio: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600 mb-1">Data Fim</label>
                      <input
                        type="date"
                        value={formData.ferias_fim || ''}
                        onChange={(e) => setFormData({ ...formData, ferias_fim: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ABA 3: PAGAMENTO */}
            {activeTab === 'pagamento' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Frequência de Pagamento
                  </label>
                  <select
                    value={formData.frequencia_pagamento || 'MENSAL'}
                    onChange={(e) => setFormData({ ...formData, frequencia_pagamento: e.target.value as any })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  >
                    <option value="DIARIO">Diário</option>
                    <option value="SEMANAL">Semanal</option>
                    <option value="MENSAL">Mensal</option>
                    <option value="PERSONALIZADO">Personalizado</option>
                  </select>
                </div>

                <div className="p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">Informação</h4>
                  <p className="text-sm text-blue-700">
                    O histórico de pagamentos pode ser gerenciado após salvar o cliente.
                    Use a seção "Histórico de Pagamentos" para registrar novos pagamentos.
                  </p>
                </div>
              </div>
            )}

            {/* ABA 4: OBSERVAÇÕES */}
            {activeTab === 'observacoes' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Observações Gerais
                  </label>
                  <textarea
                    value={formData.observacoes || ''}
                    onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                    rows={8}
                    placeholder="Observações sobre o cliente, preferências, instruções especiais de entrega, etc."
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>

                <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                  <input
                    type="checkbox"
                    id="cliente-ativo"
                    checked={formData.ativo ?? true}
                    onChange={(e) => setFormData({ ...formData, ativo: e.target.checked })}
                    className="w-4 h-4 text-orange-600 focus:ring-orange-500 rounded"
                  />
                  <label htmlFor="cliente-ativo" className="text-sm font-medium text-gray-700">
                    Cliente Ativo
                  </label>
                </div>
              </div>
            )}

            {message && (
              <div className={`p-4 rounded-lg ${
                message.type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
              }`}>
                <p className="text-sm font-medium">{message.text}</p>
              </div>
            )}
          </div>

          <div className="flex gap-3 p-6 border-t bg-gray-50 rounded-b-xl">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex-1 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 disabled:opacity-50"
            >
              {saving ? 'Salvando...' : cliente ? 'Salvar Alterações' : 'Criar Cliente'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
