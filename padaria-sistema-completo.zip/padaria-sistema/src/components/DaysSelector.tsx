import React from 'react'
import { Calendar } from 'lucide-react'

interface DaysSelectorProps {
  selectedDays: string[]
  onChange: (days: string[]) => void
  required?: boolean
}

const DIAS_SEMANA = [
  'Segunda',
  'Terca',
  'Quarta',
  'Quinta',
  'Sexta',
  'Sabado',
  'Domingo'
]

export default function DaysSelector({ selectedDays, onChange, required = true }: DaysSelectorProps) {
  const toggleDay = (day: string) => {
    if (selectedDays.includes(day)) {
      onChange(selectedDays.filter(d => d !== day))
    } else {
      onChange([...selectedDays, day])
    }
  }

  const selectAll = () => {
    onChange(DIAS_SEMANA)
  }

  const selectAlternate = () => {
    onChange(['Segunda', 'Quarta', 'Sexta'])
  }

  const clearAll = () => {
    onChange([])
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <label className="block text-sm font-medium text-gray-700">
          Dias de Entrega {required && <span className="text-red-500">*</span>}
        </label>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={selectAll}
            className="text-xs px-2 py-1 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
          >
            Todos
          </button>
          <button
            type="button"
            onClick={selectAlternate}
            className="text-xs px-2 py-1 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
          >
            Seg/Qua/Sex
          </button>
          <button
            type="button"
            onClick={clearAll}
            className="text-xs px-2 py-1 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
          >
            Limpar
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {DIAS_SEMANA.map((dia) => (
          <button
            key={dia}
            type="button"
            onClick={() => toggleDay(dia)}
            className={`
              p-3 rounded-lg border-2 transition-all
              ${selectedDays.includes(dia)
                ? 'border-orange-500 bg-orange-50 text-orange-700'
                : 'border-gray-300 bg-white text-gray-700 hover:border-gray-400'
              }
            `}
          >
            <div className="flex flex-col items-center gap-1">
              <Calendar className="w-4 h-4" />
              <span className="text-sm font-medium">{dia}</span>
            </div>
          </button>
        ))}
      </div>

      {required && selectedDays.length === 0 && (
        <p className="text-sm text-red-500">
          Selecione pelo menos um dia de entrega
        </p>
      )}

      {selectedDays.length > 0 && (
        <div className="p-3 bg-blue-50 rounded-lg">
          <p className="text-sm text-blue-700">
            <span className="font-medium">{selectedDays.length}</span> dia(s) selecionado(s): {selectedDays.join(', ')}
          </p>
        </div>
      )}
    </div>
  )
}
