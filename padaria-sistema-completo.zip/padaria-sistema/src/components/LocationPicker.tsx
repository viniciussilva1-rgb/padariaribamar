import React from 'react'
import { MapPin, Navigation } from 'lucide-react'

interface LocationPickerProps {
  latitude?: number
  longitude?: number
  onChange: (lat: number, lng: number) => void
  onClear: () => void
}

export default function LocationPicker({ latitude, longitude, onChange, onClear }: LocationPickerProps) {
  const [loading, setLoading] = React.useState(false)
  const [error, setError] = React.useState<string>('')

  const captureLocation = () => {
    if (!navigator.geolocation) {
      setError('Geolocalização não suportada pelo navegador')
      return
    }

    setLoading(true)
    setError('')

    navigator.geolocation.getCurrentPosition(
      (position) => {
        onChange(position.coords.latitude, position.coords.longitude)
        setLoading(false)
      },
      (err) => {
        setError(`Erro: ${err.message}`)
        setLoading(false)
      },
      { enableHighAccuracy: true, timeout: 10000 }
    )
  }

  const handleManualChange = (field: 'lat' | 'lng', value: string) => {
    const numValue = parseFloat(value)
    if (!isNaN(numValue)) {
      if (field === 'lat') {
        onChange(numValue, longitude || 0)
      } else {
        onChange(latitude || 0, numValue)
      }
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={captureLocation}
          disabled={loading}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
        >
          <Navigation className="w-4 h-4" />
          {loading ? 'Capturando...' : 'Capturar Localização Atual'}
        </button>
        
        {(latitude || longitude) && (
          <button
            type="button"
            onClick={onClear}
            className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400"
          >
            Limpar
          </button>
        )}
      </div>

      {error && (
        <div className="p-3 bg-red-50 text-red-700 rounded-lg text-sm">
          {error}
        </div>
      )}

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Latitude
          </label>
          <input
            type="number"
            step="0.00000001"
            value={latitude || ''}
            onChange={(e) => handleManualChange('lat', e.target.value)}
            placeholder="Ex: 38.7223"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Longitude
          </label>
          <input
            type="number"
            step="0.00000001"
            value={longitude || ''}
            onChange={(e) => handleManualChange('lng', e.target.value)}
            placeholder="Ex: -9.1393"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
          />
        </div>
      </div>

      {latitude && longitude && (
        <div className="flex items-start gap-2 p-3 bg-green-50 rounded-lg">
          <MapPin className="w-5 h-5 text-green-600 mt-0.5" />
          <div className="text-sm">
            <p className="font-medium text-green-900">Localização definida</p>
            <p className="text-green-700">
              {latitude.toFixed(6)}, {longitude.toFixed(6)}
            </p>
          </div>
        </div>
      )}
    </div>
  )
}
