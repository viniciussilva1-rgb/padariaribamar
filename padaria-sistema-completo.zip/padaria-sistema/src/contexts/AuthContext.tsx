import React, { createContext, useContext, useEffect, useState } from 'react'
import { type Profile } from '../lib/supabase'
import { 
  authAdapter, 
  testSupabaseConnection, 
  getSupabaseStatus, 
  onStatusChange,
  initializeSampleData,
  type SupabaseStatus 
} from '../lib/storage-adapter'

interface AuthContextType {
  user: any | null
  profile: Profile | null
  loading: boolean
  supabaseStatus: SupabaseStatus
  signIn: (email: string, password: string) => Promise<void>
  signOut: () => Promise<void>
  refreshProfile: () => Promise<void>
  recheckSupabase: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<any | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const [supabaseStatus, setSupabaseStatus] = useState<SupabaseStatus>('checking')

  useEffect(() => {
    // Testar conexão ao carregar
    testSupabaseConnection().then(() => {
      loadUser()
    })

    // Observar mudanças de status
    const unsubscribe = onStatusChange((status) => {
      setSupabaseStatus(status)
      if (status === 'offline') {
        initializeSampleData()
      }
    })

    return () => unsubscribe()
  }, [])

  async function loadUser() {
    setLoading(true)
    try {
      const { user, profile } = await authAdapter.getUser()
      setUser(user)
      setProfile(profile)
    } catch (error) {
      console.error('Erro ao carregar utilizador:', error)
      setUser(null)
      setProfile(null)
    } finally {
      setLoading(false)
    }
  }

  async function signIn(email: string, password: string) {
    const { user, profile } = await authAdapter.signIn(email, password)
    setUser(user)
    setProfile(profile)
  }

  async function signOut() {
    await authAdapter.signOut()
    setUser(null)
    setProfile(null)
  }

  async function refreshProfile() {
    const { user, profile } = await authAdapter.getUser()
    setUser(user)
    setProfile(profile)
  }

  async function recheckSupabase() {
    setSupabaseStatus('checking')
    await testSupabaseConnection()
  }

  return (
    <AuthContext.Provider value={{ 
      user, 
      profile, 
      loading, 
      supabaseStatus,
      signIn, 
      signOut, 
      refreshProfile,
      recheckSupabase 
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth deve ser usado dentro de AuthProvider')
  }
  return context
}
