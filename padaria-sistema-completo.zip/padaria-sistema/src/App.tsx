import React from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './contexts/AuthContext'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Clientes from './pages/Clientes'
import MeusClientes from './pages/MeusClientes'
import EntregasHoje from './pages/EntregasHoje'
import Pagamentos from './pages/Pagamentos'
import Produtos from './pages/Produtos'
import GestaoProdutos from './pages/GestaoProdutos'
import Funcionarios from './pages/Funcionarios'
import CargaDia from './pages/CargaDia'
import ProducaoQuebra from './pages/ProducaoQuebra'
import GestaoEntregas from './pages/GestaoEntregas'
import Layout from './components/Layout'

function ProtectedRoutes() {
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!user) {
    return <Navigate to="/login" replace />
  }

  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/clientes" element={<Clientes />} />
        <Route path="/meus-clientes" element={<MeusClientes />} />
        <Route path="/funcionarios" element={<Funcionarios />} />
        <Route path="/entregas-hoje" element={<EntregasHoje />} />
        <Route path="/pagamentos" element={<Pagamentos />} />
        <Route path="/produtos" element={<Produtos />} />
        <Route path="/gestao-produtos" element={<GestaoProdutos />} />
        <Route path="/gestao-entregas" element={<GestaoEntregas />} />
        <Route path="/carga-dia" element={<CargaDia />} />
        <Route path="/producao-quebra" element={<ProducaoQuebra />} />
      </Routes>
    </Layout>
  )
}

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginRoute />} />
          <Route path="/*" element={<ProtectedRoutes />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  )
}

function LoginRoute() {
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (user) {
    return <Navigate to="/dashboard" replace />
  }

  return <Login />
}

export default App
