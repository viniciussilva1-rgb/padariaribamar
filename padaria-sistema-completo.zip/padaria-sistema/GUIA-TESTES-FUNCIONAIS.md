# Guia de Testes Funcionais - Sistema de Entregas e Sobras

## OBJETIVO
Validar todas as funcionalidades do sistema através de testes manuais no navegador.

---

## PRÉ-REQUISITOS

### 1. Acesso ao Sistema
- URL: https://im7dgo3xnsza.space.minimax.io
- Email: viniciussiuva1@gmail.com
- Senha: Padariaribamar2025Cvs

### 2. Configuração do Supabase (se testar modo online)
- Criar utilizador no Supabase Auth
- Inserir perfil na tabela `profiles` (ver CONFIGURACAO-SEGURANCA-RLS.md)

---

## TESTE 1: LOGIN E AUTENTICAÇÃO

### Passos:
1. Abrir https://im7dgo3xnsza.space.minimax.io
2. Inserir credenciais:
   - Email: viniciussiuva1@gmail.com
   - Senha: Padariaribamar2025Cvs
3. Clicar em "Entrar"

### Resultado Esperado:
- Login bem-sucedido
- Redirecionamento para Dashboard
- Menu lateral mostra "Padaria Ribamar"
- Badge mostra status (Online/Offline)

### Verificação:
- [ ] Login funciona
- [ ] Dashboard carrega
- [ ] Menu visível
- [ ] Badge de status presente

---

## TESTE 2: NAVEGAÇÃO - MENU

### Passos:
1. Após login, verificar menu lateral
2. Procurar os links:
   - Dashboard
   - Clientes
   - Pedidos
   - Entregas Hoje
   - Pagamentos
   - **Carga do Dia** (NOVO)
   - **Produção e Quebra** (NOVO - apenas admin)
   - Produtos
   - Funcionários

### Resultado Esperado:
- Todos os links visíveis
- Links "Carga do Dia" e "Produção e Quebra" presentes
- Ícones corretos (ClipboardList e BarChart3)

### Verificação:
- [ ] Link "Carga do Dia" presente
- [ ] Link "Produção e Quebra" presente
- [ ] Ícones corretos

---

## TESTE 3: PÁGINA "CARGA DO DIA" - VISUALIZAÇÃO

### Passos:
1. Clicar em "Carga do Dia" no menu
2. Observar a página

### Resultado Esperado:
- Página carrega sem erros
- Título: "Carga do Dia"
- Descrição: "Registar produtos levados e sobras"
- Campo de data (padrão: hoje)
- Lista de 12 produtos:
  1. Bolinha (0.25 EUR)
  2. Viana (0.80 EUR)
  3. Pão de trigo (0.30 EUR)
  4. Cassete (0.35 EUR)
  5. Pão pequeno (0.25 EUR)
  6. Papo Seco (0.30 EUR)
  7. Bolinha de semente (0.40 EUR)
  8. Bolinha de centeio (0.40 EUR)
  9. Cassetinho de centeio (0.35 EUR)
  10. Pão de milho (0.45 EUR)
  11. Pão de forma (1.50 EUR)
  12. Pão com chouriço (1.20 EUR)
- Campos para cada produto:
  - Qtd. Levada
  - Sobras
- Colunas de valores (Valor Levado, Valor Sobra, Valor Vendido)
- Botão "Guardar Carga"

### Verificação:
- [ ] Página carrega
- [ ] 12 produtos listados
- [ ] Preços corretos
- [ ] Campos de input presentes
- [ ] Botão "Guardar" presente

---

## TESTE 4: PÁGINA "CARGA DO DIA" - PREENCHIMENTO

### Cenário: Registar carga de 3 produtos

### Passos:
1. Na página "Carga do Dia"
2. Preencher os seguintes dados:

   **Produto 1: Bolinha**
   - Qtd. Levada: 100
   - Sobras: 10

   **Produto 2: Viana**
   - Qtd. Levada: 50
   - Sobras: 5

   **Produto 3: Pão de trigo**
   - Qtd. Levada: 200
   - Sobras: 15

3. Observar os cálculos automáticos

### Resultado Esperado:
- **Bolinha:**
  - Valor Levado: 25.00 EUR (100 × 0.25)
  - Valor Sobra: 2.50 EUR (10 × 0.25)
  - Valor Vendido: 22.50 EUR (25.00 - 2.50)

- **Viana:**
  - Valor Levado: 40.00 EUR (50 × 0.80)
  - Valor Sobra: 4.00 EUR (5 × 0.80)
  - Valor Vendido: 36.00 EUR

- **Pão de trigo:**
  - Valor Levado: 60.00 EUR (200 × 0.30)
  - Valor Sobra: 4.50 EUR (15 × 0.30)
  - Valor Vendido: 55.50 EUR

- **TOTAIS:**
  - Total Levado: 125.00 EUR
  - Total Sobras: 11.00 EUR
  - Total Vendido: 114.00 EUR

### Verificação:
- [ ] Valores calculados automaticamente
- [ ] Cálculos corretos para cada produto
- [ ] Totais corretos no rodapé

---

## TESTE 5: PÁGINA "CARGA DO DIA" - SALVAMENTO

### Passos:
1. Com os dados preenchidos do TESTE 4
2. Clicar em "Guardar Carga"
3. Aguardar resposta

### Resultado Esperado:
- Mensagem de sucesso aparece (verde)
- Texto: "Carga registada com sucesso! 3 produtos salvos."
- Dados permanecem na página

### Verificação:
- [ ] Mensagem de sucesso aparece
- [ ] Dados foram salvos
- [ ] Sem erros no console do navegador

---

## TESTE 6: VALIDAÇÃO - SOBRAS MAIORES QUE LEVADO

### Passos:
1. Limpar os campos
2. Preencher um produto com sobras > levado:
   - Bolinha:
     - Qtd. Levada: 10
     - Sobras: 20
3. Clicar em "Guardar Carga"

### Resultado Esperado:
- Mensagem de erro aparece (vermelha)
- Texto: "Produto 'Bolinha': sobras não podem ser maiores que quantidade levada"
- Dados NÃO são salvos

### Verificação:
- [ ] Mensagem de erro aparece
- [ ] Validação funciona
- [ ] Dados não salvos

---

## TESTE 7: VALIDAÇÃO - NENHUM PRODUTO PREENCHIDO

### Passos:
1. Limpar todos os campos (deixar tudo vazio ou zero)
2. Clicar em "Guardar Carga"

### Resultado Esperado:
- Mensagem de erro aparece
- Texto: "Registre pelo menos um produto com quantidade levada"
- Dados NÃO são salvos

### Verificação:
- [ ] Mensagem de erro aparece
- [ ] Validação funciona

---

## TESTE 8: PÁGINA "PRODUÇÃO E QUEBRA" - ACESSO ADMIN

### Passos:
1. Clicar em "Produção e Quebra" no menu
2. Observar a página

### Resultado Esperado:
- Página carrega sem erros
- Título: "Produção e Quebra do Dia"
- Campo de data
- Seção "Registar Produção Diária" com:
  - Grid com 12 produtos
  - Campos numéricos para quantidade produzida
  - Botão "Guardar Produção"
- Tabs: "Visão Consolidada" e "Por Entregador"

### Verificação:
- [ ] Página carrega para admin
- [ ] Formulário de produção presente
- [ ] Tabs de visualização presentes

---

## TESTE 9: REGISTAR PRODUÇÃO DIÁRIA

### Passos:
1. Na página "Produção e Quebra"
2. Preencher produção para 3 produtos:
   - Bolinha: 150
   - Viana: 60
   - Pão de trigo: 250
3. Clicar em "Guardar Produção"

### Resultado Esperado:
- Mensagem de sucesso aparece
- Texto: "Produção registada com sucesso! 3 produtos salvos."
- Valores salvos no banco de dados

### Verificação:
- [ ] Mensagem de sucesso
- [ ] Produção salva

---

## TESTE 10: VISÃO CONSOLIDADA - CÁLCULO DE QUEBRA

### Pré-condição:
- Produção registada (TESTE 9)
- Carga registada (TESTE 4)

### Passos:
1. Na página "Produção e Quebra"
2. Verificar tab "Visão Consolidada"
3. Observar a tabela

### Resultado Esperado para Bolinha:
- Produzido: 150
- Levado: 100
- Sobras: 10
- Vendido: 90 (100 - 10)
- Quebra: 50 (150 - 90 - 10)
- Valor Quebra: 12.50 EUR (50 × 0.25)

### Resultado Esperado para Viana:
- Produzido: 60
- Levado: 50
- Sobras: 5
- Vendido: 45
- Quebra: 10
- Valor Quebra: 8.00 EUR

### Resultado Esperado para Pão de trigo:
- Produzido: 250
- Levado: 200
- Sobras: 15
- Vendido: 185
- Quebra: 50
- Valor Quebra: 15.00 EUR

### Verificação:
- [ ] Tabela consolidada mostra dados
- [ ] Cálculos de quebra corretos
- [ ] Valor da quebra correto

---

## TESTE 11: VISÃO POR ENTREGADOR

### Passos:
1. Na página "Produção e Quebra"
2. Clicar na tab "Por Entregador"
3. Observar os dados

### Resultado Esperado:
- Lista com entregador: viniciussiuva1@gmail.com
- Tabela com produtos:
  - Bolinha: Levado=100, Sobras=10, Vendido=90, Valor=22.50 EUR
  - Viana: Levado=50, Sobras=5, Vendido=45, Valor=36.00 EUR
  - Pão de trigo: Levado=200, Sobras=15, Vendido=185, Valor=55.50 EUR
- Totais:
  - Total Levado: 125.00 EUR
  - Total Sobras: 11.00 EUR
  - Total Vendido: 114.00 EUR

### Verificação:
- [ ] Entregador listado
- [ ] Produtos do entregador corretos
- [ ] Totais corretos

---

## TESTE 12: RESPONSIVIDADE MOBILE

### Passos:
1. Abrir DevTools do navegador (F12)
2. Ativar modo responsivo (Ctrl+Shift+M)
3. Selecionar tamanho mobile (375x667 - iPhone)
4. Navegar pelas páginas:
   - Carga do Dia
   - Produção e Quebra

### Resultado Esperado:
- **Carga do Dia:**
  - Cards individuais por produto (não tabela)
  - Campos empilhados verticalmente
  - Totais em card destacado
  - Botão "Guardar" visível

- **Menu:**
  - Menu hambúrguer aparece
  - Links acessíveis ao clicar

### Verificação:
- [ ] Layout mobile funciona
- [ ] Cards visíveis
- [ ] Campos acessíveis
- [ ] Botões funcionais

---

## TESTE 13: RECARREGAR DADOS EXISTENTES

### Passos:
1. Na página "Carga do Dia"
2. Verificar se os dados preenchidos anteriormente estão visíveis
3. Modificar algum valor
4. Salvar novamente

### Resultado Esperado:
- Dados anteriores carregados automaticamente
- Possível editar valores
- Salvamento substitui dados antigos

### Verificação:
- [ ] Dados carregados ao abrir página
- [ ] Edição funciona
- [ ] Salvamento atualiza registos

---

## TESTE 14: FILTRO POR DATA

### Passos:
1. Na página "Produção e Quebra"
2. Alterar a data para ontem
3. Verificar visão consolidada

### Resultado Esperado:
- Dados filtrados pela data selecionada
- Se não houver dados: tabela vazia ou mensagem

### Verificação:
- [ ] Filtro de data funciona
- [ ] Dados corretos para data selecionada

---

## TESTE 15: CONTROLE DE ACESSO (se possível criar funcionário)

### Passos:
1. Criar um segundo utilizador com role 'funcionario'
2. Fazer logout
3. Login com o funcionário
4. Tentar aceder "Produção e Quebra"

### Resultado Esperado:
- Mensagem: "Acesso Restrito"
- "Esta página é apenas para administradores"
- Funcionário não vê o conteúdo

### Verificação:
- [ ] Funcionário não acede produção
- [ ] Mensagem de erro aparece

---

## CHECKLIST FINAL

### Funcionalidades Essenciais:
- [ ] Login funciona
- [ ] Menu carrega com novos links
- [ ] Página Carga do Dia carrega
- [ ] 12 produtos listados com preços corretos
- [ ] Cálculos automáticos funcionam
- [ ] Validações funcionam (sobras, mínimo 1 produto)
- [ ] Salvamento de carga funciona
- [ ] Mensagens de sucesso/erro aparecem
- [ ] Página Produção e Quebra carrega (admin)
- [ ] Registo de produção funciona
- [ ] Visão consolidada com quebra funciona
- [ ] Cálculos de quebra corretos
- [ ] Visão por entregador funciona
- [ ] Totais calculados corretamente
- [ ] Responsividade mobile funciona
- [ ] Recarregar dados existentes funciona
- [ ] Filtro por data funciona
- [ ] Sistema híbrido (badge Online/Offline)

### Segurança:
- [ ] RLS implementado
- [ ] Controle de acesso funciona
- [ ] Funcionário só vê seus dados

---

## RELATÓRIO DE TESTES

**Data do Teste:** _________________

**Testador:** _________________

**Ambiente:** [ ] Produção [ ] Local

**Modo:** [ ] Online (Supabase) [ ] Offline (LocalStorage)

**Resultado Geral:** [ ] Aprovado [ ] Reprovado

**Problemas Encontrados:**
_________________________________________________
_________________________________________________
_________________________________________________

**Observações:**
_________________________________________________
_________________________________________________
_________________________________________________

---

## PRÓXIMOS PASSOS APÓS TESTES

1. **Se todos os testes passarem:**
   - Marcar tarefa como concluída
   - Entregar sistema ao utilizador
   - Fornecer documentação completa

2. **Se houver falhas:**
   - Documentar bugs encontrados
   - Priorizar correções
   - Corrigir e re-testar

---

**Status Atual:** AGUARDANDO TESTES MANUAIS NO NAVEGADOR
