# 🔐 Guia: Sistema de Credenciais para Funcionários

## ✅ Sistema Implementado e Funcional
**URL**: https://lc0tca57t416.space.minimax.io

## 🎯 Como Usar o Sistema de Credenciais

### 1. Acessar como Administrador
- **Email**: viniciussiuva1@gmail.com
- **Senha**: Padariaribamar2025Cvs
- Faça login → Clique em "Funcionários" no menu

### 2. Criar Funcionário COM Credenciais
1. Clique **"Novo Funcionário"**
2. Preencha os dados básicos:
   - Nome, Email, Telefone, Cargo, Data de Admissão
3. **✅ Marque**: "Criar credenciais de login para este funcionário"
4. **Escolha o tipo de acesso**:
   - **Funcionário**: Acesso limitado (recomendado)
   - **Administrador**: Acesso total (apenas para gerentes)
5. **Deixe marcado**: "Gerar senha automaticamente" (mais seguro)
6. Clique **"Cadastrar"**

### 3. 🎉 Credenciais Geradas Automaticamente
Após criar o funcionário, aparecerá um **modal verde** com:
- ✉️ **Email** do funcionário
- 🔑 **Senha** gerada automaticamente (8 caracteres)
- 📋 **Botões de cópia** para facilitar

### 4. Copiar e Enviar Credenciais
- **Opção 1**: Copiar email e senha separadamente
- **Opção 2**: Clique **"Copiar Tudo"** para texto completo:
```
Credenciais de Acesso - Sistema Padaria Ribamar

Email: funcionario@email.com
Senha: ABC123xy

Para acessar: https://lc0tca57t416.space.minimax.io
```

### 5. Gestão de Credenciais (Status e Controle)

#### Status Visual nos Cards:
- 🟢 **"Credenciais Ativas"** = Funcionário pode fazer login
- 🔴 **"Credenciais Inativas"** = Acesso bloqueado
- ⚪ **"Sem Credenciais"** = Apenas cadastro, sem acesso

#### Botões de Controle:
- **🔴 Desativar**: Bloqueia o acesso do funcionário (sem deletar)
- **🟢 Ativar**: Reativa o acesso bloqueado
- **🔄 Reset**: Gera nova senha e mostra no modal

### 6. Funcionário Fazer Login
O funcionário usa as credenciais recebidas:
1. Acessa: https://lc0tca57t416.space.minimax.io
2. Usa email e senha fornecidos
3. Acesso limitado conforme o role definido

## 🛡️ Vantagens do Sistema

### ✅ **Automação Total**
- Não precisa criar contas manualmente no Supabase
- Senhas geradas automaticamente (mais seguras)
- Integração automática com sistema de permissões

### ✅ **Controle Granular**
- Ativar/Desativar acesso sem perder dados
- Reset de senha em caso de problema
- Roles diferentes (funcionário vs admin)

### ✅ **Facilidade de Uso**
- Interface intuitiva com status visuais claros
- Cópia fácil das credenciais
- Texto formatado pronto para envio

### ✅ **Segurança**
- Senhas aleatórias de 8 caracteres
- Confirmação de email automática
- Sistema de permissões por role

## 📱 Compatibilidade
- ✅ Funciona em Desktop e Mobile
- ✅ Sistema Híbrido: Online (Supabase) + Offline (LocalStorage)
- ✅ Totalmente integrado com sistema existente

## 🆘 Resolução de Problemas

### Funcionário não consegue fazer login:
1. Verificar se as credenciais estão **"Ativas"** no card
2. Se inativas, clicar **"Ativar"**
3. Se necessário, usar **"Reset"** para nova senha

### Esqueceu as credenciais:
1. Localizar funcionário na lista
2. Clicar **"Reset"** 
3. Nova senha será gerada e exibida no modal

### Sistema offline:
- Funcionários criados ficam salvos localmente
- Credenciais serão criadas no Supabase quando sistema voltar online
- Status visual indica se está online/offline

## 🎉 Sistema Pronto para Uso!
Agora você pode criar funcionários com acesso ao sistema de forma rápida e segura. Qualquer dúvida, consulte esta documentação ou teste as funcionalidades no sistema.