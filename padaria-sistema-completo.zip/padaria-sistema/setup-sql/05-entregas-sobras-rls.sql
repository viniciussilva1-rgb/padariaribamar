-- Políticas RLS para Controle de Entregas e Sobras
-- Criado em: 2025-11-03

-- Habilitar RLS nas tabelas
ALTER TABLE movimentos_entregador ENABLE ROW LEVEL SECURITY;
ALTER TABLE producao_diaria ENABLE ROW LEVEL SECURITY;

-- Políticas para movimentos_entregador

-- Funcionários podem ver apenas os seus próprios registos
CREATE POLICY "Funcionários podem ver seus próprios movimentos"
  ON movimentos_entregador
  FOR SELECT
  USING (
    entregador_email = auth.jwt() ->> 'email'
    OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Funcionários podem inserir apenas com o seu próprio email
CREATE POLICY "Funcionários podem criar seus próprios movimentos"
  ON movimentos_entregador
  FOR INSERT
  WITH CHECK (
    entregador_email = auth.jwt() ->> 'email'
    OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Funcionários podem atualizar apenas os seus próprios registos
CREATE POLICY "Funcionários podem atualizar seus próprios movimentos"
  ON movimentos_entregador
  FOR UPDATE
  USING (
    entregador_email = auth.jwt() ->> 'email'
    OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Apenas admins podem deletar
CREATE POLICY "Apenas admins podem deletar movimentos"
  ON movimentos_entregador
  FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Políticas para producao_diaria

-- Apenas admins podem ver produção diária
CREATE POLICY "Apenas admins podem ver produção"
  ON producao_diaria
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Apenas admins podem inserir produção
CREATE POLICY "Apenas admins podem criar produção"
  ON producao_diaria
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Apenas admins podem atualizar produção
CREATE POLICY "Apenas admins podem atualizar produção"
  ON producao_diaria
  FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Apenas admins podem deletar produção
CREATE POLICY "Apenas admins podem deletar produção"
  ON producao_diaria
  FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );
