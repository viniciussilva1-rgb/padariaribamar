-- ================================================
-- PARTE 2: POLÍTICAS RLS (ROW LEVEL SECURITY)
-- Sistema de Gestão de Padaria Ribamar
-- ================================================

-- Ativar RLS em todas as tabelas
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE produtos ENABLE ROW LEVEL SECURITY;
ALTER TABLE pedidos ENABLE ROW LEVEL SECURITY;
ALTER TABLE pedido_itens ENABLE ROW LEVEL SECURITY;
ALTER TABLE entregas ENABLE ROW LEVEL SECURITY;
ALTER TABLE pagamentos ENABLE ROW LEVEL SECURITY;

-- Políticas para profiles
CREATE POLICY "Utilizadores podem ver o próprio perfil" ON profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Admins podem ver todos os perfis" ON profiles
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins podem inserir perfis" ON profiles
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins podem atualizar perfis" ON profiles
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

-- Políticas para clientes (todos os utilizadores autenticados)
CREATE POLICY "Utilizadores autenticados podem ver clientes" ON clientes
  FOR SELECT USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem inserir clientes" ON clientes
  FOR INSERT WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem atualizar clientes" ON clientes
  FOR UPDATE USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

-- Políticas para produtos
CREATE POLICY "Utilizadores autenticados podem ver produtos" ON produtos
  FOR SELECT USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Admins podem inserir produtos" ON produtos
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins podem atualizar produtos" ON produtos
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

-- Políticas para pedidos
CREATE POLICY "Utilizadores autenticados podem ver pedidos" ON pedidos
  FOR SELECT USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem inserir pedidos" ON pedidos
  FOR INSERT WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem atualizar pedidos" ON pedidos
  FOR UPDATE USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

-- Políticas para pedido_itens
CREATE POLICY "Utilizadores autenticados podem ver itens" ON pedido_itens
  FOR SELECT USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem inserir itens" ON pedido_itens
  FOR INSERT WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

-- Políticas para entregas
CREATE POLICY "Utilizadores autenticados podem ver entregas" ON entregas
  FOR SELECT USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem inserir entregas" ON entregas
  FOR INSERT WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem atualizar entregas" ON entregas
  FOR UPDATE USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

-- Políticas para pagamentos
CREATE POLICY "Utilizadores autenticados podem ver pagamentos" ON pagamentos
  FOR SELECT USING (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem inserir pagamentos" ON pagamentos
  FOR INSERT WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Utilizadores autenticados podem atualizar pagamentos" ON pagamentos
  FOR UPDATE USING (auth.role() IN ('authenticated', 'anon', 'service_role'));
