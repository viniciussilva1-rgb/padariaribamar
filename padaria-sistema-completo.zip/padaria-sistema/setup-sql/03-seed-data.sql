-- ================================================
-- PARTE 3: DADOS INICIAIS (OPCIONAL)
-- Sistema de Gestão de Padaria Ribamar
-- ================================================
-- IMPORTANTE: Só executar APÓS criar o utilizador admin no painel Authentication

-- Inserir perfil do administrador
-- Substituir 'USER_ID_AQUI' pelo ID do utilizador criado
INSERT INTO profiles (id, email, nome, role, ativo)
SELECT 
  id,
  'viniciussiuva1@gmail.com',
  'Administrador',
  'admin',
  true
FROM auth.users
WHERE email = 'viniciussiuva1@gmail.com'
ON CONFLICT (id) DO NOTHING;

-- Adicionar produtos de exemplo (OPCIONAL)
INSERT INTO produtos (nome, categoria, preco, estoque, unidade) VALUES
('Pão Francês', 'Pães', 0.50, 100, 'un'),
('Pão de Forma', 'Pães', 3.50, 20, 'un'),
('Bolo de Chocolate', 'Bolos', 25.00, 5, 'un'),
('Croissant', 'Pães', 2.50, 30, 'un'),
('Sonho', 'Doces', 2.00, 15, 'un'),
('Baguete', 'Pães', 1.50, 25, 'un'),
('Pão Integral', 'Pães', 4.00, 15, 'un'),
('Torta de Morango', 'Bolos', 30.00, 3, 'un')
ON CONFLICT DO NOTHING;

-- Adicionar clientes de exemplo (OPCIONAL)
INSERT INTO clientes (nome, telefone, bairro, endereco, created_by) VALUES
('João Silva', '912345678', 'Centro', 'Rua Principal, 123', (SELECT id FROM auth.users WHERE email = 'viniciussiuva1@gmail.com')),
('Maria Santos', '913456789', 'Norte', 'Av. Central, 456', (SELECT id FROM auth.users WHERE email = 'viniciussiuva1@gmail.com')),
('Pedro Costa', '914567890', 'Sul', 'Praça da República, 789', (SELECT id FROM auth.users WHERE email = 'viniciussiuva1@gmail.com')),
('Ana Ferreira', '915678901', 'Centro', 'Rua das Flores, 321', (SELECT id FROM auth.users WHERE email = 'viniciussiuva1@gmail.com')),
('Carlos Oliveira', '916789012', 'Leste', 'Av. da Liberdade, 654', (SELECT id FROM auth.users WHERE email = 'viniciussiuva1@gmail.com'))
ON CONFLICT DO NOTHING;
