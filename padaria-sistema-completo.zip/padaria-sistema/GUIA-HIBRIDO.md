# Sistema Híbrido - Guia de Uso Imediato

## Acesso ao Sistema

**URL**: https://3ecoke3pl071.space.minimax.io

**Credenciais de Administrador**:
- Email: viniciussiuva1@gmail.com
- Senha: Padariaribamar2025Cvs

## Como Funciona o Sistema Híbrido

### Detecção Automática
Ao carregar a página, o sistema automaticamente:
1. Testa conexão com Supabase (timeout de 3 segundos)
2. Se Supabase está disponível → Modo Online
3. Se Supabase não responde → Modo Offline (LocalStorage)

### Indicadores Visuais

**Badge de Status**: Aparece no cabeçalho ao lado do nome "Padaria Ribamar"
- Badge verde "Online" = Conectado ao Supabase
- Badge amarelo "Offline" = Usando LocalStorage

**Aviso na Página de Login** (modo offline):
- Caixa amarela informando que está em "Modo Offline"
- Explicação sobre armazenamento local
- Botão para tentar reconectar

## Modo Offline (Atual)

### O que funciona:
- ✅ Login com credenciais do administrador
- ✅ Dashboard completo
- ✅ Gestão de Clientes (criar, editar, excluir)
- ✅ Gestão de Produtos (criar, editar, excluir)
- ✅ Todos os dados persistem no navegador (LocalStorage)
- ✅ Dados de exemplo pré-carregados:
  - 2 clientes: Maria Silva, João Santos
  - 3 produtos: Pão Francês, Pão de Forma, Bolo de Chocolate

### Limitações do modo offline:
- Apenas 1 utilizador (administrador)
- Dados salvos apenas neste navegador
- Não há sincronização entre dispositivos
- Ao limpar dados do navegador, dados são perdidos

## Quando o Supabase Voltar

### Reativação Automática:
1. O sistema detectará automaticamente quando Supabase voltar online
2. Badge mudará para "Online" verde
3. Pode usar o botão "Tentar reconectar" para forçar verificação

### Sincronização de Dados:
Os dados criados em modo offline podem ser sincronizados manualmente:
- Função `syncLocalToSupabase()` está implementada
- Migra clientes e produtos do LocalStorage para Supabase
- Preserva os IDs e timestamps originais

### Funcionalidades adicionais (modo online):
- Multi-utilizador (adicionar funcionários)
- Sincronização em tempo real
- Dados salvos na nuvem
- Acesso de múltiplos dispositivos

## Primeiro Acesso

1. Acesse: https://3ecoke3pl071.space.minimax.io
2. Verá aviso "Modo Offline" (com Supabase pausado)
3. Faça login com as credenciais acima
4. Será redirecionado para o Dashboard
5. Explore as páginas:
   - Dashboard: Visão geral
   - Clientes: Gerir clientes
   - Produtos: Gerir produtos (apenas admin)
   - Entregas Hoje: Ver entregas do dia
   - Pagamentos: Gerir pagamentos

## Testando o Sistema

### Adicionar Cliente:
1. Ir para "Clientes"
2. Clicar "Novo Cliente"
3. Preencher: Nome, Telefone, Endereço, Bairro
4. Clicar "Adicionar"
5. Cliente aparece na lista imediatamente

### Adicionar Produto:
1. Ir para "Produtos"
2. Clicar "Novo Produto"
3. Preencher: Nome, Categoria, Preço, Estoque
4. Clicar "Adicionar"
5. Produto aparece na lista

### Verificar Persistência:
1. Adicionar dados (cliente ou produto)
2. Recarregar página (F5)
3. Fazer login novamente
4. Dados continuam lá

## Resolução de Problemas

### "Não consigo fazer login"
- Verifique as credenciais exatas (copie e cole)
- Em modo offline, apenas o admin pode fazer login
- Email: viniciussiuva1@gmail.com
- Senha: Padariaribamar2025Cvs (case-sensitive)

### "Meus dados desapareceram"
- Não limpe os dados do navegador
- Use sempre o mesmo navegador e perfil
- Em modo offline, dados estão apenas neste navegador

### "Quero usar em outro computador"
- Em modo offline, não é possível
- Aguarde Supabase ser reativado para sincronização na nuvem

### "Como ativo o Supabase?"
1. Acesse: https://supabase.com
2. Faça login na conta
3. Selecione projeto: qqvmbueaxclmywrhezcr
4. Clique em "Resume project" ou "Restore project"
5. Aguarde alguns minutos
6. No sistema, clique "Tentar reconectar"

## Suporte Técnico

### Arquivos Importantes:
- `src/lib/storage-adapter.ts`: Lógica híbrida
- `src/contexts/AuthContext.tsx`: Autenticação
- `src/components/StatusIndicator.tsx`: Indicadores visuais

### Sincronização Manual (quando Supabase voltar):
Abrir console do navegador (F12) e executar:
```javascript
// Importar e executar sincronização
import { syncLocalToSupabase } from './src/lib/storage-adapter'
await syncLocalToSupabase()
```

## Próximos Passos

Quando o Supabase for reativado:
1. Sistema detectará automaticamente
2. Poderá adicionar outros utilizadores (funcionários)
3. Dados sincronizarão entre dispositivos
4. Todas as funcionalidades estarão disponíveis
5. Poderá migrar dados criados em modo offline

## Resumo

**Sistema está 100% funcional em modo offline**
- Login funciona ✅
- CRUD de clientes funciona ✅
- CRUD de produtos funciona ✅
- Dados persistem ✅
- Interface completa ✅

**Use normalmente enquanto Supabase está pausado!**
