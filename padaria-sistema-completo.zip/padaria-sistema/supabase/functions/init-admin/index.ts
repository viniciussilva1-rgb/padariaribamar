Deno.serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    // Configurar cliente Supabase com service role
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const authHeaders = {
      'Authorization': `Bearer ${serviceRoleKey}`,
      'apikey': serviceRoleKey,
      'Content-Type': 'application/json'
    };

    // Dados do admin
    const adminEmail = 'viniciussiuva1@gmail.com';
    const adminPassword = 'Padariaribamar2025Cvs';
    const adminNome = 'Vinicius Silva';

    console.log('1. Verificando se usuário admin já existe...');
    
    // 1. Verificar se usuário já existe
    const getUserResponse = await fetch(`${supabaseUrl}/auth/v1/admin/users`, {
      method: 'GET',
      headers: authHeaders
    });

    if (!getUserResponse.ok) {
      throw new Error(`Erro ao verificar usuários: ${getUserResponse.status}`);
    }

    const existingUsers = await getUserResponse.json();
    const adminExists = existingUsers.users?.find((user: any) => user.email === adminEmail);

    let adminUserId: string;

    if (adminExists) {
      console.log('2. Usuário admin já existe, usando ID existente');
      adminUserId = adminExists.id;
    } else {
      console.log('2. Criando novo usuário admin...');
      
      // 2. Criar usuário admin
      const createUserResponse = await fetch(`${supabaseUrl}/auth/v1/admin/users`, {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({
          email: adminEmail,
          password: adminPassword,
          email_confirm: true,
          user_metadata: {
            name: adminNome,
            role: 'admin'
          }
        })
      });

      if (!createUserResponse.ok) {
        const errorData = await createUserResponse.text();
        throw new Error(`Erro ao criar usuário: ${createUserResponse.status} - ${errorData}`);
      }

      const newUser = await createUserResponse.json();
      adminUserId = newUser.id;
      console.log(`Usuário criado com ID: ${adminUserId}`);
    }

    // 3. Verificar se perfil já existe
    console.log('3. Verificando perfil na tabela profiles...');
    
    const checkProfileResponse = await fetch(`${supabaseUrl}/rest/v1/profiles?id=eq.${adminUserId}`, {
      method: 'GET',
      headers: authHeaders
    });

    if (!checkProfileResponse.ok) {
      throw new Error(`Erro ao verificar perfil: ${checkProfileResponse.status}`);
    }

    const existingProfiles = await checkProfileResponse.json();

    if (existingProfiles.length === 0) {
      console.log('4. Criando perfil na tabela profiles...');
      
      // 4. Criar perfil
      const createProfileResponse = await fetch(`${supabaseUrl}/rest/v1/profiles`, {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({
          id: adminUserId,
          email: adminEmail,
          nome: adminNome,
          role: 'admin',
          ativo: true
        })
      });

      if (!createProfileResponse.ok) {
        const errorData = await createProfileResponse.text();
        throw new Error(`Erro ao criar perfil: ${createProfileResponse.status} - ${errorData}`);
      }

      console.log('Perfil criado com sucesso');
    } else {
      console.log('4. Perfil já existe, atualizando se necessário...');
      
      // Atualizar perfil existente
      const updateProfileResponse = await fetch(`${supabaseUrl}/rest/v1/profiles?id=eq.${adminUserId}`, {
        method: 'PATCH',
        headers: authHeaders,
        body: JSON.stringify({
          email: adminEmail,
          nome: adminNome,
          role: 'admin',
          ativo: true
        })
      });

      if (!updateProfileResponse.ok) {
        console.warn('Aviso: Erro ao atualizar perfil, mas continuar...');
      }
    }

    // 5. Verificar conectividade das tabelas principais
    console.log('5. Verificando conectividade das tabelas...');
    
    const tabelas = ['profiles', 'movimentos_entregador', 'producao_diaria'];
    const statusTabelas: Record<string, boolean> = {};

    for (const tabela of tabelas) {
      try {
        const testResponse = await fetch(`${supabaseUrl}/rest/v1/${tabela}?limit=1`, {
          method: 'GET',
          headers: authHeaders
        });
        statusTabelas[tabela] = testResponse.ok;
      } catch (error) {
        statusTabelas[tabela] = false;
      }
    }

    // 6. Resultado final
    const resultado = {
      success: true,
      adminUser: {
        id: adminUserId,
        email: adminEmail,
        nome: adminNome,
        role: 'admin'
      },
      status: {
        userExists: !!adminExists,
        profileCreated: true,
        tablesStatus: statusTabelas
      },
      message: 'Sistema inicializado com sucesso! Usuário admin criado/verificado.'
    };

    console.log('6. Inicialização completa:', resultado);

    return new Response(JSON.stringify({ data: resultado }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Erro na inicialização:', error);
    
    const errorResponse = {
      error: {
        code: 'INIT_ERROR',
        message: error.message || 'Erro desconhecido na inicialização'
      }
    };

    return new Response(JSON.stringify(errorResponse), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});